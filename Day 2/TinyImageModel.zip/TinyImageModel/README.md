# IMG07 — train an image model, then look at it

The image twin of MyTextModelDemo, built to *prove* the Part-3 vision decks
(Deck 1+2 "from file to visual words" and Deck 4 "how did it learn"). Same
three-container shape, same Train → Inference → Look-inside arc — but for
photos instead of text.

| container | job |
|---|---|
| `frontend` | three-tab UI: **Train / Inference / Look inside** — http://localhost:8080 |
| `backend`  | pulls a labeled dataset from Hugging Face, serves images, routes to IMG07 or OpenAI |
| `model`    | IMG07 itself — a tiny Vision Transformer, trains and serves `model.safetensors` |

IMG07 = a pure-NumPy ViT (forward **and** backward written by hand, no torch).
A 32×32 photo becomes **16 patch tokens** (8×8 patches on a 4×4 grid); those 16
tokens flow through 4 pre-LN transformer blocks; the prediction head folds them
into one image representation and a softmax **scoreboard** gives a belief for
every class. 213,765 learned numbers — a real ViT-Base has ~86 million, same
tensor names, only tiny.

## Run
```bash
cp .env .env.local   # (optional) paste an OpenAI key to enable side B
docker compose up --build   # then open http://localhost:8080
```

## Classroom flow
1. **Train tab** — the images come from **Hugging Face only**. Take the default
   classroom set (`uoft-cs/cifar10`, 5 classes: boat/car/truck/dog/bird) or
   paste any HF image-classification dataset, pick images-per-class, and
   **Pull from Hugging Face**. The gallery fills with the downloaded photos,
   each wearing its class badge — this is a **SUPERVISED** dataset: the folder
   the image lands in *is* its human label.
2. Click **Train the model**. Watch the patch-token count — every image is 16
   patch tokens, so `images × 16 × epochs` tokens flow through the model. The
   Inference and Look-inside tabs unlock.
3. **Inference tab** — click any downloaded image. Run it two ways:
   - **IMG07** (side A) → the scoreboard, a belief for every class, with an
     automatic ✓/✗ against the photo's own label.
   - **OpenAI** (side B) → GPT-4o describes the same image. It never trained on
     your photos, yet it can name anything. That contrast is the lesson: ours
     is tiny and transparent; theirs is huge and opaque.
4. **Look inside** — the three files training wrote, what each is for, and the
   real tensors inside `model.safetensors` (same names as any HuggingFace ViT).

## What training produces (visible in ./artifacts)
- `model.safetensors` — every learned weight, HuggingFace-style tensor names
  (`patch.W`, `pos`, `layers.{0..3}.attn.q.W`, `mlp.1.W`, `head.W`, …)
- `config.json` — the architecture card (image size, patch size, hidden width,
  blocks, heads, class list)
- `classes.json` — the label vocabulary + provenance (classes, image counts,
  patch tokens seen, holdout accuracy)

The model reloads them on restart, so a trained IMG07 survives
`docker compose down`. Walk them live on the CLI:

    docker compose exec model python inspect_files.py

## Notes
- Real Hugging Face downloads happen at run time on your machine. The default
  `uoft-cs/cifar10` maps its labels to the decks' 5 classes; any other HF
  dataset with an Image column and a ClassLabel column (2–12 classes) works too.
- Side B (OpenAI) is optional — set `OPENAI_API_KEY` in `.env`. Without it, the
  Inference tab still runs your trained model; only the OpenAI comparison is
  disabled.

## Code map (split by responsibility, like the text demo)
```text
frontend/  index.html · assets/styles.css · assets/app.js
backend/app/
  main.py                 thin FastAPI routes
  config.py · schemas.py
  services/datasets.py    Hugging Face image-dataset importer + gallery
  services/model_client.py backend -> model HTTP calls
model/app/
  main.py                 thin model-service routes
  config.py               ViT dimensions + patch geometry
  vision.py               the ViT: forward + hand-written backward + Adam
  patches.py              photo -> 16 patch tokens
  training.py             supervised loop + artifact save/load
  inference.py            scoreboard prediction + label check
  inspector.py            Look-inside payload (files + tensor walk)
```
