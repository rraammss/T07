from pydantic import BaseModel
from typing import Optional, List

class TrainReq(BaseModel):
    epochs: Optional[int] = None

class InferReq(BaseModel):
    filename: str            # "train/<class>/<file>"  or a pool file
    expected: Optional[str] = None
