"""Build the JSON behind the Look-inside tab.

Everything a student needs to understand what training produced: the exact
files on disk, plain-English explanations of each, and a walk through the real
tensors inside model.safetensors (same tensor names as any HuggingFace ViT,
just tiny). All teaching copy lives here so the routes stay thin.
"""
import os
import numpy as np
from fastapi import HTTPException
from app import config as C
from app.state import state


def _tensor_rows():
    """Group the ViT weights the way the decks name them."""
    model = state["model"]
    P = model.P
    groups = []

    def g(name, keys, bullets, one_liner):
        rows = [{"name": k, "shape": list(P[k].shape), "params": int(P[k].size)} for k in keys]
        return {"name": name, "one_liner": one_liner, "bullets": bullets,
                "tensors": rows, "params": sum(r["params"] for r in rows)}

    groups.append(g(
        "Patch embedding — the stamp",
        ["patch.W", "patch.b", "pos"],
        ["Each 8x8 patch is 192 raw numbers. patch.W presses those 192 down to "
         f"{C.D_MODEL} — one vector per patch. This is the vision tokenizer: a "
         "fixed patch recipe plus this learned projection.",
         "pos is the position matrix — 16 learned vectors, one per grid seat, "
         "added so the model knows a patch's place. It is the one real lookup "
         "table in a vision model, and the most consistently trained numbers."],
        "raw pixels -> a token vector, plus where each patch sits"))

    for l in range(C.N_LAYERS):
        p = f"layers.{l}."
        groups.append(g(
            f"Transformer block {l}",
            [p + "ln1.g", p + "ln1.b",
             p + "attn.q.W", p + "attn.k.W", p + "attn.v.W", p + "attn.o.W",
             p + "ln2.g", p + "ln2.b", p + "mlp.1.W", p + "mlp.2.W"],
            (["Attention = every patch asks 'who else matters to me?' (Q asks, K "
              "matches, V shares). The road patch learns from the wheel patch.",
              "The MLP then rebuilds each token into a richer feature — this is "
              "where most of the learned knowledge sits.",
              "LayerNorm keeps the numbers well-behaved before each step."]
             if l == 0 else
             ["Same machinery as block 0, stacked. Depth = the same rooms "
              "repeated — a real ViT-Base does this 12 times."]),
            "attention (patches talk) then MLP (each token is refined)"))

    groups.append(g(
        "Final norm + prediction head",
        ["norm.g", "norm.b", "head.W", "head.b"],
        ["The 16 refined tokens are mean-pooled into ONE image representation, "
         "normalized, then head.W scores it against every class.",
         "Softmax turns those scores into the scoreboard — a belief for every "
         "possible answer that sums to 100%."],
        "16 tokens -> one summary -> a score per class"))
    return groups


def build_anatomy_payload():
    if state["model"] is None:
        raise HTTPException(400, "Train a model first, then look inside.")
    tr = state["training"] or {}
    cfg = state["meta"] or {}
    params = int(sum(v.size for v in state["model"].P.values()))

    def size(name):
        p = f"{C.ARTIFACT_DIR}/{name}"
        return os.path.getsize(p) if os.path.exists(p) else 0

    files = [
        {"name": "model.safetensors", "bytes": size("model.safetensors"),
         "what": "The learned brain — every weight the training loop nudged. "
                 f"{params:,} numbers with HuggingFace-style tensor names.",
         "role": "turns 16 patch tokens into a class score"},
        {"name": "config.json", "bytes": size("config.json"),
         "what": "The architecture card — image size, patch size, hidden width, "
                 "how many blocks and heads, and the class list. Same idea as any "
                 "HF model's config.json.",
         "role": "how to rebuild the model shell before loading the weights"},
        {"name": "classes.json", "bytes": size("classes.json"),
         "what": "The label vocabulary and provenance: which classes, how many "
                 "images, how many patch tokens were seen, holdout accuracy.",
         "role": "what the scoreboard's rows mean and where the data came from"},
    ]

    # one real embedding vector + one q_proj corner, for the 'real numbers' beat
    P = state["model"].P
    embed_sample = [round(float(x), 4) for x in P["pos"][5][:16]]
    q_corner = [[round(float(P["layers.0.attn.q.W"][i, j]), 4) for j in range(6)]
                for i in range(6)]

    return {
        "files": files,
        "training": tr,
        "config": cfg,
        "parameters": params,
        "groups": _tensor_rows(),
        "samples": {"pos_row6": embed_sample, "q_proj_corner": q_corner},
        "scale_note": f"This model has {params:,} learned numbers. A real ViT-Base "
                      "has ~86 million; the largest vision models have billions. "
                      "Same file, same tensor names — only tiny.",
    }
