"""IMG07 — a tiny Vision Transformer, pure NumPy, forward AND backward by hand.

This is the runnable proof of the Part-3 decks: a photo becomes 16 patch
"visual words", those 16 tokens flow through pre-LN transformer blocks, the
prediction head folds them into ONE image representation, and a softmax
scoreboard gives a belief for every class. Training is the supervised loop the
decks show: guess -> compare to the human label -> nudge every number.

No torch. Every gradient here is written out so students can open the file and
see that "training" is just arithmetic repeated a few million times.

Geometry (defaults, see config.py):
    32x32x3 image  ->  8x8 patches on a 4x4 grid  ->  16 patches
    each patch = 8*8*3 = 192 numbers (PATCH_DIM)
    patch projection 192 -> D_MODEL   (the "stamp" / patch embedding)
    + a learned 16xD position matrix   (the one real vision lookup table)
    N_LAYERS pre-LN blocks: multi-head self-attention + MLP (D->FFN->D, GELU)
    mean-pool 16 tokens -> final LayerNorm -> head D -> n_classes
"""
import numpy as np


def gelu(x):
    return 0.5 * x * (1.0 + np.tanh(0.7978845608028654 * (x + 0.044715 * x**3)))


def dgelu(x):
    # derivative of the tanh-approx GELU used above
    c = 0.7978845608028654
    t = np.tanh(c * (x + 0.044715 * x**3))
    dt = (1 - t**2) * c * (1 + 3 * 0.044715 * x**2)
    return 0.5 * (1 + t) + 0.5 * x * dt


def layernorm_fwd(x, g, b, eps=1e-5):
    mu = x.mean(-1, keepdims=True)
    xc = x - mu
    var = (xc**2).mean(-1, keepdims=True)
    inv = 1.0 / np.sqrt(var + eps)
    xn = xc * inv
    out = xn * g + b
    return out, (xn, inv, g)


def layernorm_bwd(dout, cache):
    xn, inv, g = cache
    D = xn.shape[-1]
    dxn = dout * g
    dg = (dout * xn).reshape(-1, D).sum(0)
    db = dout.reshape(-1, D).sum(0)
    dx = (dxn - dxn.mean(-1, keepdims=True) - xn * (dxn * xn).mean(-1, keepdims=True)) * inv
    return dx, dg, db


def softmax(z, axis=-1):
    z = z - z.max(axis, keepdims=True)
    e = np.exp(z)
    return e / e.sum(axis, keepdims=True)


class ViT:
    def __init__(self, patch_dim, d_model, n_layers, n_heads, d_ffn, n_classes,
                 n_patches, seed=0, dtype=np.float32):
        self.PD, self.D, self.L, self.H = patch_dim, d_model, n_layers, n_heads
        self.F, self.C, self.T = d_ffn, n_classes, n_patches
        self.hd = d_model // n_heads
        self.dtype = dtype
        rng = np.random.default_rng(seed)
        s = lambda *sh: (rng.standard_normal(sh) * 0.02).astype(dtype)
        z = lambda *sh: np.zeros(sh, dtype=dtype)
        P = {}
        P["patch.W"] = s(patch_dim, d_model)
        P["patch.b"] = z(d_model)
        P["pos"] = s(n_patches, d_model)
        for l in range(n_layers):
            p = f"layers.{l}."
            P[p + "ln1.g"] = np.ones(d_model, dtype); P[p + "ln1.b"] = z(d_model)
            P[p + "attn.q.W"] = s(d_model, d_model); P[p + "attn.q.b"] = z(d_model)
            P[p + "attn.k.W"] = s(d_model, d_model); P[p + "attn.k.b"] = z(d_model)
            P[p + "attn.v.W"] = s(d_model, d_model); P[p + "attn.v.b"] = z(d_model)
            P[p + "attn.o.W"] = s(d_model, d_model); P[p + "attn.o.b"] = z(d_model)
            P[p + "ln2.g"] = np.ones(d_model, dtype); P[p + "ln2.b"] = z(d_model)
            P[p + "mlp.1.W"] = s(d_model, d_ffn); P[p + "mlp.1.b"] = z(d_ffn)
            P[p + "mlp.2.W"] = s(d_ffn, d_model); P[p + "mlp.2.b"] = z(d_model)
        P["norm.g"] = np.ones(d_model, dtype); P["norm.b"] = z(d_model)
        P["head.W"] = s(d_model, n_classes); P["head.b"] = z(n_classes)
        self.P = P

    # ---- attention for one block ----
    def _attn_fwd(self, h, p):
        B, T, D = h.shape
        q = h @ self.P[p + "attn.q.W"] + self.P[p + "attn.q.b"]
        k = h @ self.P[p + "attn.k.W"] + self.P[p + "attn.k.b"]
        v = h @ self.P[p + "attn.v.W"] + self.P[p + "attn.v.b"]
        H, hd = self.H, self.hd
        qh = q.reshape(B, T, H, hd).transpose(0, 2, 1, 3)
        kh = k.reshape(B, T, H, hd).transpose(0, 2, 1, 3)
        vh = v.reshape(B, T, H, hd).transpose(0, 2, 1, 3)
        scores = qh @ kh.transpose(0, 1, 3, 2) / np.sqrt(hd)   # (B,H,T,T)
        att = softmax(scores, -1)
        oh = att @ vh                                          # (B,H,T,hd)
        o = oh.transpose(0, 2, 1, 3).reshape(B, T, D)
        out = o @ self.P[p + "attn.o.W"] + self.P[p + "attn.o.b"]
        cache = (h, q, k, v, qh, kh, vh, att, oh, o)
        return out, cache

    def _attn_bwd(self, dout, cache, p, G):
        h, q, k, v, qh, kh, vh, att, oh, o = cache
        B, T, D = h.shape
        H, hd = self.H, self.hd
        G[p + "attn.o.W"] = o.reshape(-1, D).T @ dout.reshape(-1, D)
        G[p + "attn.o.b"] = dout.reshape(-1, D).sum(0)
        do = dout @ self.P[p + "attn.o.W"].T                   # (B,T,D)
        doh = do.reshape(B, T, H, hd).transpose(0, 2, 1, 3)    # (B,H,T,hd)
        datt = doh @ vh.transpose(0, 1, 3, 2)                  # (B,H,T,T)
        dvh = att.transpose(0, 1, 3, 2) @ doh                  # (B,H,T,hd)
        # softmax backward
        dscores = att * (datt - (datt * att).sum(-1, keepdims=True))
        dscores /= np.sqrt(hd)
        dqh = dscores @ kh                                     # (B,H,T,hd)
        dkh = dscores.transpose(0, 1, 3, 2) @ qh               # (B,H,T,hd)
        dq = dqh.transpose(0, 2, 1, 3).reshape(B, T, D)
        dk = dkh.transpose(0, 2, 1, 3).reshape(B, T, D)
        dv = dvh.transpose(0, 2, 1, 3).reshape(B, T, D)
        dh = np.zeros_like(h)
        for nm, dz in (("q", dq), ("k", dk), ("v", dv)):
            G[p + f"attn.{nm}.W"] = h.reshape(-1, D).T @ dz.reshape(-1, D)
            G[p + f"attn.{nm}.b"] = dz.reshape(-1, D).sum(0)
            dh += dz @ self.P[p + f"attn.{nm}.W"].T
        return dh

    def forward(self, patches, cache=False):
        """patches: (B, T, PATCH_DIM) already scaled to [0,1]. Returns logits (B,C)."""
        P = self.P
        cch = {}
        x = patches @ P["patch.W"] + P["patch.b"] + P["pos"]
        if cache:
            cch["patches"] = patches
        for l in range(self.L):
            p = f"layers.{l}."
            h1, c1 = layernorm_fwd(x, P[p + "ln1.g"], P[p + "ln1.b"])
            a, ca = self._attn_fwd(h1, p)
            x = x + a
            h2, c2 = layernorm_fwd(x, P[p + "ln2.g"], P[p + "ln2.b"])
            pre = h2 @ P[p + "mlp.1.W"] + P[p + "mlp.1.b"]
            act = gelu(pre)
            m = act @ P[p + "mlp.2.W"] + P[p + "mlp.2.b"]
            x = x + m
            if cache:
                cch[p] = (c1, ca, c2, h2, pre, act)
        pooled = x.mean(1)                                 # (B,D)
        z, cn = layernorm_fwd(pooled, P["norm.g"], P["norm.b"])
        logits = z @ P["head.W"] + P["head.b"]
        if cache:
            cch["pooled"] = pooled; cch["z"] = z; cch["cn"] = cn; cch["xfinal"] = x
            return logits, cch
        return logits

    def loss_and_grad(self, patches, y):
        """Cross-entropy over classes. Returns (loss, grads, probs)."""
        P = self.P
        logits, cch = self.forward(patches, cache=True)
        B = patches.shape[0]
        probs = softmax(logits, -1)
        loss = -np.log(probs[np.arange(B), y] + 1e-12).mean()
        G = {}
        dlogits = probs.copy()
        dlogits[np.arange(B), y] -= 1.0
        dlogits /= B
        z = cch["z"]
        G["head.W"] = z.T @ dlogits
        G["head.b"] = dlogits.sum(0)
        dz = dlogits @ P["head.W"].T
        dpooled, G["norm.g"], G["norm.b"] = layernorm_bwd(dz, cch["cn"])
        dx = np.repeat((dpooled / self.T)[:, None, :], self.T, axis=1)   # mean-pool bwd
        for l in reversed(range(self.L)):
            p = f"layers.{l}."
            c1, ca, c2, h2, pre, act = cch[p]
            # MLP residual
            dm = dx
            G[p + "mlp.2.W"] = act.reshape(-1, self.F).T @ dm.reshape(-1, self.D)
            G[p + "mlp.2.b"] = dm.reshape(-1, self.D).sum(0)
            dact = dm @ P[p + "mlp.2.W"].T
            dpre = dact * dgelu(pre)
            G[p + "mlp.1.W"] = h2.reshape(-1, self.D).T @ dpre.reshape(-1, self.F)
            G[p + "mlp.1.b"] = dpre.reshape(-1, self.F).sum(0)
            dh2 = dpre @ P[p + "mlp.1.W"].T
            dx2, G[p + "ln2.g"], G[p + "ln2.b"] = layernorm_bwd(dh2, c2)
            dx = dx + dx2                          # residual join
            # Attention residual
            dh1 = self._attn_bwd(dx, ca, p, G)
            dxa, G[p + "ln1.g"], G[p + "ln1.b"] = layernorm_bwd(dh1, c1)
            dx = dx + dxa
        # patch projection + pos
        G["pos"] = dx.reshape(-1, self.D).reshape(dx.shape).sum(0)
        patches0 = cch["patches"]
        G["patch.W"] = patches0.reshape(-1, self.PD).T @ dx.reshape(-1, self.D)
        G["patch.b"] = dx.reshape(-1, self.D).sum(0)
        return loss, G, probs


class Adam:
    def __init__(self, params, lr=1e-3, b1=0.9, b2=0.999, eps=1e-8):
        self.lr, self.b1, self.b2, self.eps = lr, b1, b2, eps
        self.m = {k: np.zeros_like(v) for k, v in params.items()}
        self.v = {k: np.zeros_like(v) for k, v in params.items()}
        self.t = 0

    def step(self, params, grads):
        self.t += 1
        for k in params:
            g = grads[k]
            self.m[k] = self.b1 * self.m[k] + (1 - self.b1) * g
            self.v[k] = self.b2 * self.v[k] + (1 - self.b2) * (g * g)
            mh = self.m[k] / (1 - self.b1**self.t)
            vh = self.v[k] / (1 - self.b2**self.t)
            params[k] -= self.lr * mh / (np.sqrt(vh) + self.eps)
