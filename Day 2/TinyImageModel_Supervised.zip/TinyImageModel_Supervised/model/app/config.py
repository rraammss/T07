"""Tiny-ViT dimensions, patch geometry, and artifact paths."""
IMG = 32            # every photo is resized to a 32x32 square (Deck 1)
PATCH = 8           # 8x8 patch  (Deck 2 "a tile is the image's word")
GRID = IMG // PATCH # 4x4 grid
N_PATCHES = GRID * GRID          # 16 patch tokens per image
PATCH_DIM = PATCH * PATCH * 3    # 192 numbers per patch

D_MODEL = 64        # token width  (the decks' "768", tiny)
N_LAYERS = 4        # transformer blocks (the tower)
N_HEADS = 4
D_FFN = 256         # MLP hidden (D -> 4D -> D)

EPOCHS = 120        # many nudges — a small pull must still train, not sit near guessing
BATCH = 16          # small batch => several weight updates per epoch even on ~40 images
LR = 1e-3
HOLDOUT = 0.15      # fraction kept back as the never-trained exam

DATASET_DIR = "/dataset"
TRAIN_DIR = "/dataset/train"     # /dataset/train/<class>/*.png  (SUPERVISED)
ARTIFACT_DIR = "/artifacts"
