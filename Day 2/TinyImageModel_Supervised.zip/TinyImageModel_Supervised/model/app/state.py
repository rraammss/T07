"""In-memory runtime state loaded from the frozen training artifacts."""
state = {"model": None, "classes": None, "meta": None, "training": None}
