"""Run the trained ViT on one image -> the deck's SCOREBOARD.

Returns a belief for every class (softmax), the winning prediction, and — when
the image was a labeled training photo — an automatic =/-!= verdict against the
folder it came from (the folder IS the label, exactly like the decks' check).
"""
import os
import numpy as np
from fastapi import HTTPException
from app import config as C
from app.state import state
from app.vision import softmax
from app.patches import file_to_tokens


def _resolve(filename: str) -> str:
    """Map a request filename to a safe path under /dataset."""
    if filename.startswith("train/"):
        parts = filename.split("/")
        if len(parts) != 3 or ".." in parts:
            raise HTTPException(400, "bad training path")
        path = os.path.join(C.TRAIN_DIR, parts[1], parts[2])
    else:
        if "/" in filename or ".." in filename:
            raise HTTPException(400, "bad filename")
        path = os.path.join(C.DATASET_DIR, filename)
    if not os.path.exists(path):
        raise HTTPException(404, f"image not found: {filename}")
    return path


def infer(filename: str, expected: str = None) -> dict:
    if state["model"] is None:
        raise HTTPException(400, "No trained model yet. Train first.")
    path = _resolve(filename)
    classes = state["classes"]
    tokens = file_to_tokens(path)[None]                 # (1,16,192)
    logits = state["model"].forward(tokens)[0]
    probs = softmax(logits)
    order = np.argsort(-probs)
    board = [{"label": classes[i], "belief": round(float(probs[i]) * 100, 1)} for i in order]
    pred = classes[int(order[0])]
    # auto-label training photos by their folder
    if expected is None and filename.startswith("train/"):
        expected = filename.split("/")[1]
    result = {"prediction": pred, "belief": board[0]["belief"], "scoreboard": board,
              "classes": classes, "patch_tokens": C.N_PATCHES}
    if expected:
        result["expected"] = expected
        result["match"] = (expected == pred)
    tr = state.get("training") or {}
    result["split"] = (tr.get("split") or {}).get(filename)   # 'train' | 'test' | None
    return result
