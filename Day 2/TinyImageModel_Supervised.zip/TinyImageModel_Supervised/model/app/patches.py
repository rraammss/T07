"""Turn a photo into 16 patch tokens — the Deck 1 -> Deck 2 pipeline in code.

    load  : any image file -> 32x32 RGB float array in [0,1]
    patchify : (32,32,3) -> (16, 192)   4x4 grid of 8x8 patches, each flattened

The order is fixed and deterministic (row-major over the grid, then row-major
over pixels inside a patch, channels last) — this fixed recipe is the vision
equivalent of a frozen tokenizer: the same picture always yields the same 16
tokens in the same order.
"""
import numpy as np
from PIL import Image
from app.config import IMG, PATCH, GRID, PATCH_DIM


def load(path: str) -> np.ndarray:
    img = Image.open(path).convert("RGB").resize((IMG, IMG))
    return (np.asarray(img, dtype=np.float32) / 255.0)     # (32,32,3) in [0,1]


def patchify(arr: np.ndarray) -> np.ndarray:
    """(IMG,IMG,3) -> (N_PATCHES, PATCH_DIM)."""
    out = np.empty((GRID * GRID, PATCH_DIM), dtype=np.float32)
    n = 0
    for gy in range(GRID):
        for gx in range(GRID):
            tile = arr[gy * PATCH:(gy + 1) * PATCH, gx * PATCH:(gx + 1) * PATCH, :]
            out[n] = tile.reshape(-1)
            n += 1
    return out


def file_to_tokens(path: str) -> np.ndarray:
    return patchify(load(path))
