"""IMG07 model-service HTTP entry point. Routes stay thin; math lives in modules."""
import glob
import os
from fastapi import FastAPI
from app import config as C
from app.schemas import TrainReq, InferReq
from app.state import state
from app.training import start_training, train_blocking, load_artifacts, progress, summary
from app.inference import infer
from app.inspector import build_anatomy_payload

app = FastAPI(title="IMG07")

@app.post("/train")
def train(req: TrainReq):
    return start_training(req.epochs)

@app.get("/train/status")
def train_status():
    return {**progress(), "summary": summary()}

@app.post("/invalidate")
def invalidate():
    state.update({"model": None, "classes": None, "meta": None, "training": None})
    removed = []
    for name in ("model.safetensors", "config.json", "classes.json"):
        p = f"{C.ARTIFACT_DIR}/{name}"
        if os.path.exists(p):
            os.remove(p); removed.append(name)
    return {"invalidated": True, "removed": removed}

@app.post("/infer")
def do_infer(req: InferReq):
    return infer(req.filename, req.expected)

@app.get("/anatomy")
def anatomy():
    return build_anatomy_payload()

@app.get("/splits")
def splits():
    """Which exact photos were trained on vs held back, plus both accuracies."""
    tr = state["training"] or {}
    return {"split": tr.get("split", {}),
            "train_acc": tr.get("train_acc"), "holdout_acc": tr.get("holdout_acc"),
            "trained_on": tr.get("trained_on"), "holdout": tr.get("holdout"),
            "n_classes": len(tr.get("classes") or [])}

@app.get("/status")
def status():
    n = len(glob.glob(f"{C.TRAIN_DIR}/*/*"))
    return {"trained": state["model"] is not None, "labeled_images": n,
            "classes": state["classes"], "training": state["training"]}

load_artifacts()
