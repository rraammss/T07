"""Supervised training loop + artifact creation/loading.

This is the runnable version of the decks' training story:
  read a labeled photo -> cut it into 16 patch tokens -> guess a class ->
  compare to the human label -> nudge every number -> repeat.

Two things are written when training finishes (the "what survives" beat):
  model.safetensors : every learned number, HuggingFace-style tensor names
  config.json       : the architecture card (hidden_size, num_layers, patch...)
  classes.json      : the label vocabulary + where the data came from
"""
import glob
import json
import math
import os
import threading
import numpy as np
from fastapi import HTTPException
from safetensors.numpy import save_file, load_file
from app import config as C
from app.state import state
from app.vision import ViT, Adam
from app.patches import file_to_tokens

_PROG = {"running": False, "epoch": 0, "epochs": 0, "loss": None, "acc": None,
         "seen": 0, "done": False, "history": []}


def progress():
    return dict(_PROG)


def _load_dataset():
    """Read /dataset/train/<class>/*.png into tokens X and labels y."""
    manifest_path = f"{C.TRAIN_DIR}/manifest.json"
    if not os.path.exists(manifest_path):
        raise HTTPException(400, "No training data yet. Pull a Hugging Face dataset first.")
    meta = json.load(open(manifest_path))
    classes = meta["classes"]
    if len(classes) < 2:
        raise HTTPException(400, "A model needs at least 2 classes — belief needs a rival to spread between.")
    X, y, files = [], [], []
    for ci, cls in enumerate(classes):
        for f in sorted(glob.glob(f"{C.TRAIN_DIR}/{cls}/*")):
            if os.path.isfile(f):
                try:
                    X.append(file_to_tokens(f)); y.append(ci); files.append(f)
                except Exception:
                    continue
    if len(X) < 10:
        raise HTTPException(400, f"Only {len(X)} usable images — pull more rows before training.")
    return np.stack(X).astype(np.float32), np.array(y), classes, meta, files


def _auto_epochs(n_tr):
    """Pick epochs so total weight updates land near a fixed budget — a small
    pull trains hard (many passes), a big pull stays classroom-fast. The budget
    is set so a normal 20-40/class pull reaches a real (not near-guessing) score."""
    batches_per_epoch = max(1, math.ceil(n_tr / C.BATCH))
    return int(min(300, max(20, round(460 / batches_per_epoch))))


def _train_worker(epochs):
    try:
        X, y, classes, meta, files = _load_dataset()
    except HTTPException as e:
        _PROG.update(running=False, done=True, error=e.detail); return
    rng = np.random.default_rng(0)
    n = len(X)
    perm = rng.permutation(n)
    X, y = X[perm], y[perm]
    files = [_rel(files[i]) for i in perm]
    n_hold = max(1, int(n * C.HOLDOUT))
    Xtr, ytr, Xho, yho = X[n_hold:], y[n_hold:], X[:n_hold], y[:n_hold]
    files_ho, files_tr = files[:n_hold], files[n_hold:]
    # which exact photos the model saw vs was examined on — keyed like the gallery
    split = {f: "test" for f in files_ho}
    split.update({f: "train" for f in files_tr})

    if not epochs:
        epochs = _auto_epochs(len(Xtr))

    model = ViT(C.PATCH_DIM, C.D_MODEL, C.N_LAYERS, C.N_HEADS, C.D_FFN,
                len(classes), C.N_PATCHES, seed=0)
    opt = Adam(model.P, lr=C.LR)

    def holdout_acc():
        return float((model.forward(Xho).argmax(1) == yho).mean())

    def train_acc():
        return float((model.forward(Xtr).argmax(1) == ytr).mean())

    _PROG.update(running=True, done=False, error=None, epochs=epochs,
                 epoch=0, seen=0, history=[], loss=None,
                 acc=holdout_acc(), classes=classes,
                 patch_tokens_per_epoch=len(Xtr) * C.N_PATCHES)
    seen = 0
    for ep in range(epochs):
        idx = rng.permutation(len(Xtr))
        last = 0.0
        for s in range(0, len(Xtr), C.BATCH):
            b = idx[s:s + C.BATCH]
            loss, G, _ = model.loss_and_grad(Xtr[b], ytr[b])
            opt.step(model.P, G)
            last = float(loss); seen += len(b)
        acc = holdout_acc()
        tacc = train_acc()
        _PROG.update(epoch=ep + 1, loss=round(last, 4), acc=round(acc, 4),
                     train_acc=round(tacc, 4), seen=seen)
        _PROG["history"].append({"epoch": ep + 1, "loss": round(last, 4),
                                 "acc": round(acc, 4), "train_acc": round(tacc, 4)})

    tokens_seen = seen * C.N_PATCHES               # every image = 16 patch tokens
    _save_artifacts(model, classes, meta, len(X), len(Xtr), len(Xho),
                    epochs, tokens_seen, round(holdout_acc(), 4),
                    round(train_acc(), 4), split)
    load_artifacts()
    _PROG.update(running=False, done=True)


def _rel(path):
    """Absolute /dataset/train/<cls>/<file> -> gallery key 'train/<cls>/<file>'."""
    return "train/" + "/".join(path.rstrip("/").split("/")[-2:])


def _save_artifacts(model, classes, meta, n_all, n_tr, n_ho, epochs, tokens_seen, acc, tr_acc, split):
    tensors = {k: v.astype(np.float32) for k, v in model.P.items()}
    save_file(tensors, f"{C.ARTIFACT_DIR}/model.safetensors")
    params = int(sum(v.size for v in model.P.values()))
    cfg = {
        "architecture": "TinyViT",
        "image_size": C.IMG, "patch_size": C.PATCH,
        "num_patches": C.N_PATCHES, "patch_dim": C.PATCH_DIM,
        "hidden_size": C.D_MODEL, "num_hidden_layers": C.N_LAYERS,
        "num_attention_heads": C.N_HEADS, "intermediate_size": C.D_FFN,
        "num_classes": len(classes), "id2label": {str(i): c for i, c in enumerate(classes)},
        "parameters": params,
    }
    json.dump(cfg, open(f"{C.ARTIFACT_DIR}/config.json", "w"), indent=2)
    training = {
        "classes": classes, "source": meta.get("source", "unknown"),
        "images": n_all, "trained_on": n_tr, "holdout": n_ho,
        "epochs": epochs, "patches_per_image": C.N_PATCHES,
        "patch_tokens": tokens_seen, "holdout_acc": acc, "train_acc": tr_acc,
        "split": split, "parameters": params,
    }
    json.dump(training, open(f"{C.ARTIFACT_DIR}/classes.json", "w"), indent=2)


def start_training(epochs=None):
    if _PROG["running"]:
        raise HTTPException(409, "Training already in progress.")
    ep = int(epochs) if epochs else None      # None => auto-size to the dataset
    # verify a dataset exists before launching the thread (fail fast, clear msg)
    _load_dataset()
    t = threading.Thread(target=_train_worker, args=(ep,), daemon=True)
    _PROG.update(running=True, done=False, error=None)
    t.start()
    return {"started": True, "epochs": ep or "auto"}


def train_blocking(epochs=None):
    """Synchronous train — used by tests and CLI."""
    _train_worker(int(epochs) if epochs else None)
    if _PROG.get("error"):
        raise HTTPException(400, _PROG["error"])
    return summary()


def summary():
    p = f"{C.ARTIFACT_DIR}/classes.json"
    return json.load(open(p)) if os.path.exists(p) else None


def load_artifacts() -> bool:
    try:
        cfg = json.load(open(f"{C.ARTIFACT_DIR}/config.json"))
        tr = json.load(open(f"{C.ARTIFACT_DIR}/classes.json"))
        tensors = load_file(f"{C.ARTIFACT_DIR}/model.safetensors")
        model = ViT(C.PATCH_DIM, cfg["hidden_size"], cfg["num_hidden_layers"],
                    cfg["num_attention_heads"], cfg["intermediate_size"],
                    cfg["num_classes"], cfg["num_patches"], seed=0)
        for k in model.P:
            model.P[k] = tensors[k]
        state["model"] = model
        state["classes"] = tr["classes"]
        state["meta"] = cfg
        state["training"] = tr
        return True
    except Exception:
        return False
