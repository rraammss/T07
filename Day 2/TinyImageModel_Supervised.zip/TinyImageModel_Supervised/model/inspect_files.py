"""Walk the trained artifacts on the command line (live in class):
    docker compose exec model python inspect_files.py
"""
import json, os
from safetensors.numpy import load_file
A = "/artifacts"
if not os.path.exists(f"{A}/model.safetensors"):
    print("No trained model yet. Train first."); raise SystemExit
cfg = json.load(open(f"{A}/config.json"))
tr = json.load(open(f"{A}/classes.json"))
print("=" * 60); print("config.json  — the architecture card"); print("=" * 60)
for k, v in cfg.items():
    if k != "id2label": print(f"  {k:22s} {v}")
print("\n" + "=" * 60); print("classes.json — labels + provenance"); print("=" * 60)
for k, v in tr.items(): print(f"  {k:18s} {v}")
print("\n" + "=" * 60); print("model.safetensors — the learned numbers"); print("=" * 60)
t = load_file(f"{A}/model.safetensors")
total = 0
for name, arr in t.items():
    total += arr.size
    print(f"  {name:26s} {str(list(arr.shape)):14s} {arr.size:>8,} params")
print(f"\n  TOTAL {total:,} learned numbers")
