from pydantic import BaseModel
from typing import Optional

class DatasetImport(BaseModel):
    url: str = ""          # blank => default cifar10
    per_class: int = 40

class Infer(BaseModel):
    filename: str
    expected: Optional[str] = None

class Ask(BaseModel):
    filename: str
    question: str = "What is in this image?"
    model: str = "img07"   # 'img07' (ours) or 'openai'
