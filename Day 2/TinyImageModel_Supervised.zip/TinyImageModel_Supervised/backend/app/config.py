"""Runtime configuration for the backend orchestrator."""
import os
MODEL_URL = os.environ.get("MODEL_URL", "http://model:9000")
OPENAI_KEY = os.environ.get("OPENAI_API_KEY", "")
OPENAI_MODEL = os.environ.get("OPENAI_MODEL", "gpt-4o-mini")
DATASET_DIR = "/dataset"
TRAIN_DIR = "/dataset/train"
HF_ROWS_URL = "https://datasets-server.huggingface.co/rows"
HF_SPLITS_URL = "https://datasets-server.huggingface.co/splits"
