"""Pull a SUPERVISED image dataset from Hugging Face into /dataset/train.

Requirement: training data comes from Hugging Face only — either the default
(uoft-cs/cifar10, a 5-class classroom slice matching the decks) or any HF
image-classification dataset id/URL the user pastes.

Every image is downloaded and saved under /dataset/train/<class>/*.png. The
folder name IS the human label — that is what makes this SUPERVISED. A
manifest.json records the class list and the source.
"""
import io
import json
import os
import re
import shutil
import time
import requests
from fastapi import HTTPException
from PIL import Image
from app.config import HF_ROWS_URL, HF_SPLITS_URL, TRAIN_DIR

# Default classroom dataset: 5 CIFAR-10 classes mapped to the decks' labels.
DEFAULT_DATASET = "uoft-cs/cifar10"
CIFAR_MAP = {8: "boat", 1: "car", 9: "truck", 5: "dog", 2: "bird"}  # ship/automobile/...
CIFAR_CONFIG = "plain_text"


def _dataset_id(url_or_id: str) -> str:
    s = (url_or_id or "").strip()
    if not s:
        return DEFAULT_DATASET
    s = re.sub(r"^https?://huggingface\.co/datasets/", "", s)
    s = s.split("?")[0].strip("/")
    if not re.match(r"^[\w.\-]+/[\w.\-]+$", s):
        raise HTTPException(400, f"'{url_or_id}' is not a HF dataset id like owner/name.")
    return s


def _discover(dataset: str):
    """Return (config, split, image_col, label_col, label_names) for a dataset."""
    data = _hf_get(HF_SPLITS_URL, {"dataset": dataset}, timeout=25, what="the split list")
    splits = data.get("splits", [])
    if not splits:
        raise HTTPException(502, f"Hugging Face returned no splits for '{dataset}'.")
    pick = next((s for s in splits if s.get("split") == "train"), splits[0])
    config, split = pick["config"], pick["split"]
    # sniff columns from the first row
    row = _rows(dataset, config, split, 0, 1)
    if not row:
        raise HTTPException(502, f"No rows returned for '{dataset}'.")
    feats = row["features"]
    image_col = next((f["name"] for f in feats if _is_image(f)), None)
    label_col = next((f["name"] for f in feats if _is_label(f)), None)
    if not image_col or not label_col:
        cols = ", ".join(f["name"] for f in feats)
        raise HTTPException(400,
            f"'{dataset}' has images but no label column (found: {cols}). "
            f"That makes it UNSUPERVISED — there's no human label for the model to be graded against, "
            f"so it can't learn to classify. Pick a labeled classification set: on huggingface.co/datasets "
            f"use the filter Tasks -> Image Classification (not just modality: image). "
            f"Known to work here (2-12 classes): uoft-cs/cifar10, ylecun/mnist, AI-Lab-Makerere/beans, cats_vs_dogs.")
    names = _label_names(feats, label_col)
    return config, split, image_col, label_col, names


def _is_image(feat):
    t = feat.get("type", {})
    return t.get("_type") == "Image" or t.get("dtype") == "image"


def _is_label(feat):
    return feat.get("type", {}).get("_type") == "ClassLabel"


def _label_names(feats, label_col):
    for f in feats:
        if f["name"] == label_col:
            return f.get("type", {}).get("names")
    return None


def _hf_get(url, params, timeout, what, tries=2):
    """GET the HF datasets-server with retries and plain-language failures.

    The HF dataset viewer is often slow to warm up on the first request and
    occasionally rate-limits — a short retry usually clears it. Every failure
    mode gets its own readable message instead of a raw connection-pool dump.
    """
    last = ""
    for i in range(tries):
        try:
            r = requests.get(url, params=params, timeout=timeout)
            if r.status_code == 404:
                raise HTTPException(404, f"Hugging Face has no {what} for this dataset (404) — double-check the owner/name.")
            r.raise_for_status()
            return r.json()
        except requests.Timeout:
            last = (f"Hugging Face's dataset viewer didn't answer within {timeout}s while fetching {what}. "
                    f"Its server is often slow to warm up on the first request (or briefly rate-limited).")
        except requests.ConnectionError:
            last = (f"Couldn't reach Hugging Face while fetching {what} — check your internet connection, "
                    f"DNS, or a proxy/firewall between you and huggingface.co.")
        except requests.HTTPError as e:
            code = getattr(e.response, "status_code", "?")
            raise HTTPException(502, f"Hugging Face returned HTTP {code} while fetching {what}.")
        if i < tries - 1:
            time.sleep(1.5 * (i + 1))
    raise HTTPException(504, last + f" Tried {tries}×. Wait a few seconds and pull again, "
                                   f"or try a smaller count or a different dataset.")


def _rows(dataset, config, split, offset, length):
    return _hf_get(HF_ROWS_URL, {"dataset": dataset, "config": config,
                   "split": split, "offset": offset, "length": length},
                   timeout=40, what="image rows")


def _image_url(cell):
    if isinstance(cell, dict):
        return cell.get("src") or cell.get("url")
    return cell if isinstance(cell, str) and cell.startswith("http") else None


def _download_image(url) -> Image.Image:
    r = requests.get(url, timeout=30)
    r.raise_for_status()
    return Image.open(io.BytesIO(r.content)).convert("RGB")


def _reset_train_dir():
    if os.path.isdir(TRAIN_DIR):
        shutil.rmtree(TRAIN_DIR)
    os.makedirs(TRAIN_DIR, exist_ok=True)


def import_dataset(url_or_id: str, per_class: int) -> dict:
    dataset = _dataset_id(url_or_id)
    per_class = max(5, min(int(per_class), 200))

    if dataset == DEFAULT_DATASET:
        config, split = CIFAR_CONFIG, "train"
        image_col, label_col = "img", "label"
        wanted = CIFAR_MAP                       # int -> class name (5 chosen)
        classes = list(dict.fromkeys(CIFAR_MAP.values()))
    else:
        config, split, image_col, label_col, names = _discover(dataset)
        if not names:
            raise HTTPException(400, f"'{dataset}' has no named labels to use as folders.")
        if not (2 <= len(names) <= 12):
            raise HTTPException(400, f"'{dataset}' has {len(names)} classes — use one with 2 to 12.")
        wanted = {i: _slug(n) for i, n in enumerate(names)}
        classes = [_slug(n) for n in names]

    _reset_train_dir()
    counts = {c: 0 for c in classes}
    for c in classes:
        os.makedirs(f"{TRAIN_DIR}/{c}", exist_ok=True)
    target_total = per_class * len(classes)
    saved = offset = 0
    PAGE = 60
    while saved < target_total and offset < 5000:
        payload = _rows(dataset, config, split, offset, PAGE)
        rows = payload.get("rows", [])
        if not rows:
            break
        for item in rows:
            row = item.get("row", {})
            lab = row.get(label_col)
            if lab not in wanted:
                continue
            cls = wanted[lab]
            if counts[cls] >= per_class:
                continue
            url = _image_url(row.get(image_col))
            if not url:
                continue
            try:
                img = _download_image(url).resize((32, 32))
                img.save(f"{TRAIN_DIR}/{cls}/img_{counts[cls]:04d}.png")
                counts[cls] += 1; saved += 1
            except Exception:
                continue
        offset += PAGE

    classes = [c for c in classes if counts[c] > 0]
    if len(classes) < 2:
        raise HTTPException(502, "Could not download enough labeled images. Try again or a different dataset.")
    manifest = {"classes": classes, "source": dataset, "per_class_target": per_class,
                "counts": counts, "patches_per_image": 16}
    json.dump(manifest, open(f"{TRAIN_DIR}/manifest.json", "w"), indent=2)
    return {"source": dataset, "classes": classes, "counts": counts,
            "images": saved, "patch_tokens": saved * 16, "patches_per_image": 16}


def gallery() -> dict:
    """List every downloaded training image with its class label."""
    mpath = f"{TRAIN_DIR}/manifest.json"
    if not os.path.exists(mpath):
        return {"classes": [], "images": [], "source": None, "count": 0}
    manifest = json.load(open(mpath))
    imgs = []
    for cls in manifest["classes"]:
        d = f"{TRAIN_DIR}/{cls}"
        if os.path.isdir(d):
            for f in sorted(os.listdir(d)):
                if f.lower().endswith((".png", ".jpg", ".jpeg")):
                    imgs.append({"file": f"train/{cls}/{f}", "cls": cls})
    return {"classes": manifest["classes"], "source": manifest["source"],
            "count": len(imgs), "images": imgs, "counts": manifest.get("counts", {})}


def clear() -> dict:
    if os.path.isdir(TRAIN_DIR):
        shutil.rmtree(TRAIN_DIR)
    os.makedirs(TRAIN_DIR, exist_ok=True)
    return {"cleared": True}


def _slug(name: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", str(name).lower()).strip("_") or "class"
