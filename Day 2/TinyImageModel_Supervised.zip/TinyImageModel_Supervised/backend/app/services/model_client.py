"""All calls from the backend orchestrator to the IMG07 model service."""
import requests
from fastapi import HTTPException
from app.config import MODEL_URL

def _post(path, **kw):
    r = requests.post(f"{MODEL_URL}{path}", timeout=kw.pop("timeout", 120), **kw)
    if r.status_code != 200:
        raise HTTPException(r.status_code, r.json().get("detail", "model error"))
    return r.json()

def _get(path, timeout=30):
    r = requests.get(f"{MODEL_URL}{path}", timeout=timeout)
    if r.status_code != 200:
        raise HTTPException(r.status_code, r.json().get("detail", "model error"))
    return r.json()

def invalidate():
    try: requests.post(f"{MODEL_URL}/invalidate", timeout=10)
    except requests.RequestException: pass

def train(epochs=None):   return _post("/train", json={"epochs": epochs})
def train_status():       return _get("/train/status")
def infer(filename, expected=None): return _post("/infer", json={"filename": filename, "expected": expected})
def anatomy():            return _get("/anatomy")
def splits():             return _get("/splits")
def status():
    try: return _get("/status", timeout=5)
    except Exception: return {"trained": False, "labeled_images": 0}
