"""IMG07 backend/orchestrator API — thin routes; logic lives in services."""
import base64
import os
import requests
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from app.config import OPENAI_KEY, OPENAI_MODEL, TRAIN_DIR, DATASET_DIR
from app.schemas import DatasetImport, Infer, Ask
from app.services import datasets, model_client

app = FastAPI(title="IMG07 backend")


# ---------- training data (Hugging Face only) ----------
@app.post("/api/datasets/import")
def import_dataset(req: DatasetImport):
    result = datasets.import_dataset(req.url, req.per_class)
    model_client.invalidate()
    return result

@app.get("/api/datasets/gallery")
def gallery():
    return datasets.gallery()

@app.delete("/api/datasets")
def clear_dataset():
    out = datasets.clear(); model_client.invalidate(); return out


# ---------- train ----------
@app.post("/api/train")
def train():
    return model_client.train()

@app.get("/api/train/status")
def train_status():
    return model_client.train_status()


# ---------- inference ----------
@app.post("/api/infer")
def infer(req: Infer):
    return model_client.infer(req.filename, req.expected)

@app.post("/api/ask")
def ask(req: Ask):
    if req.model == "img07":
        # our trained model can only answer with its scoreboard
        r = model_client.infer(req.filename, None)
        return {"model": "IMG07-Vision", "answer": None, "scoreboard": r["scoreboard"],
                "prediction": r["prediction"], "belief": r["belief"], "classes": r["classes"]}
    if req.model == "openai":
        if not OPENAI_KEY:
            raise HTTPException(400, "OPENAI_API_KEY is not set in .env")
        data_uri, nbytes, nb64 = _image_data_uri(req.filename)
        text = req.question + " Answer in one short sentence."
        payload = {"model": OPENAI_MODEL, "messages": [{"role": "user", "content": [
            {"type": "text", "text": text},
            {"type": "image_url", "image_url": {"url": data_uri}}]}]}
        r = requests.post("https://api.openai.com/v1/chat/completions",
                          headers={"Authorization": f"Bearer {OPENAI_KEY}"}, json=payload, timeout=60)
        if r.status_code != 200:
            raise HTTPException(r.status_code, f"OpenAI: {r.text[:200]}")
        # the SAME request, with the giant base64 blob truncated so students can read it
        preview_uri = data_uri[:64] + f"\u2026\u276e{nb64:,} base64 chars \u2014 the whole image, inlined as text\u276f"
        request_preview = {
            "endpoint": "POST https://api.openai.com/v1/chat/completions",
            "how_the_image_is_sent": "base64 data-URI inlined in the JSON body — NOT a file upload",
            "image_bytes": nbytes, "base64_chars": nb64,
            "body": {"model": OPENAI_MODEL, "messages": [{"role": "user", "content": [
                {"type": "text", "text": text},
                {"type": "image_url", "image_url": {"url": preview_uri}}]}]},
        }
        return {"model": OPENAI_MODEL,
                "answer": r.json()["choices"][0]["message"]["content"].strip(),
                "request": request_preview}
    raise HTTPException(400, "model must be 'img07' or 'openai'")


# ---------- look inside ----------
@app.get("/api/anatomy")
def anatomy():
    return model_client.anatomy()

@app.get("/api/splits")
def splits():
    return model_client.splits()


# ---------- status + image serving ----------
@app.get("/api/status")
def status():
    return {**model_client.status(), "openai_key": bool(OPENAI_KEY),
            "openai_model": OPENAI_MODEL}

@app.get("/api/image")
def image(path: str):
    fp = _safe_path(path)
    return FileResponse(fp)


def _safe_path(path: str) -> str:
    if path.startswith("train/"):
        parts = path.split("/")
        if len(parts) != 3 or ".." in parts:
            raise HTTPException(400, "bad path")
        fp = os.path.join(TRAIN_DIR, parts[1], parts[2])
    else:
        if "/" in path or ".." in path:
            raise HTTPException(400, "bad path")
        fp = os.path.join(DATASET_DIR, path)
    if not os.path.exists(fp):
        raise HTTPException(404, "not found")
    return fp


def _image_data_uri(path: str):
    fp = _safe_path(path)
    raw = open(fp, "rb").read()
    b = base64.b64encode(raw).decode()
    ext = "png" if fp.lower().endswith("png") else "jpeg"
    return f"data:image/{ext};base64,{b}", len(raw), len(b)
