const $ = id => document.getElementById(id);
const api = async (path, opts = {}) => {
  const r = await fetch("/api" + path, opts);
  const body = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(typeof body.detail === "string" ? body.detail : JSON.stringify(body.detail || body));
  return body;
};
const imgUrl = file => "/api/image?path=" + encodeURIComponent(file);

let STATE = { openai: false, trained: false, sel: null };
let SPLIT = {};                 // 'train/<cls>/<file>' -> 'train' | 'test'
let ACC = {};                   // { train, hold, trainN, holdN }

async function ensureSplits() {
  if (!STATE.trained) { SPLIT = {}; ACC = {}; return; }
  try {
    const s = await api("/splits");
    SPLIT = s.split || {};
    ACC = { train: s.train_acc, hold: s.holdout_acc, trainN: s.trained_on, holdN: s.holdout, nClasses: s.n_classes };
  } catch { SPLIT = {}; ACC = {}; }
}

function renderAccTiles() {
  if (ACC.train == null || ACC.hold == null) { $("accCard").style.display = "none"; return; }
  const tr = Math.round(ACC.train * 100), ho = Math.round(ACC.hold * 100);
  $("accCard").style.display = "block";
  $("accTrain").textContent = tr + "%";
  $("accHold").textContent = ho + "%";
  $("accTrainN").textContent = `${ACC.trainN} photos it studied`;
  $("accHoldN").textContent = `${ACC.holdN} photos it never saw`;
  const chance = ACC.nClasses ? Math.round(100 / ACC.nClasses) : 20;
  const gap = tr - ho;
  let msg;
  if (tr < chance + 18) {
    msg = `Both scores sit near the <b>~${chance}%</b> you'd get by pure guessing across ${ACC.nClasses || "the"} classes — the model is <b>undertrained</b>. It hasn't even learned its own training photos yet (a memorizing model would score high on the left). This is the number to lift first: <b>more images and more epochs</b>.`;
  } else if (gap >= 12) {
    msg = `That <b>${gap}-point gap</b> is the model leaning on <b>memory</b> — it does better on photos it already saw than on new ones (overfitting). Closing the gap, mostly with <b>more images</b>, is what <b>generalizing</b> means.`;
  } else if (ho >= chance + 25 || tr >= 60) {
    msg = `Strong on both and close together — the model isn't just memorizing, it's <b>generalizing</b> to new photos about as well as to studied ones. That's the goal. 🎯`;
  } else {
    msg = `Close together, so it's <b>not just memorizing</b> — but both scores are still modest, so there's plenty of room to grow. <b>More images per class</b> will lift both.`;
  }
  const noisy = (ACC.holdN || 0) < 60;
  const note = noisy
    ? `<div class="jumpy">Keep in mind: the held-out score is graded on only <b>${ACC.holdN} photos</b>, so it <b>bounces around</b> — one photo is worth about ${Math.round(100 / (ACC.holdN || 1))}%. Watch the <b>trend</b> as you add images, not any single number.</div>`
    : "";
  $("gapNote").innerHTML = msg + note;
}

function show(tab) {
  for (const t of ["train", "infer", "anat"]) {
    $(t).classList.toggle("hide", t !== tab);
    $("tab" + t[0].toUpperCase() + t.slice(1)).classList.toggle("on", t === tab);
  }
  if (tab === "infer") loadInferGallery();
  if (tab === "anat") loadAnatomy();
}

async function refresh() {
  try {
    const s = await api("/status");
    STATE.openai = !!s.openai_key;
    STATE.trained = !!s.trained;
    $("pill").textContent = s.trained ? "model ready" : (s.labeled_images ? "dataset ready" : "no dataset");
    $("tabInfer").disabled = !s.trained;
    $("tabAnat").disabled = !s.trained;
    $("btnAsk").disabled = !STATE.openai;
    if (!STATE.openai) $("oaiMeta").textContent = "OpenAI key not set — add OPENAI_API_KEY to .env and restart to enable side B.";
    await ensureSplits();
    // if a dataset already exists on disk, show it
    const g = await api("/datasets/gallery");
    if (g.count) { renderGallery("gallery", "galWrap", "galCount", g, false); $("btnTrain").disabled = false; }
  } catch (e) { $("pill").textContent = "offline"; }
}

/* ---------------- TRAIN TAB ---------------- */
async function pull(urlId, perId, btnId) {
  urlId = urlId || "dsUrl"; perId = perId || "perClass"; btnId = btnId || "btnPull";
  const url = $(urlId).value.trim();
  const per = +$(perId).value;
  const btn = $(btnId), label = btn.textContent;
  btn.disabled = true; btn.textContent = "Pulling…";
  const t0 = Date.now();
  const tick = () => {
    const s = ((Date.now() - t0) / 1000).toFixed(1);
    $("trainOut").innerHTML = `<span class="warn">Contacting Hugging Face… ${s}s</span>\n` +
      `  • Downloading the images.\n` +
      `  • Resizing each one to <b>32 × 32 pixels</b> — the model's fixed input size (Deck 1's “preferred square”).\n` +
      `  • The HF viewer can be slow to warm up on the first request.`;
  };
  tick(); const timer = setInterval(tick, 100);
  try {
    const r = await api("/datasets/import", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url, per_class: per })
    });
    clearInterval(timer);
    const took = ((Date.now() - t0) / 1000).toFixed(1);
    const g = await api("/datasets/gallery");
    renderGallery("gallery", "galWrap", "galCount", g, false);
    $("btnTrain").disabled = false;
    $("trainOut").innerHTML =
      `<span class="ok">Downloaded ${r.images} labeled images (${r.classes.join(", ")}) in ${took}s.</span>\nClick Train the model.`;
    $("galWrap").scrollIntoView({ behavior: "smooth", block: "center" });
    refresh();
  } catch (e) {
    clearInterval(timer);
    $("trainOut").innerHTML = `<span class="warn">${e.message}</span>`;
  } finally {
    clearInterval(timer); btn.disabled = false; btn.textContent = label;
  }
}

function renderGallery(galId, wrapId, countId, g, selectable) {
  $(wrapId).classList.remove("hide");
  $(countId).textContent = `${g.count} labeled images · ${g.classes.map(c => c + " (" + (g.counts[c] || 0) + ")").join(" · ")}`;
  $(galId).innerHTML = g.images.map(im => {
    const sp = SPLIT[im.file];
    const tag = sp ? `<div class="tag ${sp}">${sp === "test" ? "TEST" : "TRAIN"}</div>` : "";
    return `<div class="thumb" data-file="${im.file}" data-cls="${im.cls}"${selectable ? ` onclick="selectImg(this)"` : ""}>
       <img loading="lazy" src="${imgUrl(im.file)}">${tag}<div class="cls">${im.cls}</div></div>`;
  }).join("");
}

async function train() {
  $("btnTrain").disabled = true;
  $("trainOut").innerHTML = "Starting…";
  try {
    await api("/train", { method: "POST" });
  } catch (e) { $("trainOut").innerHTML = `<span class="warn">${e.message}</span>`; $("btnTrain").disabled = false; return; }
  poll();
}

async function poll() {
  let s;
  try { s = await api("/train/status"); } catch { setTimeout(poll, 700); return; }
  if (s.error) { $("trainOut").innerHTML = `<span class="warn">${s.error}</span>`; $("btnTrain").disabled = false; return; }
  const line = `epoch ${s.epoch}/${s.epochs}` + (s.loss != null ? ` · loss ${s.loss}` : "") +
    (s.train_acc != null ? ` · trained-on ${(s.train_acc * 100).toFixed(0)}%` : "") +
    (s.acc != null ? ` · held-out ${(s.acc * 100).toFixed(0)}%` : "");
  if (!s.done) {
    $("trainOut").innerHTML = `<span class="warn">training…</span>\n${line}\npatch tokens per pass: ${(s.patch_tokens_per_epoch || 0).toLocaleString()}`;
    setTimeout(poll, 600); return;
  }
  const sm = s.summary || {};
  const perPass = (sm.trained_on || 0) * (sm.patches_per_image || 16);
  const trainPct = Math.round((sm.train_acc || 0) * 100);
  const holdPct = Math.round((sm.holdout_acc || 0) * 100);
  const gap = trainPct - holdPct;
  let verdict;
  if (trainPct < 40)
    verdict = `Both scores are near a lucky guess — the model is <b>undertrained</b>. Add more photos and train again.`;
  else if (gap >= 12)
    verdict = `It <b>memorized</b> the photos it studied, but hasn't learned the general pattern yet — more photos will close the gap.`;
  else
    verdict = `Close together — it's <b>learning the pattern</b>, not just memorizing. 🎯`;
  $("trainOut").innerHTML =
    `<span class="ok">Training complete — your model has been taught. 🎓</span>\n\n` +
    `Each photo was cut into <b>16 patch tokens</b> — its “visual words”.\n` +
    `For every photo it <b>guessed</b>, checked the real <b>label</b>, then <b>nudged</b> its numbers — over and over.\n\n` +
    `  ${sm.trained_on} photos × ${sm.patches_per_image} visual words × ${sm.epochs} rounds\n` +
    `  = <span class="big">${(sm.patch_tokens || 0).toLocaleString()} patch tokens</span> seen while learning\n\n` +
    `<b>How well did it learn?</b>\n` +
    `  • on photos it STUDIED: <span class="ok">${trainPct}%</span>  (${sm.trained_on} photos)\n` +
    `  • on photos it NEVER saw: <b>${holdPct}%</b>  (${sm.holdout} photos)\n` +
    `  ${verdict}\n\n` +
    `It saved <b>3 files</b> — the whole trained model:\n` +
    `  • <span class="mono">model.safetensors</span> — the <b>brain</b> (${(sm.parameters || 0).toLocaleString()} learned numbers)\n` +
    `  • <span class="mono">config.json</span> — the <b>recipe card</b> (how the model is built)\n` +
    `  • <span class="mono">classes.json</span> — the <b>label list</b> (what it can name)\n\n` +
    `See “How well did it actually learn?” on the Inference tab →`;
  $("trainedNote").style.display = "block";
  STATE.trained = true;
  $("tabInfer").disabled = false; $("tabAnat").disabled = false;
  $("btnTrain").disabled = false;
  refresh();
}

/* ---------------- INFERENCE TAB ---------------- */
async function loadInferGallery() {
  try {
    await ensureSplits();
    const g = await api("/datasets/gallery");
    renderGallery("infGallery", "infGalWrap", "infGalCount", g, true);
    renderAccTiles();
  } catch (e) { $("infGalCount").textContent = e.message; }
}

function selectImg(el) {
  document.querySelectorAll("#infGallery .thumb").forEach(t => t.classList.remove("sel"));
  el.classList.add("sel");
  const sp = SPLIT[el.dataset.file] || null;
  STATE.sel = { file: el.dataset.file, cls: el.dataset.cls, split: sp };
  $("selPrev").classList.remove("hide");
  $("selImg").src = imgUrl(STATE.sel.file);
  $("selName").textContent = STATE.sel.file;
  $("selLabel").innerHTML = `human label (folder): <b>${STATE.sel.cls}</b> — supervised`;
  $("selSplit").innerHTML = sp
    ? `<span class="splittag ${sp}">${sp === "test" ? "TEST · the model never trained on this one" : "TRAIN · the model studied this one"}</span>`
    : "";
  $("btnPredict").disabled = false;
  $("btnAsk").disabled = !STATE.openai;
  $("predOut").innerHTML = ""; $("oaiOut").textContent = "—";
}

async function predict() {
  if (!STATE.sel) return;
  $("btnPredict").disabled = true;
  try {
    const r = await api("/infer", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ filename: STATE.sel.file })
    });
    const top = r.scoreboard[0].label;
    const rows = r.scoreboard.map((b, i) =>
      `<div class="scorerow ${i === 0 ? "win" : ""}">
         <div class="nm">${i === 0 ? '<span class="crown">👑</span> ' : ""}${b.label}</div>
         <div class="bar"><span style="width:${b.belief}%"></span></div>
         <div class="pc">${b.belief}%</div></div>`).join("");
    let verdict = "";
    if (r.match !== undefined) {
      verdict = r.match
        ? `<div class="verdict ok">✓ match — the model's strongest belief (<b>${top}</b>) is the photo's label (<b>${r.expected}</b>).</div>`
        : `<div class="verdict no">✗ miss — model says <b>${top}</b>, the photo's label is <b>${r.expected}</b>.</div>`;
    }
    let splitNote = "";
    if (r.split === "test") splitNote = `<div class="meta">This was a <b>held-out TEST</b> image — the model never trained on it, so this is its <i>honest</i> answer on something new.</div>`;
    else if (r.split === "train") splitNote = `<div class="meta">This was a <b>TRAIN</b> image — the model saw it during training, so a correct answer is partly memory.</div>`;
    $("predOut").innerHTML =
      `<div class="scoreboard"><div class="sbh">The scoreboard · belief for every class</div>${rows}
        <div class="meta">PREDICTION: <b>${top}</b> (${r.belief}% belief) · built from ${r.patch_tokens} patch tokens</div>${verdict}${splitNote}</div>`;
  } catch (e) { $("predOut").innerHTML = `<div class="out mono"><span class="warn">${e.message}</span></div>`; }
  finally { $("btnPredict").disabled = false; }
}

async function askOpenai() {
  if (!STATE.sel) { $("oaiOut").textContent = "Pick an image first."; return; }
  $("btnAsk").disabled = true; $("oaiOut").textContent = "Asking OpenAI…";
  try {
    const r = await api("/ask", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ filename: STATE.sel.file, question: $("oaiQ").value, model: "openai" })
    });
    $("oaiOut").textContent = r.answer;
    const spn = STATE.sel.split === "test" ? " (a TEST image for IMG07)"
              : STATE.sel.split === "train" ? " (a TRAIN image for IMG07)" : "";
    $("oaiMeta").textContent = `answered by ${r.model} — it never trained on any of your photos${spn}`;
    renderRequest(r.request);
  } catch (e) { $("oaiOut").innerHTML = `<span class="warn">${e.message}</span>`; $("oaiReq").innerHTML = ""; }
  finally { $("btnAsk").disabled = !STATE.openai; }
}

function renderRequest(req) {
  if (!req) { $("oaiReq").innerHTML = ""; return; }
  const body = JSON.stringify(req.body, null, 2);
  $("oaiReq").innerHTML =
    `<details class="reqbox"><summary>Show the exact request sent to OpenAI →</summary>
       <div class="reqnote"><b>How the image travels:</b> ${req.how_the_image_is_sent}. ` +
       `Your ${req.image_bytes.toLocaleString()}-byte photo becomes ${req.base64_chars.toLocaleString()} base64 characters — a wall of text glued right into the JSON below.</div>
       <div class="reqep">${req.endpoint}</div>
       <pre class="reqjson">${body.replace(/</g, "&lt;")}</pre>
       <div class="reqnote">Contrast with IMG07: it reads the photo's pixels <b>locally</b> and runs the numbers on your machine — it never ships the image anywhere.</div>
     </details>`;
}

/* ---------------- LOOK INSIDE TAB ---------------- */
async function loadAnatomy() {
  try {
    const a = await api("/anatomy");
    $("anatBody").innerHTML = renderAnatomy(a);
  } catch (e) { $("anatBody").innerHTML = `<div class="out mono"><span class="warn">${e.message}</span></div>`; }
}

function renderAnatomy(a) {
  const tr = a.training || {};
  const files = a.files.map(f =>
    `<div class="filecard"><span class="fn">${f.name}</span><span class="fb">${f.bytes.toLocaleString()} bytes</span>
       <div class="fw">${f.what}</div><div class="fr">role: ${f.role}</div></div>`).join("");

  const trainCard =
    `<details class="astep" open><summary><span class="num">✓</span><span class="t">What training produced</span>
       <span class="s">${(a.parameters).toLocaleString()} params</span></summary><div class="body">
       <div class="kv">
         <div class="k">source</div><div class="v">${tr.source}</div>
         <div class="k">classes</div><div class="v">${(tr.classes || []).join(", ")}</div>
         <div class="k">images</div><div class="v">${tr.images} (${tr.trained_on} trained · ${tr.holdout} holdout)</div>
         <div class="k">patch tokens seen</div><div class="v">${(tr.patch_tokens || 0).toLocaleString()} (${tr.patches_per_image}/image × epochs)</div>
         <div class="k">accuracy (trained-on)</div><div class="v">${((tr.train_acc || 0) * 100).toFixed(0)}%</div>
         <div class="k">accuracy (held-out)</div><div class="v">${((tr.holdout_acc || 0) * 100).toFixed(0)}%</div>
       </div></div></details>`;

  const filesCard =
    `<details class="astep" open><summary><span class="num">1</span><span class="t">The three files on disk</span>
       <span class="s">./artifacts/</span></summary><div class="body">${files}
       <div class="note">On restart the model reloads these — a trained IMG07 survives <span class="mono">docker compose down</span>. Walk them on the CLI: <span class="mono">docker compose exec model python inspect_files.py</span></div></div></details>`;

  const groups = a.groups.map((g, i) => {
    const rows = g.tensors.map(t =>
      `<div class="nm">${t.name}</div><div class="sh">[${t.shape.join("×")}]</div><div class="pc">${t.params.toLocaleString()}</div>`).join("");
    const bullets = g.bullets.map(b => `<li>${b}</li>`).join("");
    return `<details class="astep"><summary><span class="num">${i + 2}</span><span class="t">${g.name}</span>
      <span class="s">${g.params.toLocaleString()} params</span></summary><div class="body">
      <div class="meta" style="margin:0 0 8px">${g.one_liner}</div>
      <ul class="tlist">${bullets}</ul>
      <div class="grid"><div class="h">tensor</div><div class="h">shape</div><div class="h">params</div>${rows}</div>
      </div></details>`;
  }).join("");

  const sample = `<details class="astep"><summary><span class="num">${a.groups.length + 2}</span>
      <span class="t">Real numbers</span><span class="s">actual weights</span></summary><div class="body">
      <div class="meta">One learned position vector (seat 6, first 16 of ${a.config.hidden_size}):</div>
      <div class="matrix">${a.samples.pos_row6.join("  ")}</div>
      <div class="meta" style="margin-top:10px">A 6×6 corner of block 0's query projection:</div>
      <div class="matrix">${a.samples.q_proj_corner.map(r => r.join("  ")).join("\n")}</div>
      </div></details>`;

  return trainCard + filesCard + groups + sample + `<div class="scale">${a.scale_note}</div>`;
}

refresh();
