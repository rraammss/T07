const $ = id => document.getElementById(id);
const api = async (path, options={}) => {
  const r = await fetch('/api'+path, options);
  const data = await r.json();
  if(!r.ok) throw new Error(data.detail || data.error || ('HTTP '+r.status));
  return data;
};

function show(which){
  ['train','infer','anat'].forEach(x => $(x).classList.toggle('hide', x!==which));
  $('tabTrain').classList.toggle('on', which==='train');
  $('tabInfer').classList.toggle('on', which==='infer');
  $('tabAnat').classList.toggle('on', which==='anat');
  if(which==='infer') loadInferenceGallery();
  if(which==='anat') loadAnatomy();
}
window.show=show;

async function refreshStatus(){
  try{
    const s = await api('/status');
    $('pill').textContent = s.loaded ? 'model ready' : 'connected';
    STATE.openai=!!s.openai_key;
    if(s.loaded){
      $('tabInfer').disabled=false; $('tabAnat').disabled=false;
    }
    const ask=$('btnAsk'); if(ask) ask.disabled = !STATE.openai || !selected;
    const meta=$('oaiMeta'); if(meta && !STATE.openai) meta.textContent='OpenAI key not set — add OPENAI_API_KEY to .env and restart to enable side B.';
  }catch(e){ $('pill').textContent='offline'; }
}

function thumbHtml(f, target){
  const esc = f.replaceAll("'", "\\'");
  return `<div class="thumb" onclick="selectImage('${esc}',this,'${target}')"><img src="/api/image/${encodeURIComponent(f)}" alt="${f}"><span class="tl">UNLABELED</span></div>`;
}

async function loadGallery(){
  const g = await api('/datasets/gallery');
  $('galWrap').classList.toggle('hide', !g.images?.length);
  $('galCount').textContent = g.images?.length ? `${g.count} unlabeled images · one flat pool · no class folders` : '';
  $('gallery').innerHTML = (g.images||[]).map(f=>`<div class="thumb"><img src="/api/image/${encodeURIComponent(f)}" alt="${f}"><span class="tl">UNLABELED</span></div>`).join('');
  $('btnTrain').disabled = !(g.images && g.images.length);
  return g;
}

async function pull(){
  const b=$('btnPull'); b.disabled=true; b.textContent='Pulling…';
  $('trainOut').textContent='Downloading images only. Any class labels in the source dataset are deliberately ignored…';
  try{
    const g=await api('/datasets/import',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({url:$('dsUrl').value,count:+$('imageCount').value})});
    $('trainOut').innerHTML=`<span class="ok">✓ ${g.count || $('imageCount').value} images ready.</span>\nFlat pool: images/img_0001.png …\nNo label column is used.`;
    await loadGallery();
  }catch(e){ $('trainOut').textContent='Pull failed: '+e.message; }
  finally{ b.disabled=false; b.textContent='Pull uoft-cs/cifar10'; }
}
window.pull=pull;

let pollTimer=null;
let trainingStartMse=null;
function fmt(v){ return (v===undefined || v===null) ? '—' : Number(v).toFixed(5); }
async function trainModel(){
  const b=$('btnTrain'); b.disabled=true;
  $('trainOut').textContent='Starting masked-image training…';
  trainingStartMse=null;
  $('trainingMseResult').style.display='none';
  $('mseStart').textContent='—'; $('mseFinal').textContent='—';
  try{
    await api('/train',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});
    if(pollTimer) clearInterval(pollTimer);
    pollTimer=setInterval(async()=>{
      try{
        const s=await api('/train/status');
        $('trainOut').innerHTML = `SELF-SUPERVISED TRAINING\n\nepoch ${s.epoch||0}/${s.epochs||0}\nimages: ${s.images||'?'}\nhidden patches: ${Math.round((s.mask_ratio||.5)*16)}/16\ntrain MSE: ${fmt(s.mse)}\nholdout MSE: ${fmt(s.holdout_mse)}\n\nNo class labels are being read.`;
        if(trainingStartMse===null && s.mse!==undefined && s.mse!==null) trainingStartMse=Number(s.mse);
        if(s.done || (!s.running && s.epoch)){
          clearInterval(pollTimer); pollTimer=null; b.disabled=false;
          $('tabInfer').disabled=false; $('tabAnat').disabled=false;
          $('trainedNote').style.display='block'; $('pill').textContent='model ready';
          $('mseStart').textContent=fmt(trainingStartMse);
          $('mseFinal').textContent=fmt(s.mse);
          $('trainingMseResult').style.display='block';
        }
      }catch(e){ clearInterval(pollTimer); pollTimer=null; b.disabled=false; $('trainOut').textContent='Training status error: '+e.message; }
    },700);
  }catch(e){ b.disabled=false; $('trainOut').textContent='Training failed: '+e.message; }
}
window.trainModel=trainModel;

let STATE={openai:false};
let selected=null;
async function loadInferenceGallery(){
  try{
    const g=await api('/datasets/gallery');
    $('infGalCount').textContent=`${g.count||0} unlabeled images · pick one to mask and reconstruct`;
    $('infGallery').innerHTML=(g.images||[]).map(f=>thumbHtml(f,'infer')).join('');
  }catch(e){ $('infGalCount').textContent='Could not load images: '+e.message; }
  const mi=$('mseInfer'); if(mi) mi.textContent='—';
  if($('mseBefore')) $('mseBefore').classList.remove('hide');
  if($('mseAfter')) $('mseAfter').classList.add('hide');
}

function selectImage(f, el){
  selected=f;
  document.querySelectorAll('#infGallery .thumb').forEach(x=>x.classList.remove('sel'));
  if(el) el.classList.add('sel');
  $('btnRecon').disabled=false;
  if($('btnAsk')) $('btnAsk').disabled=!STATE.openai;
  $('selectedPreview').innerHTML=`<div class="selprev"><img src="/api/image/${encodeURIComponent(f)}"><div class="lab"><b class="mono">${f}</b><br>No class name is supplied to the model.<br>Next we will hide patches and reconstruct them.</div></div>`;
  $('reconOut').innerHTML='';
  if($('mseInfer')) $('mseInfer').textContent='—';
  if($('mseBefore')) $('mseBefore').classList.remove('hide');
  if($('mseAfter')) $('mseAfter').classList.add('hide');
}
window.selectImage=selectImage;

async function reconstructSelected(){
  if(!selected) return;
  const b=$('btnRecon'); b.disabled=true; b.textContent='Reconstructing…';
  $('reconOut').innerHTML='<div class="out mono">Hiding patches, running the model, then comparing its prediction with the original hidden pixels…</div>';
  try{
    const r=await api('/reconstruct',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({filename:selected})});
    const mse=fmt(r.mse);
    if($('mseInfer')) $('mseInfer').textContent=mse;
    if($('mseBefore')) $('mseBefore').classList.add('hide');
    if($('mseAfter')) $('mseAfter').classList.remove('hide');
    $('reconOut').innerHTML=`
      <div class="gptflow">
        <div class="fbox"><b>ORIGINAL</b><img class="reconimg" src="${r.original}"><small>answer key exists here</small></div>
        <span class="farr">→</span>
        <div class="fbox enc"><b>MASKED INPUT</b><img class="reconimg" src="${r.masked}"><small>${r.n_hidden}/${r.n_patches} patches hidden</small></div>
        <span class="farr">→</span>
        <div class="fbox out"><b>RECONSTRUCTION</b><img class="reconimg" src="${r.reconstruction}"><small>MSE ${mse}</small></div>
      </div>
      <div class="flowcap"><b>This is the whole SSL trick:</b> the model never needed the word “dog” or “car.” We hid part of the original ourselves, so those original hidden pixels became the target automatically.</div>`;
  }catch(e){ $('reconOut').innerHTML=`<div class="out mono">Reconstruction failed: ${e.message}</div>`; }
  finally{ b.disabled=false; b.textContent='Reconstruct with IMG07'; }
}
window.reconstructSelected=reconstructSelected;

async function askOpenai(){
  if(!selected) return;
  const b=$('btnAsk'); b.disabled=true; $('oaiOut').textContent='Asking OpenAI…'; $('oaiReq').innerHTML='';
  try{
    const r=await api('/ask',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({filename:selected,question:$('oaiQ').value,model:'openai'})});
    $('oaiOut').textContent=r.answer || '—';
    $('oaiMeta').textContent=`model: ${r.model}`;
    if(r.request) renderOpenAIRequest(r.request);
  }catch(e){ $('oaiOut').textContent='OpenAI failed: '+e.message; }
  finally{ b.disabled=!STATE.openai || !selected; }
}
window.askOpenai=askOpenai;

function renderOpenAIRequest(req){
  const body=JSON.stringify(req.body,null,2);
  $('oaiReq').innerHTML=`<details class="reqbox"><summary>Show the exact request sent to OpenAI →</summary>
    <div class="reqep">${req.endpoint}</div><pre class="reqjson">${body.replace(/</g,'&lt;')}</pre>
    <div class="reqnote">Contrast with IMG07 SSL: reconstruction runs locally on your machine; this OpenAI comparison sends the selected image in the API request.</div></details>`;
}

async function loadAnatomy(){
  try{ const a=await api('/anatomy'); $('anatBody').innerHTML=renderAnatomy(a); }
  catch(e){ $('anatBody').innerHTML=`<div class="out mono"><span class="warn">${e.message}</span></div>`; }
}

function renderAnatomy(a){
  const tr=a.training||{};
  const files=a.files.map(f=>`<div class="filecard"><span class="fn">${f.name}</span><span class="fb">${f.bytes.toLocaleString()} bytes</span><div class="fw">${f.what}</div><div class="fr">role: ${f.role}</div></div>`).join('');
  const trainCard=`<details class="astep" open><summary><span class="num">✓</span><span class="t">What training produced</span><span class="s">${a.parameters.toLocaleString()} params</span></summary><div class="body"><div class="kv">
    <div class="k">source</div><div class="v">${tr.source||'—'}</div>
    <div class="k">classes</div><div class="v">${(tr.classes||[]).join(', ')}</div>
    <div class="k">images</div><div class="v">${tr.images||0} (${tr.trained_on||0} trained · ${tr.holdout||0} holdout)</div>
    <div class="k">patch tokens seen</div><div class="v">${(tr.patch_tokens||0).toLocaleString()} (${tr.patches_per_image||16}/image × epochs)</div>
    <div class="k">training metric</div><div class="v">MSE ${tr.train_mse==null?'—':Number(tr.train_mse).toFixed(5)}</div>
    <div class="k">held-out metric</div><div class="v">MSE ${tr.holdout_mse==null?'—':Number(tr.holdout_mse).toFixed(5)}</div>
  </div><div class="note"><b>Why the class row still appears:</b> the Look Inside UI is intentionally identical to supervised. In SSL the value is <b>NO CLASS LABELS USED</b>; the model learned by reconstructing hidden pixels instead.</div></div></details>`;
  const filesCard=`<details class="astep" open><summary><span class="num">1</span><span class="t">The three files on disk</span><span class="s">./artifacts/</span></summary><div class="body">${files}<div class="note">On restart the model reloads these — a trained IMG07 survives <span class="mono">docker compose down</span>.</div></div></details>`;
  const groups=a.groups.map((g,i)=>{const rows=g.tensors.map(t=>`<div class="nm">${t.name}</div><div class="sh">[${t.shape.join('×')}]</div><div class="pc">${t.params.toLocaleString()}</div>`).join(''); const bullets=g.bullets.map(b=>`<li>${b}</li>`).join(''); return `<details class="astep"><summary><span class="num">${i+2}</span><span class="t">${g.name}</span><span class="s">${g.params.toLocaleString()} params</span></summary><div class="body"><div class="meta" style="margin:0 0 8px">${g.one_liner}</div><ul class="tlist">${bullets}</ul><div class="grid"><div class="h">tensor</div><div class="h">shape</div><div class="h">params</div>${rows}</div></div></details>`;}).join('');
  const sample=`<details class="astep"><summary><span class="num">${a.groups.length+2}</span><span class="t">Real numbers</span><span class="s">actual weights</span></summary><div class="body"><div class="meta">One learned position vector (seat 6, first 16 of ${a.config.hidden_size}):</div><div class="matrix">${a.samples.pos_row6.join('  ')}</div><div class="meta" style="margin-top:10px">A 6×6 corner of block 0's query projection:</div><div class="matrix">${a.samples.q_proj_corner.map(r=>r.join('  ')).join('\n')}</div></div></details>`;
  return trainCard+filesCard+groups+sample+`<div class="scale">${a.scale_note}</div>`;
}

refreshStatus(); loadGallery();
