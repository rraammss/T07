# TinyImageModel SSL

A tiny self-supervised image-learning demo.

The model is **not taught DOG, CAR, BIRD, BOAT, or TRUCK**.

It learns with one simple loop:

**IMAGE → PATCHES → HIDE SOME → REBUILD → COMPARE → LEARN**

## Run

```bash
docker compose up --build
```

Open:

```text
http://localhost:8080
```

## What the 3 containers do

```text
Browser
  ↓
frontend
  ↓
backend
  ↓
model
```

- **frontend** — the teaching UI
- **backend** — downloads/serves images and calls OpenAI
- **model** — trains the tiny self-supervised model and reconstructs hidden patches

## Demo flow

### 1. Train

Pull images from the dataset.

The labels are ignored.

The model repeatedly:

```text
image
  ↓
split into patches
  ↓
hide some patches
  ↓
rebuild them
  ↓
compare with the originals
  ↓
update weights
```

Training shows:

**Start MSE → Final MSE**

MSE = **Mean Squared Error**.

If MSE decreases, the model is getting better at rebuilding hidden patches.

### 2. Inference

Pick one image and click **Reconstruct**.

You will see:

```text
Original → Masked → Reconstruction
```

The MSE shown here belongs to **this image only**.

Closer to `0` means the rebuilt hidden pixels are closer to the originals.

This does **not** mean the tiny model recognized the object.

### 3. OpenAI comparison

The same image can also be sent to OpenAI.

The contrast is intentional:

```text
Tiny SSL model → rebuilds hidden pixels
OpenAI vision  → understands/describes the image
```

### 4. Look Inside

This tab shows the files and learned tensors created by training.

The important saved files are:

```text
artifacts/
├── model.safetensors
├── config.json
└── training.json
```

- `model.safetensors` — learned weights
- `config.json` — model architecture
- `training.json` — training details and MSE history

## Project structure

```text
TinyImageModel_SSL/
├── frontend/       # HTML, CSS, JavaScript
├── backend/        # image download + API + OpenAI call
├── model/          # tiny SSL model + training + reconstruction
├── images/         # flat image pool; no class folders
├── artifacts/      # trained model files
├── .env
├── docker-compose.yml
└── README.md
```

## OpenAI setup

Put your key in `.env`:

```text
OPENAI_API_KEY=your_key_here
OPENAI_MODEL=gpt-4o-mini
```

Then restart:

```bash
docker compose down
docker compose up --build
```

## The one idea to remember

**Supervised learning:** learn from human labels.

**Self-supervised learning:** learn by creating a task from the data itself.

In this demo, that task is:

**Hide → Rebuild → Compare → Learn**
