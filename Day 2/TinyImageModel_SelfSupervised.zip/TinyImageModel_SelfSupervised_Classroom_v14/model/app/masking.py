"""Random patch masking — the training program hides its own answer."""
import numpy as np
def make_mask(B, T, ratio, rng):
    k = max(1, int(round(T * ratio)))
    mask = np.zeros((B, T), dtype=bool)
    for i in range(B):
        mask[i, rng.permutation(T)[:k]] = True     # True = hidden
    return mask
