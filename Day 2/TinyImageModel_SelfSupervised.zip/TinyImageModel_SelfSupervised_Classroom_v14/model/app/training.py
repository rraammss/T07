"""Train the model by hiding patches and learning to rebuild them."""
import glob, json, math, os, threading
import numpy as np
from fastapi import HTTPException
from app import config as C
from app.state import state
from app.vision_mim import MaskedViT, Adam
from app.masking import make_mask
from app.patches import file_to_tokens

_PROG={"running":False,"epoch":0,"epochs":0,"mse":None,"holdout_mse":None,"seen":0,"done":False,"history":[]}
def progress(): return dict(_PROG)

def _pool():
    exts=("*.png","*.jpg","*.jpeg","*.bmp","*.webp"); files=[]
    for e in exts: files+=glob.glob(os.path.join(C.DATASET_DIR,e))
    return sorted(files)

def _load_dataset():
    files=_pool()
    if len(files)<10:
        raise HTTPException(400,f"Only {len(files)} images in the pool — pull more first (no labels needed).")
    X=[]; 
    for f in files:
        try: X.append(file_to_tokens(f))
        except Exception: continue
    return np.stack(X).astype(np.float32), len(files)

def _auto_epochs(n_tr):
    bpe=max(1,math.ceil(n_tr/C.BATCH)); return int(min(300,max(20,round(600/bpe))))

def _holdout_mse(model,Xho):
    mk=make_mask(len(Xho),C.N_PATCHES,C.MASK_RATIO,np.random.default_rng(123))
    r=model.forward(Xho,mk); m=mk[...,None]
    return float(((r-Xho)**2*m).sum()/(m.sum()*C.PATCH_DIM))

def _worker(epochs):
    try: X,nall=_load_dataset()
    except HTTPException as e: _PROG.update(running=False,done=True,error=e.detail); return
    rng=np.random.default_rng(C.SEED); X=X[rng.permutation(len(X))]
    n_ho=max(2,int(len(X)*C.HOLDOUT)); Xho,Xtr=X[:n_ho],X[n_ho:]
    if not epochs: epochs=_auto_epochs(len(Xtr))
    model=MaskedViT(C.PATCH_DIM,C.D_MODEL,C.N_LAYERS,C.N_HEADS,C.D_FFN,C.N_PATCHES,seed=C.SEED)
    opt=Adam(model.P,lr=C.LR)
    _PROG.update(running=True,done=False,error=None,epochs=epochs,epoch=0,seen=0,history=[],
                 mse=None,holdout_mse=round(_holdout_mse(model,Xho),5),
                 mask_ratio=C.MASK_RATIO,images=nall,trained_on=len(Xtr),holdout=len(Xho))
    seen=0
    for ep in range(epochs):
        idx=rng.permutation(len(Xtr)); last=0.
        for s in range(0,len(Xtr),C.BATCH):
            b=idx[s:s+C.BATCH]; mk=make_mask(len(b),C.N_PATCHES,C.MASK_RATIO,rng)
            last,G,_=model.loss_and_grad(Xtr[b],mk); opt.step(model.P,G); seen+=len(b)
        hm=_holdout_mse(model,Xho)
        _PROG.update(epoch=ep+1,mse=round(float(last),5),holdout_mse=round(hm,5),seen=seen)
        _PROG["history"].append({"epoch":ep+1,"mse":round(float(last),5),"holdout_mse":round(hm,5)})
    _save(model,nall,len(Xtr),len(Xho),epochs,seen)
    load_artifacts(); _PROG.update(running=False,done=True)

def _save(model,nall,ntr,nho,epochs,seen):
    params=int(sum(v.size for v in model.P.values()))
    try:
        from safetensors.numpy import save_file
        save_file({k:v.astype(np.float32) for k,v in model.P.items()},f"{C.ARTIFACT_DIR}/model.safetensors")
    except Exception:
        np.savez(f"{C.ARTIFACT_DIR}/model.npz",**{k:v.astype(np.float32) for k,v in model.P.items()})
    json.dump({"architecture":"TinyMAE","objective":"masked-patch reconstruction (self-supervised)",
        "image_size":C.IMG,"patch_size":C.PATCH,"num_patches":C.N_PATCHES,"patch_dim":C.PATCH_DIM,
        "hidden_size":C.D_MODEL,"num_hidden_layers":C.N_LAYERS,"num_attention_heads":C.N_HEADS,
        "intermediate_size":C.D_FFN,"mask_ratio":C.MASK_RATIO,"parameters":params,
        "labels_used":False,"data_layout":"flat unlabeled pool"},open(f"{C.ARTIFACT_DIR}/config.json","w"),indent=2)
    json.dump({"objective":"predict hidden patches (no labels)","images":nall,"trained_on":ntr,
        "holdout":nho,"epochs":epochs,"mask_ratio":C.MASK_RATIO,"patch_tokens_seen":seen*C.N_PATCHES,
        "history":_PROG["history"],"final_holdout_mse":_PROG.get("holdout_mse"),
        "parameters":params},open(f"{C.ARTIFACT_DIR}/training.json","w"),indent=2)

def start_training(epochs=None):
    if _PROG["running"]: raise HTTPException(409,"Training already in progress.")
    _load_dataset()
    t=threading.Thread(target=_worker,args=(int(epochs) if epochs else None,),daemon=True)
    _PROG.update(running=True,done=False,error=None); t.start()
    return {"started":True,"epochs":epochs or "auto"}

def train_blocking(epochs=None):
    _worker(int(epochs) if epochs else None)
    if _PROG.get("error"): raise HTTPException(400,_PROG["error"])
    return summary()

def summary():
    p=f"{C.ARTIFACT_DIR}/training.json"; return json.load(open(p)) if os.path.exists(p) else None

def load_artifacts():
    try:
        cfg=json.load(open(f"{C.ARTIFACT_DIR}/config.json"))
        model=MaskedViT(cfg["patch_dim"],cfg["hidden_size"],cfg["num_hidden_layers"],
                        cfg["num_attention_heads"],cfg["intermediate_size"],cfg["num_patches"],seed=0)
        if os.path.exists(f"{C.ARTIFACT_DIR}/model.safetensors"):
            from safetensors.numpy import load_file
            T=load_file(f"{C.ARTIFACT_DIR}/model.safetensors")
        else:
            T=dict(np.load(f"{C.ARTIFACT_DIR}/model.npz"))
        for k in model.P: model.P[k]=T[k]
        state["model"]=model; state["meta"]=cfg; state["training"]=summary(); return True
    except Exception: return False
