"""TinyMAE — the self-supervised twin of IMG07's ViT.

SAME backbone as the supervised model (patch embed -> +pos -> N pre-LN blocks),
written in pure NumPy with forward AND backward by hand. The ONLY differences:

  * some patches are HIDDEN: their embedded token is replaced by a learned
    mask token before the encoder runs (SimMIM-style).
  * there is NO class head. A per-token reconstruction head maps each token
    back to PATCH_DIM pixels, and the loss is MSE on the HIDDEN patches only
    (predicted pixels vs the originals the program removed). No labels anywhere.

Tensor names stay HuggingFace-style; the head just changed from `head.*` to
`recon.*`, plus one `mask.tok`.
"""
import numpy as np

def gelu(x):
    return 0.5 * x * (1.0 + np.tanh(0.7978845608028654 * (x + 0.044715 * x**3)))

def dgelu(x):
    c = 0.7978845608028654
    t = np.tanh(c * (x + 0.044715 * x**3))
    dt = (1 - t**2) * c * (1 + 3 * 0.044715 * x**2)
    return 0.5 * (1 + t) + 0.5 * x * dt

def layernorm_fwd(x, g, b, eps=1e-5):
    mu = x.mean(-1, keepdims=True); xc = x - mu
    var = (xc**2).mean(-1, keepdims=True); inv = 1.0 / np.sqrt(var + eps)
    xn = xc * inv; return xn * g + b, (xn, inv, g)

def layernorm_bwd(dout, cache):
    xn, inv, g = cache; D = xn.shape[-1]
    dxn = dout * g
    dg = (dout * xn).reshape(-1, D).sum(0); db = dout.reshape(-1, D).sum(0)
    dx = (dxn - dxn.mean(-1, keepdims=True) - xn * (dxn * xn).mean(-1, keepdims=True)) * inv
    return dx, dg, db

def softmax(z, axis=-1):
    z = z - z.max(axis, keepdims=True); e = np.exp(z); return e / e.sum(axis, keepdims=True)


class MaskedViT:
    def __init__(self, patch_dim, d_model, n_layers, n_heads, d_ffn, n_patches,
                 seed=0, dtype=np.float32):
        self.PD, self.D, self.L, self.H = patch_dim, d_model, n_layers, n_heads
        self.F, self.T = d_ffn, n_patches
        self.hd = d_model // n_heads; self.dtype = dtype
        rng = np.random.default_rng(seed)
        s = lambda *sh: (rng.standard_normal(sh) * 0.02).astype(dtype)
        z = lambda *sh: np.zeros(sh, dtype=dtype)
        P = {}
        P["patch.W"] = s(patch_dim, d_model); P["patch.b"] = z(d_model)
        P["pos"] = s(n_patches, d_model)
        P["mask.tok"] = s(d_model)                       # the learned "something is hidden here"
        for l in range(n_layers):
            p = f"layers.{l}."
            P[p+"ln1.g"] = np.ones(d_model, dtype); P[p+"ln1.b"] = z(d_model)
            P[p+"attn.q.W"] = s(d_model, d_model); P[p+"attn.q.b"] = z(d_model)
            P[p+"attn.k.W"] = s(d_model, d_model); P[p+"attn.k.b"] = z(d_model)
            P[p+"attn.v.W"] = s(d_model, d_model); P[p+"attn.v.b"] = z(d_model)
            P[p+"attn.o.W"] = s(d_model, d_model); P[p+"attn.o.b"] = z(d_model)
            P[p+"ln2.g"] = np.ones(d_model, dtype); P[p+"ln2.b"] = z(d_model)
            P[p+"mlp.1.W"] = s(d_model, d_ffn); P[p+"mlp.1.b"] = z(d_ffn)
            P[p+"mlp.2.W"] = s(d_ffn, d_model); P[p+"mlp.2.b"] = z(d_model)
        P["norm.g"] = np.ones(d_model, dtype); P["norm.b"] = z(d_model)
        P["recon.W"] = s(d_model, patch_dim); P["recon.b"] = z(patch_dim)   # token -> pixels
        self.P = P

    def _attn_fwd(self, h, p):
        B, T, D = h.shape
        q = h @ self.P[p+"attn.q.W"] + self.P[p+"attn.q.b"]
        k = h @ self.P[p+"attn.k.W"] + self.P[p+"attn.k.b"]
        v = h @ self.P[p+"attn.v.W"] + self.P[p+"attn.v.b"]
        H, hd = self.H, self.hd
        qh = q.reshape(B,T,H,hd).transpose(0,2,1,3)
        kh = k.reshape(B,T,H,hd).transpose(0,2,1,3)
        vh = v.reshape(B,T,H,hd).transpose(0,2,1,3)
        scores = qh @ kh.transpose(0,1,3,2) / np.sqrt(hd)
        att = softmax(scores, -1)
        oh = att @ vh
        o = oh.transpose(0,2,1,3).reshape(B,T,D)
        out = o @ self.P[p+"attn.o.W"] + self.P[p+"attn.o.b"]
        return out, (h,q,k,v,qh,kh,vh,att,oh,o)

    def _attn_bwd(self, dout, cache, p, G):
        h,q,k,v,qh,kh,vh,att,oh,o = cache
        B,T,D = h.shape; H,hd = self.H, self.hd
        G[p+"attn.o.W"] = o.reshape(-1,D).T @ dout.reshape(-1,D)
        G[p+"attn.o.b"] = dout.reshape(-1,D).sum(0)
        do = dout @ self.P[p+"attn.o.W"].T
        doh = do.reshape(B,T,H,hd).transpose(0,2,1,3)
        datt = doh @ vh.transpose(0,1,3,2)
        dvh = att.transpose(0,1,3,2) @ doh
        dscores = att * (datt - (datt*att).sum(-1,keepdims=True)); dscores /= np.sqrt(hd)
        dqh = dscores @ kh; dkh = dscores.transpose(0,1,3,2) @ qh
        dq = dqh.transpose(0,2,1,3).reshape(B,T,D)
        dk = dkh.transpose(0,2,1,3).reshape(B,T,D)
        dv = dvh.transpose(0,2,1,3).reshape(B,T,D)
        dh = np.zeros_like(h)
        for nm, dz in (("q",dq),("k",dk),("v",dv)):
            G[p+f"attn.{nm}.W"] = h.reshape(-1,D).T @ dz.reshape(-1,D)
            G[p+f"attn.{nm}.b"] = dz.reshape(-1,D).sum(0)
            dh += dz @ self.P[p+f"attn.{nm}.W"].T
        return dh

    def forward(self, patches, mask, cache=False):
        """patches (B,T,PD) in [0,1]; mask (B,T) bool True=hidden. Returns recon (B,T,PD)."""
        P = self.P; cch = {}
        emb = patches @ P["patch.W"] + P["patch.b"]           # embed every patch
        m = mask[..., None].astype(self.dtype)                # (B,T,1)
        x = (1 - m) * emb + m * P["mask.tok"] + P["pos"]      # hide masked tokens
        for l in range(self.L):
            p = f"layers.{l}."
            h1, c1 = layernorm_fwd(x, P[p+"ln1.g"], P[p+"ln1.b"])
            a, ca = self._attn_fwd(h1, p); x = x + a
            h2, c2 = layernorm_fwd(x, P[p+"ln2.g"], P[p+"ln2.b"])
            pre = h2 @ P[p+"mlp.1.W"] + P[p+"mlp.1.b"]; act = gelu(pre)
            mout = act @ P[p+"mlp.2.W"] + P[p+"mlp.2.b"]; x = x + mout
            if cache: cch[p] = (c1, ca, c2, h2, pre, act)
        zt, cn = layernorm_fwd(x, P["norm.g"], P["norm.b"])   # per-token final norm
        recon = zt @ P["recon.W"] + P["recon.b"]              # (B,T,PD) predicted pixels
        if cache:
            cch.update(patches=patches, emb=emb, m=m, zt=zt, cn=cn); return recon, cch
        return recon

    def loss_and_grad(self, patches, mask):
        """MSE between predicted and original pixels, on HIDDEN patches only."""
        P = self.P
        recon, cch = self.forward(patches, mask, cache=True)
        B, T, PD = recon.shape
        m = cch["m"]                                          # (B,T,1)
        denom = float(m.sum() * PD) + 1e-8
        diff = (recon - patches) * m
        loss = float((diff**2).sum() / denom)
        G = {}
        drecon = (2.0 / denom) * diff                        # (B,T,PD)
        zt = cch["zt"]
        G["recon.W"] = zt.reshape(-1, self.D).T @ drecon.reshape(-1, PD)
        G["recon.b"] = drecon.reshape(-1, PD).sum(0)
        dz = drecon @ P["recon.W"].T                         # (B,T,D)
        dx, G["norm.g"], G["norm.b"] = layernorm_bwd(dz, cch["cn"])
        for l in reversed(range(self.L)):
            p = f"layers.{l}."
            c1, ca, c2, h2, pre, act = cch[p]
            dm = dx
            G[p+"mlp.2.W"] = act.reshape(-1, self.F).T @ dm.reshape(-1, self.D)
            G[p+"mlp.2.b"] = dm.reshape(-1, self.D).sum(0)
            dact = dm @ P[p+"mlp.2.W"].T
            dpre = dact * dgelu(pre)
            G[p+"mlp.1.W"] = h2.reshape(-1, self.D).T @ dpre.reshape(-1, self.F)
            G[p+"mlp.1.b"] = dpre.reshape(-1, self.F).sum(0)
            dh2 = dpre @ P[p+"mlp.1.W"].T
            dx2, G[p+"ln2.g"], G[p+"ln2.b"] = layernorm_bwd(dh2, c2)
            dx = dx + dx2
            dh1 = self._attn_bwd(dx, ca, p, G)
            dxa, G[p+"ln1.g"], G[p+"ln1.b"] = layernorm_bwd(dh1, c1)
            dx = dx + dxa
        # input split: x = (1-m)*emb + m*mask_tok + pos
        G["pos"] = dx.sum(0)                                 # (T,D)
        mm = cch["m"]
        G["mask.tok"] = (dx * mm).reshape(-1, self.D).sum(0) # (D,)
        demb = dx * (1 - mm)
        patches0 = cch["patches"]
        G["patch.W"] = patches0.reshape(-1, self.PD).T @ demb.reshape(-1, self.D)
        G["patch.b"] = demb.reshape(-1, self.D).sum(0)
        return loss, G, recon


class Adam:
    def __init__(self, params, lr=1e-3, b1=0.9, b2=0.999, eps=1e-8):
        self.lr, self.b1, self.b2, self.eps = lr, b1, b2, eps
        self.m = {k: np.zeros_like(v) for k, v in params.items()}
        self.v = {k: np.zeros_like(v) for k, v in params.items()}
        self.t = 0
    def step(self, params, grads):
        self.t += 1
        for k in params:
            g = grads[k]
            self.m[k] = self.b1*self.m[k] + (1-self.b1)*g
            self.v[k] = self.b2*self.v[k] + (1-self.b2)*(g*g)
            mh = self.m[k]/(1-self.b1**self.t); vh = self.v[k]/(1-self.b2**self.t)
            params[k] -= self.lr * mh / (np.sqrt(vh) + self.eps)
