"""Reconstruct the hidden patches of one image with the trained model."""
import base64, io, os
import numpy as np
from fastapi import HTTPException
from PIL import Image
from app import config as C
from app.state import state
from app.masking import make_mask
from app.patches import file_to_tokens, unpatchify

def _resolve(filename):
    if "/" in filename or ".." in filename:
        raise HTTPException(400,"bad filename")
    path=os.path.join(C.DATASET_DIR,filename)
    if not os.path.exists(path): raise HTTPException(404,f"image not found: {filename}")
    return path

def _png(arr, scale=8):
    im=Image.fromarray((np.clip(arr,0,1)*255).astype(np.uint8)).resize(
        (C.IMG*scale,C.IMG*scale),Image.NEAREST)
    buf=io.BytesIO(); im.save(buf,"PNG")
    return "data:image/png;base64,"+base64.b64encode(buf.getvalue()).decode()

def reconstruct(filename, seed=None):
    if state["model"] is None:
        raise HTTPException(400,"No trained model yet. Train first.")
    path=_resolve(filename)
    tok = file_to_tokens(path)
    rng=np.random.default_rng(seed if seed is not None else 0)
    mk = make_mask(1, C.N_PATCHES, C.MASK_RATIO, rng)
    rec = state["model"].forward(tok[None], mk)[0]
    m=mk[0][:,None]
    orig=unpatchify(tok)
    masked=unpatchify(np.where(m,0.5,tok))
    filled=unpatchify(np.where(m,rec,tok))
    denom=float(m.sum()*C.PATCH_DIM)+1e-8
    mse=float((((rec-tok)*m)**2).sum()/denom)
    hidden=[int(i) for i in np.where(mk[0])[0]]
    return {"filename":filename,"hidden_patches":hidden,"n_hidden":len(hidden),
            "n_patches":C.N_PATCHES,"mask_ratio":C.MASK_RATIO,"mse":round(mse,5),
            "original":_png(orig),"masked":_png(masked),"reconstruction":_png(filled)}
