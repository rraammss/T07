"""photo <-> 16 patch tokens (fixed recipe) + unpatchify for reconstructions."""
import numpy as np
from PIL import Image
from app.config import IMG, PATCH, GRID, PATCH_DIM
def load(path):
    return np.asarray(Image.open(path).convert("RGB").resize((IMG,IMG)),np.float32)/255.
def patchify(arr):
    out=np.empty((GRID*GRID,PATCH_DIM),np.float32); n=0
    for gy in range(GRID):
        for gx in range(GRID):
            out[n]=arr[gy*PATCH:(gy+1)*PATCH,gx*PATCH:(gx+1)*PATCH,:].reshape(-1); n+=1
    return out
def unpatchify(tokens):
    img=np.zeros((IMG,IMG,3),np.float32); n=0
    for gy in range(GRID):
        for gx in range(GRID):
            img[gy*PATCH:(gy+1)*PATCH,gx*PATCH:(gx+1)*PATCH,:]=tokens[n].reshape(PATCH,PATCH,3); n+=1
    return np.clip(img,0,1)
def file_to_tokens(path): return patchify(load(path))
