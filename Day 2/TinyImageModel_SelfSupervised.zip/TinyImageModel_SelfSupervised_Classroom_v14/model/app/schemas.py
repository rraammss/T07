from pydantic import BaseModel
from typing import Optional
class TrainReq(BaseModel): epochs: Optional[int] = None
class ReconReq(BaseModel):
    filename: str
    seed: Optional[int] = None
