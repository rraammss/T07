"""Build the Look-inside payload using the exact supervised UI structure."""
import os
from fastapi import HTTPException
from app import config as C
from app.state import state


def _groups():
    P=state["model"].P
    groups=[]
    def g(name,keys,bullets,one_liner):
        rows=[{"name":k,"shape":list(P[k].shape),"params":int(P[k].size)} for k in keys]
        return {"name":name,"one_liner":one_liner,"bullets":bullets,"tensors":rows,"params":sum(r["params"] for r in rows)}
    groups.append(g("Patch embedding — the stamp",["patch.W","patch.b","pos","mask.tok"],[
        f"Each 8x8 patch is 192 raw numbers. patch.W presses those 192 down to {C.D_MODEL} — one vector per patch.",
        "pos tells the Transformer where every patch sits. mask.tok is the learned placeholder used when a patch is deliberately hidden."],
        "raw pixels -> patch tokens, positions, and a learned MASK placeholder"))
    for l in range(C.N_LAYERS):
        p=f"layers.{l}."
        keys=[p+"ln1.g",p+"ln1.b",p+"attn.q.W",p+"attn.q.b",p+"attn.k.W",p+"attn.k.b",p+"attn.v.W",p+"attn.v.b",p+"attn.o.W",p+"attn.o.b",p+"ln2.g",p+"ln2.b",p+"mlp.1.W",p+"mlp.1.b",p+"mlp.2.W",p+"mlp.2.b"]
        bullets=["Attention lets visible and masked patch tokens exchange context; the MLP refines each token.","LayerNorm keeps values stable while the same block structure is stacked deeper."] if l==0 else ["Same Transformer machinery as block 0, stacked again so patch representations become richer."]
        groups.append(g(f"Transformer block {l}",keys,bullets,"attention (patches talk) then MLP (each token is refined)"))
    groups.append(g("Final norm + prediction head",["norm.g","norm.b","recon.W","recon.b"],[
        "The final norm cleans up each patch token before prediction.",
        "In SSL the prediction head is recon.W/recon.b: every masked token predicts the original pixels of its hidden patch. There is no class-score head."],
        "16 refined tokens -> reconstructed pixels for hidden patches"))
    return groups

def build_anatomy_payload():
    if state["model"] is None:
        raise HTTPException(400,"Train a model first, then look inside.")
    tr=state["training"] or {}; cfg=state["meta"] or {}; P=state["model"].P
    params=int(sum(v.size for v in P.values()))
    def size(name):
        p=f"{C.ARTIFACT_DIR}/{name}"; return os.path.getsize(p) if os.path.exists(p) else 0
    files=[
      {"name":"model.safetensors","bytes":size("model.safetensors") or size("model.npz"),"what":f"The learned brain — every weight the SSL training loop nudged. {params:,} numbers with HuggingFace-style tensor names.","role":"turns 16 patch tokens into reconstructed hidden pixels"},
      {"name":"config.json","bytes":size("config.json"),"what":"The architecture card — image size, patch size, hidden width, blocks, heads, mask ratio, and labels_used:false.","role":"how to rebuild the model shell before loading the weights"},
      {"name":"training.json","bytes":size("training.json"),"what":"The training provenance: image counts, patch tokens seen, mask ratio, epochs, MSE history, and held-out reconstruction MSE.","role":"what the SSL training scoreboard means and where the data came from"}
    ]
    pos=[round(float(x),4) for x in P["pos"][5][:16]]
    q=[[round(float(P["layers.0.attn.q.W"][i,j]),4) for j in range(6)] for i in range(6)]
    training={
      "source":"uoft-cs/cifar10 images — labels deliberately ignored",
      "classes":["NO CLASS LABELS USED"],
      "images":tr.get("images",0),"trained_on":tr.get("trained_on",0),"holdout":tr.get("holdout",0),
      "patch_tokens":tr.get("patch_tokens_seen",0),"patches_per_image":C.N_PATCHES,
      "train_acc":0,"holdout_acc":0,
      "train_mse":(tr.get("history") or [{}])[-1].get("mse") if tr.get("history") else None,
      "holdout_mse":tr.get("final_holdout_mse")
    }
    return {"files":files,"training":training,"config":cfg,"parameters":params,"groups":_groups(),
      "samples":{"pos_row6":pos,"q_proj_corner":q},
      "scale_note":f"This SSL model has {params:,} learned numbers. Same visual backbone idea as supervised IMG07; the key difference is the prediction head and loss: reconstructed pixels + MSE instead of class scores + cross-entropy."}
