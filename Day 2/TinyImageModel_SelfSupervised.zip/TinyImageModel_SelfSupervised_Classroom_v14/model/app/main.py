"""TinyMAE model-service HTTP entry point (self-supervised). Thin routes."""
import glob, os
from fastapi import FastAPI
from app import config as C
from app.schemas import TrainReq, ReconReq
from app.state import state
from app.training import start_training, train_blocking, load_artifacts, progress, summary
from app.reconstruct import reconstruct
from app.inspector import build_anatomy_payload

app=FastAPI(title="TinyMAE (self-supervised)")

@app.post("/train")
def train(req: TrainReq): return start_training(req.epochs)

@app.get("/train/status")
def train_status(): return {**progress(),"summary":summary()}

@app.post("/invalidate")
def invalidate():
    state.update({"model":None,"meta":None,"training":None}); removed=[]
    for name in ("model.safetensors","model.npz","config.json","training.json"):
        p=f"{C.ARTIFACT_DIR}/{name}"
        if os.path.exists(p): os.remove(p); removed.append(name)
    return {"invalidated":True,"removed":removed}

@app.post("/reconstruct")
def do_recon(req: ReconReq): return reconstruct(req.filename, req.seed)

@app.get("/anatomy")
def anatomy(): return build_anatomy_payload()

@app.get("/status")
def status():
    n=len(glob.glob(f"{C.DATASET_DIR}/*"))
    return {"trained":state["model"] is not None,"pool_images":n,"training":state["training"],
            "labels_used":False}

load_artifacts()
