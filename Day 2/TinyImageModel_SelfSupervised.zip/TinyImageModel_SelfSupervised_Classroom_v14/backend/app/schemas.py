from pydantic import BaseModel
from typing import Optional
class DatasetImport(BaseModel):
    url: str = "uoft-cs/cifar10"
    count: int = 200
class TrainReq(BaseModel): epochs: Optional[int] = None
class ReconReq(BaseModel):
    filename: str
    seed: Optional[int] = None

class Ask(BaseModel):
    filename: str
    question: str = "What is in this image?"
    model: str = "openai"
