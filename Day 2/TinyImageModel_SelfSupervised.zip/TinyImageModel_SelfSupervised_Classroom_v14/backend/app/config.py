import os
MODEL_URL=os.environ.get("MODEL_URL","http://model:9000")
DATASET_DIR="/images"     # the flat, label-free pool (shared volume)

OPENAI_KEY=os.environ.get("OPENAI_API_KEY","")
OPENAI_MODEL=os.environ.get("OPENAI_MODEL","gpt-4o-mini")
