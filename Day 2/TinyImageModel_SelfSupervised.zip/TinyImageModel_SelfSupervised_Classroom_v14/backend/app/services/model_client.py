import requests
from fastapi import HTTPException
from app.config import MODEL_URL
def _get(p):
    try: return requests.get(MODEL_URL+p,timeout=30).json()
    except Exception as e: raise HTTPException(502,f"model service unreachable: {e}")
def _post(p,j=None):
    try: return requests.post(MODEL_URL+p,json=j or {},timeout=600).json()
    except Exception as e: raise HTTPException(502,f"model service unreachable: {e}")
def train(epochs=None): return _post("/train",{"epochs":epochs})
def train_status(): return _get("/train/status")
def reconstruct(filename,seed=None): return _post("/reconstruct",{"filename":filename,"seed":seed})
def anatomy(): return _get("/anatomy")
def status(): return _get("/status")
def invalidate(): return _post("/invalidate")
