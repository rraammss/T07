"""Download images into one flat pool. Dataset labels are intentionally ignored."""
import glob, io, json, os
from fastapi import HTTPException
from PIL import Image
from app.config import DATASET_DIR

IMG=32
def _img_col(row):
    for k in ("img","image","image_bytes","png"):
        if k in row and row[k] is not None: return row[k]
    for v in row.values():
        if isinstance(v,Image.Image): return v
    return None

def import_dataset(url: str, count: int):
    try:
        from datasets import load_dataset
    except Exception:
        raise HTTPException(500,"`datasets` not installed in the backend image.")
    os.makedirs(DATASET_DIR, exist_ok=True)
    # start clean so the pool is exactly what was pulled
    for f in glob.glob(f"{DATASET_DIR}/*"): 
        try: os.remove(f)
        except Exception: pass
    try:
        ds=load_dataset(url, split="train", streaming=True)
    except Exception as e:
        raise HTTPException(400,f"Could not load HF dataset '{url}': {e}")
    saved=0
    for row in ds:
        if saved>=count: break
        im=_img_col(row)
        if im is None: continue
        if isinstance(im,(bytes,bytearray)): im=Image.open(io.BytesIO(im))
        im.convert("RGB").resize((IMG,IMG)).save(f"{DATASET_DIR}/img_{saved+1:04d}.png")
        saved+=1
    if saved==0: raise HTTPException(400,"No image column found in that dataset.")
    json.dump({"source":url,"count":saved,"labels_used":False,"layout":"flat pool"},
              open(f"{DATASET_DIR}/manifest.json","w"))
    return {"imported":saved,"source":url,"labels_used":False,
            "note":"IMAGE column only — the dataset's label column was never read."}

def gallery():
    files=sorted(os.path.basename(f) for f in glob.glob(f"{DATASET_DIR}/*.png"))
    src=None
    if os.path.exists(f"{DATASET_DIR}/manifest.json"):
        src=json.load(open(f"{DATASET_DIR}/manifest.json")).get("source")
    return {"images":files,"count":len(files),"source":src,"labels":None}

def clear():
    n=0
    for f in glob.glob(f"{DATASET_DIR}/*"):
        try: os.remove(f); n+=1
        except Exception: pass
    return {"cleared":n}
