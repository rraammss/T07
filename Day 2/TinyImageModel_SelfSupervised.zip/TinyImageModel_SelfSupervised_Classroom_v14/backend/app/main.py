"""TinyMAE backend/orchestrator — thin routes; logic in services."""
import os
import base64
import requests
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from app.config import DATASET_DIR, OPENAI_KEY, OPENAI_MODEL
from app.schemas import DatasetImport, TrainReq, ReconReq, Ask
from app.services import datasets, model_client

app=FastAPI(title="TinyMAE backend (self-supervised)")

@app.post("/api/datasets/import")
def import_dataset(req: DatasetImport):
    out=datasets.import_dataset(req.url, req.count); model_client.invalidate(); return out

@app.get("/api/datasets/gallery")
def gallery(): return datasets.gallery()

@app.delete("/api/datasets")
def clear(): out=datasets.clear(); model_client.invalidate(); return out

@app.get("/api/image/{name}")
def image(name: str):
    if "/" in name or ".." in name: return {"error":"bad name"}
    p=os.path.join(DATASET_DIR,name)
    return FileResponse(p) if os.path.exists(p) else {"error":"not found"}

@app.post("/api/train")
def train(req: TrainReq): return model_client.train(req.epochs)
@app.get("/api/train/status")
def train_status(): return model_client.train_status()

@app.post("/api/reconstruct")
def reconstruct(req: ReconReq): return model_client.reconstruct(req.filename, req.seed)

@app.post("/api/ask")
def ask(req: Ask):
    if req.model != "openai":
        raise HTTPException(400, "model must be 'openai'")
    if not OPENAI_KEY:
        raise HTTPException(400, "OPENAI_API_KEY is not set in .env")
    if "/" in req.filename or ".." in req.filename:
        raise HTTPException(400, "bad filename")
    fp=os.path.join(DATASET_DIR,req.filename)
    if not os.path.exists(fp):
        raise HTTPException(404, "image not found")
    raw=open(fp,"rb").read(); b64=base64.b64encode(raw).decode("ascii")
    ext=os.path.splitext(fp)[1].lower(); mime="image/png" if ext==".png" else "image/jpeg"
    data_uri=f"data:{mime};base64,{b64}"
    text=req.question + " Answer in one short sentence."
    payload={"model":OPENAI_MODEL,"messages":[{"role":"user","content":[
        {"type":"text","text":text},
        {"type":"image_url","image_url":{"url":data_uri}}
    ]}]}
    r=requests.post("https://api.openai.com/v1/chat/completions",headers={"Authorization":f"Bearer {OPENAI_KEY}"},json=payload,timeout=60)
    if r.status_code != 200:
        raise HTTPException(r.status_code, f"OpenAI: {r.text[:200]}")
    preview=data_uri[:64] + f"…❮{len(b64):,} base64 chars — the whole image, inlined as text❯"
    request_preview={
        "endpoint":"POST https://api.openai.com/v1/chat/completions",
        "how_the_image_is_sent":"base64 data-URI inlined in the JSON body — NOT a file upload",
        "image_bytes":len(raw),"base64_chars":len(b64),
        "body":{"model":OPENAI_MODEL,"messages":[{"role":"user","content":[
            {"type":"text","text":text},{"type":"image_url","image_url":{"url":preview}}
        ]}]}
    }
    return {"model":OPENAI_MODEL,"answer":r.json()["choices"][0]["message"]["content"].strip(),"request":request_preview}

@app.get("/api/anatomy")
def anatomy(): return model_client.anatomy()
@app.get("/api/status")
def status(): return {**model_client.status(), "openai_key": bool(OPENAI_KEY), "openai_model": OPENAI_MODEL}
