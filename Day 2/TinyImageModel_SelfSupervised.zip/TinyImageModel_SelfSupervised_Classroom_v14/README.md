# TinyImageModel — Self-Supervised Reconstruction Classroom v14

This is the **full Docker project**, rebuilt from the original TinyImageModel self-supervised bundle.

## Core lesson

**SUPERVISED**
- TRAIN: image + label `CAR` → learn
- INFERENCE: new image → `CAR`

**SELF-SUPERVISED RECONSTRUCTION**
- TRAIN: image → hide part → predict part → compare with original → MSE → backprop → learn
- INFERENCE: new image → hide part → trained model → predict/reconstruct part

**Same training/inference structure. Different task.**

## Project structure

- `frontend/` — Nginx + UI (`index.html`, `assets/app.js`, `assets/styles.css`)
- `backend/` — FastAPI orchestration, dataset import/gallery, optional OpenAI comparison
- `model/` — FastAPI model service, patching, masking, Tiny ViT, training, reconstruction, inspector
- `images/` — exactly 10 unlabeled classroom images included
- `artifacts/` — starts clean; trained artifacts are written here
- `docker-compose.yml` — runs frontend + backend + model

## Run

```bash
docker compose up --build
```

Open:

`http://localhost:8080`

The bundle starts with **no trained artifacts**, so Inference and Look Inside unlock only after training.

## Optional OpenAI comparison

Set `OPENAI_API_KEY` in your shell before `docker compose up` if you want the optional OpenAI button on the Inference page. This is deliberately separate from the tiny reconstruction objective.

The student assignment at the bottom of Inference points them to **OpenAI Image GPT (iGPT)** and **CLIP**.
