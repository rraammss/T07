"""
main.py — the ENTIRE backend, in one shareable file.

What it does: a connection test against each provider's real API using the
provider's OWN official SDK. Nothing else — no payload building, no error
demos, no file handling. Three endpoints:

  GET /api/health           -> which API keys are present in the environment
  GET /api/vendors          -> provider list for the UI dropdown
  GET /api/connection_test  -> one tiny real call that proves the key works

Keys are read from the environment (.env) at startup. They are never sent
from, or entered in, the browser.
"""
import os, time, json

from fastapi import FastAPI
from fastapi.concurrency import run_in_threadpool
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv

load_dotenv()

# ---------------------------------------------------------------------------
# Providers — id, label, env var for the key, default model, curl equivalent,
# and a `call` function that makes one tiny request via the official SDK.
# ---------------------------------------------------------------------------


def _anthropic_call(prompt):
    from anthropic import Anthropic
    r = Anthropic().messages.create(
        model="claude-haiku-4-5", max_tokens=16,
        messages=[{"role": "user", "content": prompt}])
    return "".join(b.text for b in r.content if b.type == "text")


def _openai_call(prompt):
    from openai import OpenAI
    r = OpenAI().chat.completions.create(
        model="gpt-4o-mini", max_tokens=16,
        messages=[{"role": "user", "content": prompt}])
    return r.choices[0].message.content or ""


def _google_call(prompt):
    from google import genai
    from google.genai import types
    key = os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY")
    r = genai.Client(api_key=key).models.generate_content(
        model="gemini-2.5-flash", contents=prompt,
        config=types.GenerateContentConfig(max_output_tokens=16))
    return r.text or ""


def _groq_call(prompt):
    from groq import Groq
    r = Groq().chat.completions.create(
        model="llama-3.3-70b-versatile", max_tokens=16,
        messages=[{"role": "user", "content": prompt}])
    return r.choices[0].message.content or ""


def _curl(url, headers, body):
    lines = [f"curl {url} \\"] + [f'  -H "{h}" \\' for h in headers]
    return "\n".join(lines) + f"\n  -d '{json.dumps(body)}'"


def _chat_body(model, prompt):
    return {"model": model, "messages": [{"role": "user", "content": prompt}],
            "max_tokens": 16}


PROVIDERS = {
    "anthropic": {
        "label": "Anthropic", "key_env": "ANTHROPIC_API_KEY",
        "default_model": "claude-haiku-4-5", "call": _anthropic_call,
        "curl": lambda p: _curl(
            "https://api.anthropic.com/v1/messages",
            ["x-api-key: $ANTHROPIC_API_KEY", "anthropic-version: 2023-06-01",
             "content-type: application/json"],
            _chat_body("claude-haiku-4-5", p)),
    },
    "openai": {
        "label": "OpenAI", "key_env": "OPENAI_API_KEY",
        "default_model": "gpt-4o-mini", "call": _openai_call,
        "curl": lambda p: _curl(
            "https://api.openai.com/v1/chat/completions",
            ["Authorization: Bearer $OPENAI_API_KEY",
             "content-type: application/json"],
            _chat_body("gpt-4o-mini", p)),
    },
    "google": {
        "label": "Google Gemini", "key_env": "GEMINI_API_KEY",
        "default_model": "gemini-2.5-flash", "call": _google_call,
        "curl": lambda p: _curl(
            '"https://generativelanguage.googleapis.com/v1beta/models/'
            'gemini-2.5-flash:generateContent?key=$GEMINI_API_KEY"',
            ["content-type: application/json"],
            {"contents": [{"parts": [{"text": p}]}]}),
    },
    "groq": {
        "label": "Groq", "key_env": "GROQ_API_KEY",
        "default_model": "llama-3.3-70b-versatile", "call": _groq_call,
        "curl": lambda p: _curl(
            "https://api.groq.com/openai/v1/chat/completions",
            ["Authorization: Bearer $GROQ_API_KEY",
             "content-type: application/json"],
            _chat_body("llama-3.3-70b-versatile", p)),
    },
}


def _has_key(v):
    if v["key_env"] == "GEMINI_API_KEY":
        return bool(os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY"))
    return bool(os.getenv(v["key_env"]))


def _status_of(e):
    code = getattr(e, "status_code", None) or getattr(e, "code", None) \
        or getattr(getattr(e, "response", None), "status_code", None)
    return code if isinstance(code, int) else None


def _connection_test(provider, prompt):
    v = PROVIDERS[provider]
    curl = v["curl"](prompt)
    if not _has_key(v):
        return {"ok": False, "reason": "no_key",
                "message": f"{v['key_env']} not set", "curl": curl}
    t0 = time.time()
    try:
        reply = v["call"](prompt)
        ms = int((time.time() - t0) * 1000)
        return {"ok": True, "status": 200, "latency_ms": ms,
                "reply": reply.strip(), "curl": curl}
    except Exception as e:
        return {"ok": False, "reason": "error", "status": _status_of(e),
                "message": str(e), "curl": curl}


# ---------------------------------------------------------------------------
# The app
# ---------------------------------------------------------------------------

app = FastAPI(title="Life of an LLM Request — connection test backend")
app.add_middleware(CORSMiddleware, allow_origins=["*"],
                   allow_methods=["*"], allow_headers=["*"])


@app.get("/api/health")
def health():
    return {pid: {"label": v["label"], "key_env": v["key_env"],
                  "has_key": _has_key(v)} for pid, v in PROVIDERS.items()}


@app.get("/api/vendors")
def vendors():
    return [{"id": pid, "label": v["label"], "default_model": v["default_model"]}
            for pid, v in PROVIDERS.items()]


@app.get("/api/connection_test")
async def connection_test(provider: str = "anthropic",
                          prompt: str = "Say 'ok'."):
    if provider not in PROVIDERS:
        return {"ok": False, "reason": "error",
                "message": f"unknown provider '{provider}'"}
    return await run_in_threadpool(_connection_test, provider, prompt)
