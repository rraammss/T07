/* ============================================================================
   app.js — boot + global wiring. Loaded LAST. Fetches the provider list and
   key status from the backend, fills the dropdown, and wires the tab bar.
   ============================================================================ */

Promise.all([
  fetch(API+"/api/vendors").then(r=>r.json()),
  fetch(API+"/api/health").then(r=>r.json()),
]).then(([vs,health])=>{
  VENDORS=vs; connProv=vs[0].id;
  $("#keychips").innerHTML=Object.values(health).map(h=>{
    const url=KEY_PAGES[h.key_env];
    const link=url?` <a class="getkey" href="${url}" target="_blank" rel="noopener" title="Open the provider's key portal — green only means the env var is SET, not that the key is valid">portal ↗</a>`:"";
    return `<span class="chip ${h.has_key?'on':'off'}"><span class="statusdot"></span>${h.key_env}${link}</span>`;
  }).join("");
  $("#conn-prov").innerHTML=vs.map(v=>`<option value="${v.id}">${v.label}</option>`).join("");
  $("#conn-prov").onchange=e=>connProv=e.target.value;
});

/* ---- tab bar wiring ---- */
$$(".tab").forEach(t=>t.onclick=()=>{
  $$(".tab").forEach(x=>x.classList.remove("sel")); t.classList.add("sel");
  $$(".panel").forEach(p=>p.classList.remove("sel")); $("#p-"+t.dataset.t).classList.add("sel");
});
