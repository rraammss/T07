/* ============================================================================
   core.js — shared state and small helpers. Loaded FIRST.
   ============================================================================ */

const API = (window.BACKEND_URL || "").replace(/\/$/,"");
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
let VENDORS=[];
let connProv;

const KEY_PAGES={
  "OPENAI_API_KEY":"https://platform.openai.com/api-keys",
  "ANTHROPIC_API_KEY":"https://console.anthropic.com/settings/keys",
  "GEMINI_API_KEY":"https://aistudio.google.com/app/apikey",
  "GROQ_API_KEY":"https://console.groq.com/keys",
};

function esc(s){ return (s||"").replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c])); }
