# The Life of an LLM Request — connection test

A hands-on companion to the lifecycle slides. Current build ships **Tab 1 only**
(Connection test). All other tabs are marked **coming soon** in the UI.

```
llm_app/
  docker-compose.yml        runs BOTH containers
  .env.example              copy → .env, paste your keys
  backend/                  FastAPI — ONE file
    Dockerfile
    requirements.txt        fastapi + the 4 official SDKs
    app/main.py             the entire backend (health, vendors, connection_test)
  frontend/                 static UI, served by nginx
    Dockerfile  nginx.conf  index.html
    css/styles.css
    js/core.js  tab-connection.js  app.js
```

## Run

```bash
cp .env.example .env            # paste real keys
docker compose up --build
# open http://localhost:8080
```

The **frontend** (nginx, :8080) serves the page and proxies `/api/*` to the
**backend** container (uvicorn, :8000).

## What the backend does

`backend/app/main.py` is self-contained and shareable as a single file:

- `GET /api/health` — which API keys are present in the environment
- `GET /api/vendors` — provider list (Anthropic, OpenAI, Google Gemini, Groq)
- `GET /api/connection_test?provider=...&prompt=...` — one tiny real call via
  the provider's OWN official SDK; returns `{ok, status, latency_ms, reply, curl}`

Keys are read from `.env` at startup — never entered in the browser. The
equivalent `curl` (with the key shown as `$ENV_VAR`) is returned with every
response so students can see that an API call is just an HTTP request.

## Coming soon (removed from this build, tabs greyed in the UI)

Error codes · Text payload and conversation · File upload · Image · Audio · Video
