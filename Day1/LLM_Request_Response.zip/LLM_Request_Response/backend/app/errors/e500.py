"""
errors/e500.py — 500 Internal server error. Dies INSIDE the model server (GPU run).

This is the retry class. Unlike 4xx, you CANNOT craft a 500 from the client —
it's the server failing, not your request. That is the whole lesson: the right
response is not "fix the request", it's "retry with exponential backoff".
execute() is honest about this and returns the backoff plan the UI animates.
"""
from ._util import result

CODE = "500"; NAME = "Internal server error"
LABEL = "Crashed"; ZONE = "gpu"; CLASS = "retry"
WHY = "the model server hit an unexpected error while handling a valid request"
REMEDY = "Retry with exponential backoff — it's server-side, not your request."
RETRYABLE = True
BACKOFF = [{"attempt": 1, "wait_s": 0}, {"attempt": 2, "wait_s": 1},
           {"attempt": 3, "wait_s": 2}, {"attempt": 4, "wait_s": 4}]


def prepare(vendor):
    req = {"client_api_key": f"${vendor.key_env} (real key)",
           "model": vendor.default_model,
           "messages": [{"role": "user", "content": "hi"}], "max_tokens": 8,
           "_note": "a perfectly valid request — 500 comes from the server, not from you"}
    steps = [
        {"label": "request is fine", "detail": "nothing to craft — a normal, valid call"},
        {"label": "server-side fault", "detail": "the model server errors while handling it"},
        {"label": "the fix", "detail": "exponential backoff: retry after 1s, 2s, 4s …"},
    ]
    return {"display": req, "display_pretty": None, "steps": steps, "backoff": BACKOFF}


def execute(vendor):
    # Not client-reproducible on demand — and saying so IS the teaching point.
    return result(CODE, "n/a",
                  "server-side — can't be triggered from the client; retry with backoff",
                  label=LABEL, zone=ZONE, cls=CLASS, remedy=REMEDY)
