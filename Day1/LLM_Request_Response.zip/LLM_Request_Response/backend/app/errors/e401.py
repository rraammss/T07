"""
errors/e401.py — 401 Authentication. Dies at the API gateway's identity check.

REPRODUCTION (safe): env keeps the GOOD key untouched. We build a fresh SDK
client with an EXPLICIT wrong key and make one otherwise-normal call.
"""
from ._util import status_of, result, pretty, headers_of

CODE = "401"; NAME = "Authentication"
LABEL = "Bad key"; ZONE = "gateway"; CLASS = "fix"
WHY = "who are you? — the API key is missing or wrong"
REMEDY = "Check the API key and the env var it is read from."
BAD_KEY = "sk-invalid-key-for-demo-00000000000000000000"


def prepare(vendor):
    req = {
        "sdk_call": ("client.messages.create(...)" if vendor.id == "anthropic"
                     else "client.chat.completions.create(...)"),
        "client_api_key": BAD_KEY,          # <-- the fault, shown explicitly
        "model": vendor.default_model,
        "messages": [{"role": "user", "content": "hi"}],
        "max_tokens": 8,
    }
    steps = [
        {"label": "use a fresh client", "detail": f"vendor.client(api_key='{BAD_KEY[:22]}…')"},
        {"label": "env untouched", "detail": f"{vendor.key_env} in the environment is NOT modified"},
        {"label": "build request", "detail": "a normal, well-formed 'hi' message"},
        {"label": "will send", "detail": "one call with the bad-key client → identity gate rejects it"},
    ]
    return {"display": req, "display_pretty": pretty(req), "steps": steps}


def execute(vendor):
    try:
        client = vendor.client(api_key=BAD_KEY)     # explicit wrong key; env safe
        if vendor.id == "anthropic":
            client.messages.create(model=vendor.default_model, max_tokens=8,
                                   messages=[{"role": "user", "content": "hi"}])
        else:
            client.chat.completions.create(model=vendor.default_model, max_tokens=8,
                                          messages=[{"role": "user", "content": "hi"}])
        return result(CODE, "200", "unexpectedly accepted the bad key",
                      label=LABEL, zone=ZONE, cls=CLASS, remedy=REMEDY)
    except Exception as e:
        return result(CODE, status_of(e),
                      "fresh client used an explicit invalid key; env key never changed",
                      str(e), headers=headers_of(e),
                      label=LABEL, zone=ZONE, cls=CLASS, remedy=REMEDY)
