"""errors/e403.py — 403 Authorization. Good key, model not entitled. Dies at the API gateway."""
from ._util import status_of, result, pretty

CODE = "403"; NAME = "Authorization / permission"
LABEL = "Not allowed"; ZONE = "gateway"; CLASS = "fix"
WHY = "valid key, but not allowed to use this model or org"
REMEDY = "Use an entitled model, or check org / project permissions."
FORBIDDEN = {"anthropic": "claude-opus-4-1-forbidden", "openai": "gpt-4-forbidden-tier"}


def prepare(vendor):
    model = FORBIDDEN.get(vendor.id, "no-such-model")
    req = {"client_api_key": f"${vendor.key_env} (the REAL key from env)",
           "model": model, "messages": [{"role": "user", "content": "hi"}], "max_tokens": 8}
    steps = [
        {"label": "use good key", "detail": f"{vendor.key_env} from env — authentication passes"},
        {"label": "craft the fault", "detail": f"model='{model}' (not entitled)"},
        {"label": "will send", "detail": "identity passes; authorization fails"},
    ]
    return {"display": req, "display_pretty": pretty(req), "steps": steps}


def execute(vendor):
    if not vendor.has_key():
        return result(CODE, "no_key", f"{vendor.key_env} not set",
                      label=LABEL, zone=ZONE, cls=CLASS, remedy=REMEDY)
    model = FORBIDDEN.get(vendor.id, "no-such-model")
    payload = vendor.build_payload(model=model, system="", user="hi", history=[],
                                   stream=False, max_tokens=8)
    r = vendor.send(payload)
    got = r.get("status") or ("200" if r.get("ok") else "err")
    return result(CODE, got, "valid key, model/tier not permitted (some providers say 404)",
                  r.get("raw", ""), headers=r.get("headers", {}),
                  label=LABEL, zone=ZONE, cls=CLASS, remedy=REMEDY)
