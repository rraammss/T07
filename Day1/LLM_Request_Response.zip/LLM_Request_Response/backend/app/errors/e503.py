"""errors/e503.py — 503 Service unavailable. Retry class — dies at the model server."""
from ._util import result

CODE = "503"; NAME = "Service unavailable"
LABEL = "Unavailable"; ZONE = "gpu"; CLASS = "retry"
WHY = "the service is temporarily down or restarting"
REMEDY = "Retry with backoff; the service is temporarily unavailable."
RETRYABLE = True
BACKOFF = [{"attempt": 1, "wait_s": 0}, {"attempt": 2, "wait_s": 1},
           {"attempt": 3, "wait_s": 2}, {"attempt": 4, "wait_s": 4}]


def prepare(vendor):
    req = {"client_api_key": f"${vendor.key_env} (real key)",
           "model": vendor.default_model,
           "messages": [{"role": "user", "content": "hi"}], "max_tokens": 8,
           "_note": "valid request — 503 means the service, not you, is unavailable"}
    steps = [
        {"label": "request is fine", "detail": "a normal, valid call"},
        {"label": "service down", "detail": "temporary — deploy, restart, capacity"},
        {"label": "the fix", "detail": "back off and retry; honor Retry-After if present"},
    ]
    return {"display": req, "display_pretty": None, "steps": steps, "backoff": BACKOFF}


def execute(vendor):
    return result(CODE, "n/a",
                  "transient service outage — not client-reproducible; retry with backoff",
                  label=LABEL, zone=ZONE, cls=CLASS, remedy=REMEDY)
