"""
errors/_util.py — shared helpers.

Two-phase design so the UI can SHOW the exact crafted request before sending:
  * prepare(vendor) -> {"display": <the request we'll send>, "trace": [...] }
  * execute(vendor) -> actually fires it, returns {status, matched, raw, ...}

Reproduction is safe: we never mutate os.environ. Auth faults are produced by
passing an explicit wrong key into a fresh client via vendor.client(api_key=...).

Every module also declares WHERE on the request's journey it dies, so the UI
can pin it on the gauntlet (matches the "Life of an LLM Request" deck):

  LABEL  — one/two words the student remembers ("Bad key", "Too big")
  ZONE   — the station that owns the failure (see ZONES below)
  CLASS  — "fix"  = your fault, dies before the model runs -> change the request
           "retry"= not your fault, server-side -> exponential backoff
  REMEDY — the one-line "what to do about it"
"""
import json
from typing import Any, Dict, List, Optional

# The stations of the journey, left -> right, straight from the deck.
# The UI colors these with the project bundle palette
# (edge = amber, gateway = blue, model/gpu = green).
ZONES: List[Dict[str, str]] = [
    {"id": "device",  "name": "Your device"},
    {"id": "corp",    "name": "Corporate gateway"},
    {"id": "edge",    "name": "Provider edge / CDN"},
    {"id": "gateway", "name": "API gateway"},
    {"id": "model",   "name": "Model server"},
    {"id": "gpu",     "name": "GPU / model runs"},
]
ZONE_ORDER = {z["id"]: i for i, z in enumerate(ZONES)}


def status_of(e: Exception) -> Optional[int]:
    code = getattr(e, "status_code", None)
    if code:
        return code
    resp = getattr(e, "response", None)
    if resp is not None and getattr(resp, "status_code", None):
        return resp.status_code
    s = str(e)
    for guess in ("400", "401", "403", "404", "413", "429", "500", "503", "529"):
        if guess in s:
            return int(guess)
    return None


# Header names worth surfacing — this is where the actionable info lives.
_HEADER_KEYS = (
    "retry-after",
    "anthropic-ratelimit-requests-remaining",
    "anthropic-ratelimit-tokens-remaining",
    "x-ratelimit-remaining-requests",
    "x-ratelimit-remaining-tokens",
    "x-ratelimit-remaining",
    "request-id",
    "x-request-id",
)


def headers_of(e: Exception) -> Dict[str, str]:
    """Pull the few response headers that actually help debugging."""
    resp = getattr(e, "response", None)
    h = getattr(resp, "headers", None)
    if not h:
        return {}
    out: Dict[str, str] = {}
    for k in _HEADER_KEYS:
        try:
            v = h.get(k)
        except Exception:
            v = None
        if v is not None:
            out[k] = str(v)
    return out


def pretty(obj: Any) -> str:
    try:
        return json.dumps(obj, indent=2)[:2000]
    except Exception:
        return str(obj)[:2000]


def result(expected: str, got, note: str, raw: str = "",
           headers: Optional[Dict[str, str]] = None,
           label: str = "", zone: str = "", cls: str = "",
           remedy: str = "") -> Dict[str, Any]:
    return {
        "expected": expected,
        "status": got,
        "matched": str(got) == str(expected),
        "note": note,
        "raw": (raw or "")[:800],
        "headers": headers or {},
        "label": label,
        "zone": zone,
        "class": cls,
        "remedy": remedy,
    }
