"""errors/__init__.py — registry. Each module: CODE, NAME, LABEL, ZONE, CLASS, WHY, REMEDY, prepare(v), execute(v)."""
from types import ModuleType
from typing import Dict, List
from . import e401, e403, e400, e404, e413, e429, e500, e503, e529
from ._util import ZONES

# Ordered by where they die on the journey: edge -> gateway -> gpu.
MODULES: List[ModuleType] = [e413, e401, e403, e404, e429, e400, e500, e503, e529]
REGISTRY: Dict[str, ModuleType] = {m.CODE: m for m in MODULES}


def _meta(m: ModuleType) -> Dict:
    return {
        "code": m.CODE,
        "name": m.NAME,
        "why": m.WHY,
        "label": getattr(m, "LABEL", ""),
        "zone": getattr(m, "ZONE", ""),
        "class": getattr(m, "CLASS", "fix"),
        "remedy": getattr(m, "REMEDY", ""),
        "retryable": bool(getattr(m, "RETRYABLE", False)),
    }


def meta_list():
    return [_meta(m) for m in MODULES]


def zones():
    """The gauntlet stations, left -> right, for the UI to render."""
    return ZONES


def get(code: str) -> ModuleType:
    if code not in REGISTRY:
        raise KeyError(f"unknown error code '{code}'")
    return REGISTRY[code]
