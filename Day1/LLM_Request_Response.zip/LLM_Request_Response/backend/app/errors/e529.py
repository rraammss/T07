"""errors/e529.py — 529 Overloaded (Anthropic). Retry class — the model fleet is saturated."""
from ._util import result

CODE = "529"; NAME = "Overloaded"
LABEL = "Overloaded"; ZONE = "gpu"; CLASS = "retry"
WHY = "the model is temporarily overloaded — too much traffic right now"
REMEDY = "Anthropic is overloaded — retry with backoff."
RETRYABLE = True
BACKOFF = [{"attempt": 1, "wait_s": 0}, {"attempt": 2, "wait_s": 1},
           {"attempt": 3, "wait_s": 2}, {"attempt": 4, "wait_s": 4}]


def prepare(vendor):
    req = {"client_api_key": f"${vendor.key_env} (real key)",
           "model": vendor.default_model,
           "messages": [{"role": "user", "content": "hi"}], "max_tokens": 8,
           "_note": "Anthropic-specific: 529 = fleet saturated, distinct from your per-key 429"}
    steps = [
        {"label": "request is fine", "detail": "a normal, valid call"},
        {"label": "fleet saturated", "detail": "529 is provider-wide load, not your quota"},
        {"label": "the fix", "detail": "back off and retry — it clears on its own"},
    ]
    return {"display": req, "display_pretty": None, "steps": steps, "backoff": BACKOFF}


def execute(vendor):
    return result(CODE, "n/a",
                  "provider overloaded — not client-reproducible; retry with backoff",
                  label=LABEL, zone=ZONE, cls=CLASS, remedy=REMEDY)
