"""
routes/_shared.py — helpers used by more than one router.
"""
import base64
from .. import documents


def attach_kwargs(d):
    """From the request dict, return the attachment kwargs for build_payload,
    extracting document text (PDF via pypdf, Word via python-docx) so providers
    that can't take a document block (OpenAI, Groq) can inline the text.

    If raw_document is set, we DON'T inline — we force the native document/image
    block even on providers that reject it, so the real API error surfaces
    (a deliberate teaching demonstration)."""
    b64 = d.get("attachment_b64")
    media = d.get("attachment_media", "application/pdf")
    raw_document = bool(d.get("raw_document"))
    text = None
    if b64 and not raw_document:
        try:
            raw = base64.b64decode(b64)
            text = documents.extract_text(raw, media)
        except Exception:
            text = None
    return {"attachment_b64": b64, "attachment_media": media,
            "attachment_text": text, "raw_document": raw_document}


def clean_history(history):
    """Keep ONLY role + content on each history message.

    The UI attaches presentation-only keys (e.g. `doc` for the paperclip badge)
    to conversation turns. Providers reject unknown fields — Anthropic's
    count_tokens API returns 400 'Extra inputs are not permitted' — so we strip
    every message down to what the API actually accepts before forwarding it.
    """
    out = []
    for m in history or []:
        if not isinstance(m, dict):
            continue
        content = m.get("content", "")
        # Drop empty turns — an empty text block makes providers 400
        # ("text content blocks must be non-empty" / "must have non-empty content").
        if isinstance(content, str) and not content.strip():
            continue
        if isinstance(content, (list, tuple)) and len(content) == 0:
            continue
        out.append({"role": m.get("role", "user"), "content": content})
    return out
