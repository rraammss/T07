"""routes/errors_routes.py — Tab 2: prepare a request for a target HTTP error, then fire it.

Two-phase (prepare/execute) so the UI shows the exact crafted request before
anything is sent. execute can target one provider OR fan out to BOTH so the
class sees the same fault land on different codes across providers.
"""
import asyncio
from fastapi import APIRouter
from fastapi.concurrency import run_in_threadpool
from .. import vendors, errors

router = APIRouter()


@router.get("/api/errors")
def error_meta():
    return errors.meta_list()


@router.get("/api/error_zones")
def error_zones():
    """The gauntlet stations (device -> corp -> edge -> gateway -> model -> gpu)."""
    return errors.zones()


@router.get("/api/error_prepare")
async def error_prepare(provider: str = "anthropic", code: str = "401"):
    """Return the exact crafted request + steps — nothing is sent yet."""
    v = vendors.get(provider); mod = errors.get(code)
    return await run_in_threadpool(mod.prepare, v)


@router.get("/api/error_execute")
async def error_execute(provider: str = "anthropic", code: str = "401"):
    """Actually fire the crafted request and return the result."""
    v = vendors.get(provider); mod = errors.get(code)
    return await run_in_threadpool(mod.execute, v)


@router.get("/api/error_execute_both")
async def error_execute_both(code: str = "401", providers: str = "anthropic,openai"):
    """Fire the SAME fault at several providers concurrently.

    This is the payoff demo: one logical fault, different codes/messages per
    provider (e.g. an unentitled model is 403 on one, 404 on another).
    """
    ids = [p.strip() for p in providers.split(",") if p.strip()]
    mod = errors.get(code)

    async def one(pid: str):
        try:
            v = vendors.get(pid)
        except KeyError:
            return pid, {"status": "n/a", "note": f"unknown provider '{pid}'",
                         "matched": False, "headers": {}, "label": getattr(mod, "LABEL", ""),
                         "zone": getattr(mod, "ZONE", ""), "class": getattr(mod, "CLASS", ""),
                         "remedy": getattr(mod, "REMEDY", "")}
        res = await run_in_threadpool(mod.execute, v)
        return pid, res

    pairs = await asyncio.gather(*(one(p) for p in ids))
    return {"code": code, "results": {pid: res for pid, res in pairs}}
