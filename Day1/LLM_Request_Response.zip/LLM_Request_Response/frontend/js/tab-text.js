/* ============================================================================
   tab-text.js — Tab 3: the Text payload & conversation tab.
   Build a request, see the exact JSON, measure tokens + wire size, send it,
   and watch the conversation (and its cost) grow turn by turn.
   ============================================================================ */

// ===== TAB 3 =====
async function fetchCtx(){
  const q=new URLSearchParams({provider:plProv,model:$("#pl-model").value});
  try{ const c=await (await fetch(API+"/api/context?"+q)).json();
    if(c.context_window){
      $("#ctx-line").innerHTML=`<span style="color:var(--navy);font-size:15px"><b>${c.context_window.toLocaleString()} tokens</b> · max output <b>${(c.max_output||0).toLocaleString()}</b></span>
        <span class="pill" style="margin-left:8px">${esc(c.source)}</span>
        <div class="muted mono" style="margin-top:4px">endpoint: ${esc(c.endpoint)}</div>`;
      window._ctx=c;
    } else { $("#ctx-line").textContent="unknown model"; window._ctx=null; }
  }catch(e){ $("#ctx-line").textContent="(couldn't fetch)"; }
}
$("#ctx-refresh").onclick=fetchCtx;

$("#pl-file").onchange=async e=>{
  const f=e.target.files[0];
  if(!f){ attachB64=null; $("#pl-fnote").textContent=""; $("#pl-enc").style.display="none"; return; }
  const okTypes=["application/pdf","application/vnd.openxmlformats-officedocument.wordprocessingml.document"];
  if(!okTypes.includes(f.type) && !/\.(pdf|docx)$/i.test(f.name)){
    $("#pl-fnote").innerHTML='<span class="bad">✕ PDF or Word (.docx) only — no image / audio / video.</span>';
    attachB64=null; $("#pl-enc").style.display="none"; return;
  }
  $("#pl-fnote").innerHTML='<span class="spin"></span> reading &amp; base64-encoding…';
  const buf=await f.arrayBuffer(); let bin=""; new Uint8Array(buf).forEach(b=>bin+=String.fromCharCode(b));
  const b64=btoa(bin);
  attachMedia=f.type||(/\.pdf$/i.test(f.name)?"application/pdf":"application/vnd.openxmlformats-officedocument.wordprocessingml.document");
  const j=await (await fetch(API+"/api/attach",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({media_type:attachMedia,b64})})).json();
  if(!j.ok){ $("#pl-fnote").innerHTML='<span class="bad">✕ '+esc(j.message)+'</span>'; attachB64=null; $("#pl-enc").style.display="none"; return; }
  attachB64=j.b64;
  window._attachText=j.extracted_text||null;
  window._attachName=f.name;
  $("#pl-fnote").innerHTML=`✓ <b>${esc(f.name)}</b> <button class="removeattach" id="pl-removeattach" title="remove attachment">✕ remove</button>`;
  document.getElementById("pl-removeattach").onclick=removeAttachment;
  $("#pl-enc").style.display="block";
  // MIME — friendly label + browser-vs-bytes (truncated, full on hover) + agree/disagree
  const bm=f.type||"(none reported)";
  const friendly=mimeLabel(j.resolved_media);
  const agree=!j.mime_mismatch;
  let mimehtml=`<div class="mimehead"><span class="mimekind">${esc(friendly)}</span>
      <span class="mimeflag ${agree?'ok':'warn'}">${agree?'✓ browser &amp; bytes agree':'⚠ browser &amp; bytes disagree'}</span></div>
    <div class="mimerow"><span class="k">browser says</span><span class="v" title="${esc(bm)}">${esc(mimeShort(bm))}</span></div>
    <div class="mimerow"><span class="k">bytes say</span><span class="v" title="${esc(j.resolved_media)}">${esc(mimeShort(j.resolved_media))}</span></div>`;
  if(j.mime_mismatch) mimehtml+=`<div class="mimewarn">the browser's guess (usually from the file extension) doesn't match what the bytes actually are — the bytes win.</div>`;
  $("#pl-mime").innerHTML=mimehtml;
  // remember the file facts so we can show "what's actually sent" per provider
  window._attach={raw:j.raw_bytes, b64:j.b64_bytes, ratio:j.ratio, chars:j.extracted_chars, resolved:j.resolved_media};
  window._attachResolved=j.resolved_media;
  renderAttachSize();
  renderCompat();
  $("#pl-rawwrap").style.display="flex";
  scheduleJsonRefresh();
};

function removeAttachment(){
  attachB64=null; attachMedia=null; window._attach=null; window._attachResolved=null;
  window._attachText=null; window._attachName=null;
  $("#pl-file").value="";                    // reset the file input
  $("#pl-fnote").innerHTML="";
  $("#pl-enc").style.display="none";
  $("#pl-compat").style.display="none";
  $("#pl-rawwrap").style.display="none";
  const raw=document.getElementById("pl-raw"); if(raw) raw.checked=false;
  scheduleJsonRefresh();
  if($("#pl-size").style.display!=="none") refreshSizing();
}

document.getElementById("pl-raw").addEventListener("change", scheduleJsonRefresh);

function renderAttachSize(){
  const a=window._attach; if(!a){ return; }
  // "the file" — base64 inflation (the encoding lesson)
  $("#enc-size").textContent=`${fmt(a.raw)} → ${fmt(a.b64)}`;
  $("#enc-detail").innerHTML=`the file itself, base64-encoded <span class="muted">(+33% over the ${fmt(a.raw)} raw file)</span>`;
  // "text inside" is a SEPARATE measurement — make that explicit so it doesn't look like a ratio
  if(a.chars!=null){
    $("#enc-textinside").style.display="block";
    $("#enc-textinside").innerHTML=`text inside the file: <b>${a.chars.toLocaleString()} chars</b> (~${fmt(a.chars)}) <span class="muted">— a PDF is a binary container; its words are only a slice of the file, so this is unrelated to the ${fmt(a.b64)} above</span>`;
  } else { $("#enc-textinside").style.display="none"; }
  // "what THIS provider actually sends"
  const readsDirect=(plProv==="anthropic"||plProv==="google");
  const label=VENDORS.find(x=>x.id===plProv);
  const provName=label?label.label:plProv;
  let sent;
  if(readsDirect){
    sent=`sent to <b>${esc(provName)}</b>: the <b>whole file</b> (${fmt(a.b64)} base64) <span class="muted">(reads PDFs natively)</span>`;
  } else {
    const approx=a.chars!=null?fmt(a.chars):"—";
    sent=`sent to <b>${esc(provName)}</b>: only the <b>extracted text</b> (~${approx}), not the ${fmt(a.b64)} file <span class="muted">(can't take a PDF)</span>`;
  }
  $("#enc-sent").innerHTML=sent;
}

// per-provider compatibility for the attached file — two plain groups
function renderCompat(){
  if(!attachB64){ $("#pl-compat").style.display="none"; $("#pl-rawwrap").style.display="none"; return; }
  $("#pl-compat").style.display="block";
  $("#pl-compat").innerHTML=
    `<div class="compatgroup ok"><div class="cg-head">✓ Reads the file directly</div>
       <div class="cg-body">Anthropic · Gemini</div></div>
     <div class="compatgroup warn"><div class="cg-head">⚠ Needs text extracted first</div>
       <div class="cg-body">OpenAI · Groq <span class="muted">— the app sends the extracted text instead</span></div></div>`;
}

function payloadReq(stream){
  return {provider:plProv, model:$("#pl-model").value, system:$("#pl-system").value, user:$("#pl-user").value,
    history:conv.map(m=>({role:m.role, content:m.content})), stream, max_tokens:parseInt($("#pl-max").value||"300"),
    attachment_b64:attachB64, attachment_media:attachMedia,
    raw_document: $("#pl-raw") && $("#pl-raw").checked};
}

let _jsonTimer=null;
async function refreshJsonOnly(){
  const j=await (await fetch(API+"/api/build",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify(payloadReq(plMode==="stream"))})).json();
  renderJsonTree(j.payload); $("#jsonctl").style.display="flex";
}
function scheduleJsonRefresh(){ clearTimeout(_jsonTimer); _jsonTimer=setTimeout(refreshJsonOnly, 400); }

async function refreshSizing(){
  const j=await (await fetch(API+"/api/build",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify(payloadReq(plMode==="stream"))})).json();
  renderJsonTree(j.payload);
  $("#jsonctl").style.display="flex";
  $("#pl-size").style.display="block";
  const b=j.bytes;
  // Token counting needs a non-empty final user turn; the JSON + wire size don't.
  // Skip the count (and its provider call) when the message box is empty — e.g. the
  // auto-refresh right after a Send clears it — so we never send an empty text block.
  if(!(($("#pl-user").value||"").trim())){
    $("#tok-head").innerHTML='<span class="muted">Type a user message and click <b>Calculate input tokens &amp; size</b> to count tokens.</span>';
    $("#tokbar").style.display="none"; $("#tokbar-legend").style.display="none";
    $("#tok-fit").innerHTML=""; $("#tok-method").innerHTML="";
    renderWireTable(b);
    return;
  }
  const t=await (await fetch(API+"/api/count_tokens",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify(payloadReq(plMode==="stream"))})).json();
  const tok=t.tokenizer, fit=t.fit, bd=t.breakdown;
  $("#tok-method").innerHTML=`counted with <b>${esc(tok.method)}</b> — ${esc(tok.note)}`;
  if(fit && bd){
    renderTokenBar(bd, fit);
    if(window.renderWindowBar) renderWindowBar(bd, fit);
  } else {
    $("#tok-head").innerHTML=tok.tokens!=null?`<b style="font-size:20px">${tok.tokens.toLocaleString()}</b> input tokens (context unknown)`:`<span class="bad">${esc(tok.note)}</span>`;
    $("#tokbar").style.display="none"; $("#tokbar-legend").style.display="none"; $("#tok-fit").innerHTML="";
  }
  renderWireTable(b);
}
// ---- require a non-empty user message before counting or sending ----
function showUserError(msg){
  let e=document.getElementById("pl-user-err");
  if(!e){
    e=document.createElement("div");
    e.id="pl-user-err";
    e.style.cssText="color:var(--red);font-size:12px;font-weight:700;margin-top:6px;display:none;";
    const host=$("#pl-user"); if(host) host.insertAdjacentElement("afterend", e);
  }
  if(e){ e.textContent=msg||""; e.style.display=msg?"block":"none"; }
}
function requireUser(){
  const v=($("#pl-user").value||"").trim();
  if(!v){
    showUserError("Type a user message first — the model needs non-empty content to size or send.");
    $("#pl-user").style.borderColor="var(--red)";
    $("#pl-user").focus();
    return false;
  }
  showUserError(""); $("#pl-user").style.borderColor="";
  return true;
}
// clear the error the moment they start typing
$("#pl-user").addEventListener("input", ()=>{
  if(($("#pl-user").value||"").trim()){ showUserError(""); $("#pl-user").style.borderColor=""; }
});

$("#pl-calc").onclick=async()=>{
  if(!requireUser()) return;
  $("#pl-status").innerHTML='<span class="spin"></span> building &amp; counting…';
  await refreshSizing();
  $("#pl-status").innerHTML="";
};

// ---- token composition bar (cell 0) ----

function renderTokenBar(bd, fit){
  const cw=fit.context_window, reserved=fit.reserved_output, inputTot=fit.input_tokens, total=fit.total_needed;
  $("#tok-head").innerHTML=`<b style="font-size:22px;color:var(--navy)">${inputTot.toLocaleString()}</b> input + <b style="color:var(--amber)">${reserved.toLocaleString()}</b> reserved = <b>${total.toLocaleString()}</b> of ${cw.toLocaleString()} tokens`
    +`<div style="margin-top:4px">${deltaBadge(inputTot, window._lastSentTokens, "tok")} <span class="muted" style="font-size:10.5px">— tokens are what you're billed for</span></div>`;
  const segs=[
    {k:"system",     v:bd.system||0,     c:"s"},
    {k:"history",    v:bd.history||0,    c:"h"},
    {k:"message",    v:bd.message||0,    c:"m"},
    {k:"attachment", v:bd.attachment||0, c:"a"},
  ].filter(s=>s.v>0);
  const pct=v=>Math.max(0.4,100*v/cw);
  let html=segs.map(s=>`<div class="wseg ${s.c}" style="width:${pct(s.v)}%" title="${s.k}: ${s.v.toLocaleString()} tok"></div>`).join("");
  html+=`<div class="wseg out" style="width:${pct(reserved)}%" title="reserved output: ${reserved.toLocaleString()}"></div>`;
  $("#tokbar").style.display="flex"; $("#tokbar").innerHTML=html;
  $("#tokbar-legend").style.display="flex";
  $("#tokbar-legend").innerHTML=
    segs.map(s=>`<span class="wlg ${s.c}">${s.k} <b>${s.v.toLocaleString()}</b></span>`).join("")+
    `<span class="wlg out">reserved <b>${reserved.toLocaleString()}</b></span>`+
    `<span class="wlg free">free <b>${(cw-total).toLocaleString()}</b></span>`;
  $("#tok-fit").innerHTML=fit.fits?`<span class="fitpill yes">✓ fits — ${(100-100*total/cw).toFixed(1)}% headroom</span>`
    :`<span class="fitpill no">✕ exceeds the context window</span>`;
  window._curTokens=inputTot;   // remember for the next baseline snapshot
}

// ---- layered wire size table (cell 1) ----
function renderWireTable(b){
  const rows=[
    {lab:"application data <span class='muted'>(the JSON body — exact)</span>", val:b.app_data_bytes, cls:"l-app"},
    {lab:"+ HTTP headers <span class='muted'>(Authorization, Content-Type, Host… ≈ typical)</span>", val:b.http_header_bytes, cls:"l-http"},
    {lab:`+ TCP/IP framing <span class='muted'>(~${b.tcpip_per_packet} B × ${b.packets} packets ≈)</span>`, val:b.tcpip_bytes, cls:"l-tcp"},
  ];
  let html=rows.map(r=>`<tr><td><span class="ldot ${r.cls}"></span>${r.lab}</td><td class="wv">${fmt(r.val)}</td></tr>`).join("");
  html+=`<tr class="wtotal"><td><b>= total on the wire</b></td><td class="wv"><b>${fmt(b.total_bytes)}</b></td></tr>`;
  $("#wiretable").innerHTML="<tbody>"+html+"</tbody>";
  $("#wire-packets").innerHTML=`${deltaBadge(b.total_bytes, window._lastSentBytes, "B")} <span class="muted" style="font-size:10.5px">— bytes are the data on the wire, not the bill</span>`
    +`<div style="margin-top:6px">chopped into <b>${b.packets} MTU packet${b.packets>1?'s':''}</b> of ${b.mtu} B payload each (ethernet 1500 − 20 IP − 20 TCP) · header sizes are typical estimates, body is exact</div>`
    +`<div class="unitnote">tokens ≠ bytes: the <b>model</b> counts <b>tokens</b> (~4 characters each — "concise" is 1 token), the <b>network</b> counts <b>bytes</b> (1 character ≈ 1 byte). That's why your 37-character system prompt is ~7 tokens but ~37 bytes.</div>`;
  window._curBytes=b.total_bytes;
}

// ---- JSON colored collapsible tree ----

$("#json-expand").onclick=()=>$$("#pl-jsontree .jnode").forEach(n=>{n.classList.remove("collapsed"); const c=n.querySelector(":scope > .jtoggle .jcaret"); if(c)c.textContent="▾";});
$("#json-collapse").onclick=()=>$$("#pl-jsontree .jnode .jnode").forEach(n=>{n.classList.add("collapsed"); const c=n.querySelector(":scope > .jtoggle .jcaret"); if(c)c.textContent="▸";});

$("#pl-send").onclick=async()=>{
  if(!requireUser()) return;
  lastUserSent=$("#pl-user").value;
  $("#pl-resp").innerHTML='<span class="muted">…</span>'; $("#pl-usage").textContent="";
  $("#pl-status").innerHTML='<span class="spin"></span> sending…';
  if(plMode==="stream") await doStream(); else await doJSON();
};
function afterReply(){
  // append this exchange to the conversation automatically on each send
  if(lastUserSent!=null && (lastUserSent||"").trim() && lastReply!=null && (lastReply||"").trim()){
    // If a document was attached, it was inlined into THIS turn's message and sent.
    // Save it into history the same way — so the document is genuinely re-sent on every
    // following turn too (the naive re-attach cost this app is teaching).
    const hadDoc = !!(attachB64 && window._attachText!=null);
    let userContent = lastUserSent;
    if(hadDoc){
      userContent = `${lastUserSent}\n\n[Attached document — extracted text follows]\n${window._attachText}`;
    }
    conv.push({role:"user", content:userContent, doc: hadDoc?window._attachName:null});
    conv.push({role:"assistant", content:lastReply});
    // snapshot what we JUST sent as the baseline for the next request's % comparison
    window._lastSentTokens = window._curTokens ?? null;
    window._lastSentBytes = window._curBytes ?? null;
    renderConv();
    $("#pl-user").value="";
    if($("#pl-size").style.display!=="none") refreshSizing();
  }
}
async function doJSON(){
  const j=await (await fetch(API+"/api/send",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify(payloadReq(false))})).json();
  $("#pl-status").innerHTML="";
  if(j.ok){ lastReply=j.text||""; $("#pl-resp").textContent=lastReply||"(empty)"; $("#pl-usage").textContent=usage(j.usage,j.latency_ms); setRawResponse(j.raw_response); afterReply(); }
  else if(j.reason==="no_key") $("#pl-resp").innerHTML='<span class="bad">'+esc(j.message)+' — set it in .env and restart backend.</span>';
  else $("#pl-resp").innerHTML='<span class="bad">HTTP '+j.status+'</span><pre class="mono small">'+esc((j.raw||'').slice(0,400))+'</pre>';
}
async function doStream(){
  const resp=$("#pl-resp"); resp.innerHTML=''; let acc="",inT=null,outT=null,first=true;
  const r=await fetch(API+"/api/stream",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify(payloadReq(true))});
  const reader=r.body.getReader(),dec=new TextDecoder(); let buf="";
  while(true){ const {value,done}=await reader.read(); if(done)break;
    buf+=dec.decode(value,{stream:true}); const parts=buf.split("\n\n"); buf=parts.pop();
    for(const p of parts){ const line=p.trim(); if(!line.startsWith("data:"))continue;
      const ev=JSON.parse(line.slice(5).trim());
      if(ev.type==="delta"){ if(first){first=false;$("#pl-status").innerHTML="";} acc+=ev.text; resp.innerHTML=esc(acc)+'<span class="cursor">▌</span>'; }
      else if(ev.type==="usage"){ if(ev.input!=null)inT=ev.input; if(ev.output!=null)outT=ev.output; $("#pl-usage").textContent=usage({input_tokens:inT,output_tokens:outT}); }
      else if(ev.type==="error"){ resp.innerHTML='<span class="bad">stream error '+(ev.status||'')+'</span><pre class="mono small">'+esc((ev.raw||ev.message||'').slice(0,400))+'</pre>'; $("#pl-status").innerHTML=""; }
      else if(ev.type==="done"){ lastReply=acc; resp.innerHTML=esc(acc); setRawResponse(null, true); afterReply(); }
    }
  }
}
// ---- response view: reply text vs raw JSON envelope ----
function setRawResponse(raw, streamed){
  window._rawResponse=raw; window._rawStreamed=!!streamed;
  $("#respmode").style.display="flex";
  // default back to text view on each new send
  setRespMode("text");
}
function setRespMode(mode){
  $$("#respmode .rm-btn").forEach(b=>b.classList.toggle("sel", b.dataset.rm===mode));
  if(mode==="text"){
    $("#pl-resp").style.display="block"; $("#pl-resp-json").style.display="none";
  } else {
    $("#pl-resp").style.display="none"; $("#pl-resp-json").style.display="block";
    if(window._rawStreamed){
      $("#pl-resp-json").innerHTML='<div style="color:#9ab;font-size:12px;line-height:1.6">Streaming responses arrive as many small <span style="color:#7fb3e8">delta</span> chunks, not one JSON object — so there is no single raw body to show here.<br><br>Switch <b>Mode</b> to <b>Non-stream</b> and send again to see the full raw JSON response envelope (with <span style="color:#7fb3e8">choices</span>, <span style="color:#7fb3e8">usage</span>, <span style="color:#7fb3e8">finish_reason</span>…).</div>';
    } else if(window._rawResponse){
      renderJsonTreeInto($("#pl-resp-json"), window._rawResponse);
    } else {
      $("#pl-resp-json").innerHTML='<span style="color:#9ab">no raw response captured.</span>';
    }
  }
}
$$("#respmode .rm-btn").forEach(b=>b.onclick=()=>setRespMode(b.dataset.rm));

function renderConv(){
  if(!conv.length){
    $("#conv-list").innerHTML='<span class="muted">no turns yet. Each time you click Send, the exchange is appended here and re-sent as context.</span>';
    $("#conv-hint").style.display="none"; $("#sw-wrap").style.display="none"; return;
  }
  // list (newest at bottom, scrollable) — each turn tagged with its byte size
  let totalBytes=0, docCopies=0, docBytesTotal=0;
  $("#conv-list").innerHTML=conv.map((t,i)=>{
    const bytes=byteLen(t.content);
    totalBytes+=bytes;
    const docTag = t.doc ? `<div class="docmark" title="the whole document was re-attached to this turn">📎 +${esc(t.doc)}</div>` : "";
    if(t.doc){ docCopies++; docBytesTotal+=bytes; }
    // strip the inlined document text from the on-screen preview so it stays readable
    let preview=t.content;
    const cut=preview.indexOf("[Attached document — extracted text follows]");
    if(cut>=0) preview=preview.slice(0,cut).trim()+"  ⟨+ document text⟩";
    return `<div class="turnrow"><div class="role ${t.role}">${t.role}<div class="turnbytes">${fmt(bytes)}</div>${docTag}</div><div class="txt">${esc(preview.slice(0,200))}${preview.length>200?'…':''}</div></div>`;
  }).join("");
  $("#conv-list").scrollTop=$("#conv-list").scrollHeight;
  const turns=conv.length/2;
  $("#conv-hint").style.display="block";
  let hint=`Each Send copies <b>all ${conv.length} messages</b> (${turns} exchange${turns>1?'s':''}) into <span class="mono">messages[]</span> before appending your new user turn — the whole conversation is re-sent and re-billed every request. <b>History content ≈ ${fmt(totalBytes)}</b> rides on every future request.`;
  if(docCopies>0){
    hint+=`<div class="docnote">📎 The document was re-attached on <b>${docCopies} turn${docCopies>1?'s':''}</b> — that's <b>${fmt(docBytesTotal)}</b> of the same file text sent over and over. This is the cost of naive re-attaching; real APIs let you upload a file once and reference it by ID instead.</div>`;
  }
  $("#conv-hint").innerHTML=hint;
  // the bar is driven by the REAL tokenizer — show a prompt until a count runs
  if(!window._lastBreakdown){
    $("#sw-wrap").style.display="block";
    $("#swbar").innerHTML="";
    $("#sw-note").innerHTML='<span class="muted">click <b>Calculate size &amp; input tokens</b> to size this against the window with the real tokenizer.</span>';
  } else {
    renderWindowBar(window._lastBreakdown, window._lastFit);
  }
}

// real-token composition bar: history / system / message / attachment vs the window
function renderWindowBar(bd, fit){
  window._lastBreakdown=bd; window._lastFit=fit;
  $("#sw-wrap").style.display="block";
  const cw=(fit&&fit.context_window)||(window._ctx&&window._ctx.context_window)||200000;
  const reserved=(fit&&fit.reserved_output)||parseInt($("#pl-max").value||"300");
  const segs=[
    {k:"history",    v:bd.history||0,    c:"h"},
    {k:"system",     v:bd.system||0,     c:"s"},
    {k:"message",    v:bd.message||0,    c:"m"},
    {k:"attachment", v:bd.attachment||0, c:"a"},
  ].filter(s=>s.v>0);
  const inputTot=segs.reduce((a,s)=>a+s.v,0);
  const total=inputTot+reserved;
  // scale segments (input parts + reserved output) across the full window width
  const pct=v=>Math.max(0.5,100*v/cw);
  let html=segs.map(s=>`<div class="wseg ${s.c}" style="width:${pct(s.v)}%" title="${s.k}: ${s.v.toLocaleString()} tok"></div>`).join("");
  html+=`<div class="wseg out" style="width:${pct(reserved)}%" title="reserved output: ${reserved.toLocaleString()} tok"></div>`;
  $("#swbar").innerHTML=html;
  const fits=total<=cw;
  $("#sw-note").innerHTML=
    segs.map(s=>`<span class="wlg ${s.c}">${s.k} <b>${s.v.toLocaleString()}</b></span>`).join(" · ")+
    ` · <span class="wlg out">reserved <b>${reserved.toLocaleString()}</b></span>`+
    `<div style="margin-top:5px">input <b>${inputTot.toLocaleString()}</b> + reserved <b>${reserved.toLocaleString()}</b> = <b>${total.toLocaleString()}</b> of ${cw.toLocaleString()} · `+
    (fits?`<span class="ok">fits (${(100-100*total/cw).toFixed(1)}% free)</span>`:`<span class="bad">exceeds the window — oldest history is dropped first</span>`)+`</div>`;
}

