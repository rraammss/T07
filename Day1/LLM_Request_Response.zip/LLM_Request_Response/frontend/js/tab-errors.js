/* ============================================================================
   tab-errors.js — Tab 2: craft a request that triggers a specific HTTP error,
   show WHERE on the journey it dies (the gauntlet), fire it for real, and show
   headers + the fix. Two classes: FIX (4xx, your fault) vs RETRY (5xx, server).
   ============================================================================ */

let errMode = "one";          // "one" | "both"
let curPrep = null;           // last prepared payload (holds backoff for retry class)

function errMeta(code){ return ERRORS.find(e=>e.code===code); }

async function loadZones(){
  if(window.__ZONES) return window.__ZONES;
  try{ window.__ZONES = await (await fetch(API+"/api/error_zones")).json(); }
  catch(e){ window.__ZONES = [
    {id:"device",name:"Your device"},{id:"corp",name:"Corporate gateway"},
    {id:"edge",name:"Provider edge / CDN"},{id:"gateway",name:"API gateway"},
    {id:"model",name:"Model server"},{id:"gpu",name:"GPU / model runs"}]; }
  return window.__ZONES;
}

function zoneName(id){ const z=(window.__ZONES||[]).find(z=>z.id===id); return z?z.name:id; }
function codeZone(code){ const m=ERRORS.find(e=>String(e.code)===String(code)); return m?m.zone:null; }

function renderErrBtns(){
  const mk=e=>`<button class="${e.class==='retry'?'retry':''}" data-code="${e.code}" title="${esc(e.label||e.name)}">${e.code}</button>`;
  $("#err-btns-fix").innerHTML   = ERRORS.filter(e=>e.class!=="retry").map(mk).join("");
  $("#err-btns-retry").innerHTML = ERRORS.filter(e=>e.class==="retry").map(mk).join("");
  $$("#err-btns-fix button, #err-btns-retry button").forEach(b=>b.onclick=()=>prepareErr(b.dataset.code,b));
  // mode toggle (single vs compare-both)
  $$("#err-mode button").forEach(b=>b.onclick=()=>{
    $$("#err-mode button").forEach(x=>x.classList.remove("sel")); b.classList.add("sel");
    errMode=b.dataset.m; if(curErr) prepareErr(curErr);
  });
  loadZones();
}

async function renderGauntlet(zoneId, code, note){
  const zones=await loadZones();
  const died=zones.findIndex(z=>z.id===zoneId);
  const host=$("#err-gauntlet"); host.style.display="block"; host.innerHTML="";
  const strip=document.createElement("div");
  strip.style.display="flex"; strip.style.alignItems="stretch"; strip.style.gap="5px";
  zones.forEach((z,i)=>{
    if(i>0){ const a=document.createElement("div"); a.className="garrow"; a.textContent="›"; strip.appendChild(a); }
    const s=document.createElement("div");
    const state = i<died?"passed" : (i===died?"died":"upcoming");
    s.className=`gstation z-${z.id} ${state}`;
    let inner=`<div class="gs-name">${esc(z.name)}</div>`;
    if(state==="died") inner+=`<div class="gs-code">${esc(String(code))} ✕</div><div class="gs-tag">died here</div>`;
    else inner+=`<div class="gs-tag"></div>`;
    s.innerHTML=inner; strip.appendChild(s);
  });
  host.appendChild(strip);
  if(note){ const n=document.createElement("div"); n.className="gnote"; n.innerHTML=note; host.appendChild(n); }
}

// After firing, move the red marker to where it ACTUALLY died (returned code),
// and call out the mismatch vs where the target code would be caught.
async function repin(meta, statuses){
  const codes=statuses.filter(c=>c!=null && String(c)!=="n/a" && String(c)!=="err");
  if(!codes.length) return;
  const zones=[...new Set(codes.map(codeZone).filter(Boolean))];
  if(zones.length!==1) return;                 // providers died at different stations — leave the aim pin
  const actualZone=zones[0];
  const shown=[...new Set(codes.map(String))].join(" / ");
  let note="";
  if(actualZone!==meta.zone){
    note=`aimed <b>${meta.code}</b> @ ${esc(zoneName(meta.zone))} → actually <b>${esc(shown)}</b> @ ${esc(zoneName(actualZone))} — these providers reject it at the API gateway, not the CDN`;
  }
  await renderGauntlet(actualZone, shown, note);
}

async function prepareErr(code,btn){
  curErr=code;
  $$("#err-btns-fix button, #err-btns-retry button").forEach(x=>x.classList.remove("active"));
  const active = btn || $$("#err-btns-fix button, #err-btns-retry button").find(b=>b.dataset.code===code);
  if(active) active.classList.add("active");
  const meta=errMeta(code);
  const retry = meta.class==="retry";
  $("#err-why").innerHTML=`<b class="mono">${code} · ${esc(meta.label||meta.name)}</b> — ${esc(meta.why)}`
    +`  <span class="muted">· ${retry?'not your fault — retry with backoff':'your fault — fix the request'}</span>`;

  await renderGauntlet(meta.zone, code);

  // reset result area to a single "not sent" column
  setCols(1);
  $("#err-result").innerHTML='<span class="muted">not sent yet — review the request on the left, then click <b>Send this request</b>.</span>';

  const q=new URLSearchParams({provider:errProv,code});
  const j=await (await fetch(API+"/api/error_prepare?"+q)).json();
  curPrep=j;
  const host=$("#err-steps"); host.innerHTML="";
  for(let i=0;i<j.steps.length;i++){
    const row=document.createElement("div"); row.className="tracerow";
    row.innerHTML=`<div class="n">${i+1}</div><div><div class="lab">${esc(j.steps[i].label)}</div><div class="det">${esc(j.steps[i].detail||'')}</div></div>`;
    host.appendChild(row); await sleep(300); row.classList.add("on");
  }
  if(j.display_pretty){ $("#err-req").textContent=j.display_pretty; $("#err-req").style.display="block"; }
  else { $("#err-req").style.display="none"; }
  $("#err-reqwrap").style.display="block";
  $("#err-send").disabled=false;
  $("#err-send").textContent = retry ? "▶ Watch retry with backoff" : "▶ Send this request";
  $("#err-send").onclick=()=>executeErr(code,meta);
}

function setCols(n){
  const wrap=$("#err-cols");
  wrap.className="err-cols "+(n===2?"two":"one");
  if(n===2){
    wrap.innerHTML=`<div class="err-col" id="err-col-anthropic"></div><div class="err-col" id="err-col-openai"></div>`;
  }else{
    wrap.innerHTML=`<div class="err-col" id="err-result"></div>`;
  }
}

function colHTML(provider, res, targetCode){
  const got=res.status, match=res.matched, na=(String(got)==="n/a"||got==null);
  const badgeCls = na?"na":(match?"ok":"bad");
  const hdrs=res.headers||{};
  const hkeys=Object.keys(hdrs);
  const hdrHTML = hkeys.length
    ? `<div class="err-hdrs">${hkeys.map(k=>`<div class="hrow"><span>${esc(k)}</span><b>${esc(hdrs[k])}</b></div>`).join("")}</div>`
    : "";
  const remCls = res.class==="retry" ? "err-remedy retry" : "err-remedy";
  const remHTML = res.remedy ? `<div class="${remCls}"><b>Do:</b> ${esc(res.remedy)}</div>` : "";
  const rawHTML = res.raw ? `<pre class="mono small err-raw">${esc((res.raw||'').slice(0,400))}</pre>` : "";
  const matchLine = na
    ? `<div class="ecol-match">server-side — can't be fired from the client</div>`
    : `<div class="ecol-match">${match?'✓ matched the target code':'provider surfaced a different code'}</div>`;
  return `<div class="ecol-prov">${esc(provider)}</div>
    <div class="ecol-badge ${badgeCls}">${na?'n/a':got}</div>
    ${matchLine}
    ${hdrHTML}${remHTML}${rawHTML}`;
}

async function executeErr(code,meta){
  const retry = meta.class==="retry";
  $("#err-send").disabled=true;

  if(retry){
    // can't fire a real 5xx — teach the fix: exponential backoff
    setCols(1);
    await runBackoff(code, meta);
    logHist({code,label:meta.label,provider:errProv,got:"n/a",match:null,cls:"retry"});
    $("#err-send").disabled=false;
    return;
  }

  if(errMode==="both"){
    setCols(2);
    $("#err-col-anthropic").innerHTML='<span class="spin"></span> firing…';
    $("#err-col-openai").innerHTML='<span class="spin"></span> firing…';
    try{
      const q=new URLSearchParams({code, providers:"anthropic,openai"});
      const j=await (await fetch(API+"/api/error_execute_both?"+q)).json();
      const statuses=[];
      ["anthropic","openai"].forEach(p=>{
        const r=j.results[p]||{status:"n/a",note:"no result"};
        $("#err-col-"+p).innerHTML=colHTML(p, r, code);
        logHist({code,label:meta.label,provider:p,got:r.status,match:r.matched,cls:"fix"});
        statuses.push(r.status);
      });
      await repin(meta, statuses);
    }catch(e){ $("#err-cols").innerHTML='<div class="err-col bad">✕ '+esc(e.message)+'</div>'; }
  }else{
    setCols(1);
    const res=$("#err-result"); res.innerHTML='<span class="spin"></span> firing the real request…';
    try{
      const q=new URLSearchParams({provider:errProv,code});
      const j=await (await fetch(API+"/api/error_execute?"+q)).json();
      res.innerHTML=colHTML(errProv, j, code);
      logHist({code,label:meta.label,provider:errProv,got:j.status,match:j.matched,cls:"fix"});
      await repin(meta, [j.status]);
    }catch(e){ res.innerHTML='<div class="bad">✕ '+esc(e.message)+'</div>'; }
  }
  $("#err-send").disabled=false;
}

async function runBackoff(code, meta){
  const plan=(curPrep&&curPrep.backoff)||[{attempt:1,wait_s:0},{attempt:2,wait_s:1},{attempt:3,wait_s:2},{attempt:4,wait_s:4}];
  const host=$("#err-result");
  host.innerHTML=`<div class="ecol-prov">${esc(errProv)}</div>
    <div class="ecol-badge na">${code}</div>
    <div class="ecol-match">a valid request — the server, not you, returned ${code}</div>
    <div class="backoff" id="err-backoff"></div>
    <div class="err-remedy retry"><b>Do:</b> ${esc(meta.remedy||'retry with exponential backoff')}</div>`;
  const bo=$("#err-backoff");
  for(let i=0;i<plan.length;i++){
    const last=i===plan.length-1;
    const row=document.createElement("div");
    row.className="bo-row"+(last?" win":"");
    const label = last
      ? `attempt ${plan[i].attempt} → 200 OK ✓`
      : `attempt ${plan[i].attempt} → ${code} ✕` + (plan[i+1]?`  → wait ${plan[i+1].wait_s}s`:``);
    row.innerHTML=`<div class="bo-n">${plan[i].attempt}</div><div class="bo-txt">${label}</div>`;
    bo.appendChild(row);
    await sleep(120); row.classList.add("on");
    await sleep(last?200:650);
  }
}

function logHist(h){
  h.when=new Date().toLocaleTimeString();
  errHist.unshift(h); renderErrHist();
}
function renderErrHist(){
  if(!errHist.length) return;
  $("#err-hist").innerHTML="<thead><tr><th>time</th><th>provider</th><th>target</th><th>returned</th><th>match</th></tr></thead><tbody>"+
    errHist.map(h=>`<tr><td class="mono">${h.when}</td><td>${esc(h.provider)}</td>
      <td class="mono">${h.code} ${esc(h.label||'')}</td>
      <td class="mono ${h.match===false?'bad':(h.match?'ok':'')}">${h.got}</td>
      <td>${h.match==null?'—':(h.match?'✓':'≠')}</td></tr>`).join("")+"</tbody>";
}
