"""API request models kept separate from route/controller code."""
from pydantic import BaseModel

class DatasetImport(BaseModel):
    source: str = "alpaca"   # legacy, unused
    url: str = ""
    rows: int = 25

class Infer(BaseModel):
    prompt: str
    model: str
    mode: str = "sentence"
