"""Live Hugging Face text importer — default dataset plus any custom HF dataset.

Mirrors the image demo's robustness: retrying HF calls with plain-language
failures, and a small discovery step so an arbitrary text dataset can be turned
into a training corpus.
"""
import re
import time
import requests
from fastapi import HTTPException
from app.config import HF_ROWS_URL, HF_SPLITS_URL
from app.services import corpus

DEFAULT_DATASET = "tatsu-lab/alpaca"

# The non-live sources are classroom HOMEWORK — real-world ingestion paths.
CATALOG = [
    {"id": "commoncrawl", "name": "Common Crawl", "kind": "Web-scale raw corpus",
     "path": "WARC/WET files -> filter/clean/dedupe -> text shards -> /corpus"},
    {"id": "google", "name": "Google Dataset Search", "kind": "Dataset discovery",
     "path": "find dataset -> visit publisher -> download -> normalize -> /corpus"},
    {"id": "kaggle", "name": "Kaggle", "kind": "Dataset Hub",
     "path": "dataset/API download -> CSV/JSON/text -> normalize -> /corpus"},
    {"id": "datagov", "name": "data.gov", "kind": "Government catalog",
     "path": "catalog -> agency CSV/JSON/API -> select text -> /corpus"},
]


def _one_line(value: str) -> str:
    return re.sub(r"\s+", " ", (value or "").strip())


def _dataset_id(url: str) -> str:
    """Normalize blank/url/owner-name input into an owner/name dataset id."""
    s = (url or "").strip()
    if not s:
        return DEFAULT_DATASET
    m = re.search(r"huggingface\.co/datasets/([^/\s?#]+/[^/\s?#]+)", s)
    if m:
        return m.group(1)
    s = s.rstrip("/")
    if re.fullmatch(r"[^/\s]+/[^/\s]+", s):
        return s
    raise HTTPException(400, f"'{url}' doesn't look like a Hugging Face dataset. "
                             f"Use owner/name (e.g. tatsu-lab/alpaca) or a full "
                             f"https://huggingface.co/datasets/... link.")


def _hf_get(url, params, timeout, what, tries=2):
    """GET the HF datasets-server with retries and plain-language failures."""
    last = ""
    for i in range(tries):
        try:
            r = requests.get(url, params=params, timeout=timeout)
            if r.status_code == 404:
                raise HTTPException(404, f"Hugging Face has no {what} for this dataset (404) — double-check the owner/name.")
            r.raise_for_status()
            return r.json()
        except requests.Timeout:
            last = (f"Hugging Face's dataset viewer didn't answer within {timeout}s while fetching {what}. "
                    f"Its server is often slow to warm up on the first request (or briefly rate-limited).")
        except requests.ConnectionError:
            last = (f"Couldn't reach Hugging Face while fetching {what} — check your internet connection, "
                    f"DNS, or a proxy/firewall between you and huggingface.co.")
        except requests.HTTPError as e:
            code = getattr(e.response, "status_code", "?")
            raise HTTPException(502, f"Hugging Face returned HTTP {code} while fetching {what}.")
        if i < tries - 1:
            time.sleep(1.5 * (i + 1))
    raise HTTPException(504, last + f" Tried {tries}x. Wait a few seconds and pull again, "
                                   f"or try a smaller count or a different dataset.")


def _discover(dataset: str):
    """Pick a train-ish (config, split) for an arbitrary dataset."""
    data = _hf_get(HF_SPLITS_URL, {"dataset": dataset}, 25, "the split list")
    splits = data.get("splits", [])
    if not splits:
        raise HTTPException(502, f"Hugging Face returned no splits for '{dataset}'.")
    pick = next((s for s in splits if s.get("split") == "train"), splits[0])
    return pick.get("config", "default"), pick.get("split", "train")


def _row_to_text(row: dict):
    """Turn one dataset row into (training_line, preview_example) or None."""
    if "instruction" in row and "output" in row:                 # alpaca-style
        instr, inp, out = _one_line(row.get("instruction", "")), _one_line(row.get("input", "")), _one_line(row.get("output", ""))
        if instr and out:
            prefix = f"Instruction: {instr}" + (f" Input: {inp}" if inp else "") + " Response:"
            return f"{prefix} {out}", {"prompt": prefix, "answer": out}
        return None
    for pk, ck in (("prompt", "completion"), ("question", "answer"), ("query", "response")):
        if pk in row and ck in row:                              # prompt/completion style
            p, c = _one_line(row.get(pk, "")), _one_line(row.get(ck, ""))
            if p and c:
                return f"{p} {c}", {"prompt": p, "answer": c}
    for key in ("text", "content", "sentence", "document", "body", "review"):
        if isinstance(row.get(key), str):                        # single text column
            t = _one_line(row[key])
            if t:
                return t, {"prompt": t[:80], "answer": t}
    strs = [_one_line(v) for v in row.values() if isinstance(v, str) and v.strip()]
    if strs:                                                     # fallback: join strings
        joined = " ".join(strs)
        return joined, {"prompt": strs[0][:80], "answer": joined}
    return None


def import_dataset(url: str, requested_rows: int) -> dict:
    """Replace the active corpus with a small slice of a HF text dataset."""
    dataset = _dataset_id(url)
    count = max(5, min(int(requested_rows), 100))
    config, split = ("default", "train") if dataset == DEFAULT_DATASET else _discover(dataset)
    payload = _hf_get(HF_ROWS_URL, {"dataset": dataset, "config": config, "split": split,
                      "offset": 0, "length": count}, 40, "dataset rows")
    rows = [item.get("row", {}) for item in payload.get("rows", [])][:count]
    if not rows:
        raise HTTPException(502, f"Hugging Face returned no rows for '{dataset}'.")
    lines, examples = [], []
    for row in rows:
        res = _row_to_text(row)
        if not res:
            continue
        line, ex = res
        lines.append(line)
        if len(examples) < 6:
            examples.append(ex)
    if not lines:
        raise HTTPException(400, f"'{dataset}' loaded, but no text columns were found to train on. "
                                 f"Text datasets work best — a text column, or instruction+output.")
    text = "\n".join(lines) + "\n"
    slug = re.sub(r"[^a-z0-9]+", "_", dataset.lower()).strip("_") or "dataset"
    corpus.clear_text_files(); corpus.remove_dataset_meta()
    corpus.write_text(f"hf_{slug}.txt", text)
    corpus.write_dataset_meta({"source": dataset, "rows": len(lines), "examples": examples})
    return {"source": dataset, "rows": len(lines), "characters": len(text),
            "corpus_file": f"hf_{slug}.txt", "examples": examples}
