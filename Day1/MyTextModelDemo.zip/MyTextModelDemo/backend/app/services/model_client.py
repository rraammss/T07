"""All calls from the backend orchestrator to the TF07 model service."""
import requests
from fastapi import HTTPException
from app.config import MODEL_URL

def invalidate_model() -> None:
    """Best-effort invalidation after corpus changes."""
    try:
        requests.post(f"{MODEL_URL}/invalidate", timeout=10)
    except requests.RequestException:
        # Corpus updates should still succeed if the model container is restarting.
        pass

def train_model() -> dict:
    response = requests.post(f"{MODEL_URL}/train", timeout=120)
    if response.status_code != 200:
        raise HTTPException(response.status_code, response.json().get("detail", "training failed"))
    return response.json()

def generate(prompt: str, mode: str) -> dict:
    response = requests.post(f"{MODEL_URL}/generate", json={"prompt": prompt, "mode": mode}, timeout=120)
    if response.status_code != 200:
        raise HTTPException(response.status_code, response.json().get("detail", "model error"))
    return response.json()

def anatomy() -> dict:
    response = requests.get(f"{MODEL_URL}/anatomy", timeout=30)
    if response.status_code != 200:
        raise HTTPException(response.status_code, response.json().get("detail", "anatomy error"))
    return response.json()

def status() -> dict:
    try:
        return requests.get(f"{MODEL_URL}/status", timeout=5).json()
    except requests.RequestException:
        return {"trained": False, "profiles": 0}
