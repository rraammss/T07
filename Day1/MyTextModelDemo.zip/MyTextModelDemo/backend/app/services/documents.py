"""Document extraction and resume/profile fact extraction helpers."""
import io
import re
from docx import Document
from fastapi import HTTPException
from pypdf import PdfReader

def extract_text(filename: str, data: bytes) -> str:
    """Convert supported PDF, DOCX, or TXT uploads into plain text."""
    name = filename.lower()
    if name.endswith(".pdf"):
        return "\n".join(page.extract_text() or "" for page in PdfReader(io.BytesIO(data)).pages)
    if name.endswith(".docx"):
        return "\n".join(paragraph.text for paragraph in Document(io.BytesIO(data)).paragraphs)
    if name.endswith(".txt"):
        return data.decode("utf-8", errors="replace")
    raise HTTPException(400, f"Unsupported file type: {filename} (pdf, docx or txt)")

def slug(name: str) -> str:
    """Create a safe corpus filename from a person's display name."""
    return re.sub(r"[^a-z0-9]+", "_", name.lower()).strip("_") or "profile"

def auto_facts(name: str, text: str) -> list[str]:
    """Extract a few demo-friendly facts from resume text on a best-effort basis."""
    facts: list[str] = []
    flat = " ".join(text.split())
    email = re.search(r"[\w.+-]+@[\w-]+\.[\w.-]+", flat)
    if email: facts.append(f"{name} email is {email.group()}")
    phone = re.search(r"(\+?\d[\d\s().\-]{7,}\d|\(\d{3}\)[\d\s.\-]{6,}\d)", flat)
    if phone: facts.append(f"{name} phone is {phone.group().strip()}")
    linked = re.search(r"(https?://)?(www\.)?linkedin\.com/in/[\w-]+", flat, re.I)
    if linked: facts.append(f"{name} LinkedIn is {linked.group()}")
    for keyword in ("Master", "Bachelor", "Diploma", "PhD", "B.S.", "M.S.", "B.Tech", "M.Tech"):
        match = re.search(keyword + r"[a-z]* of [A-Z][^,.•\n]{0,55}", flat)
        if match:
            facts.append(f"{name} education includes {match.group().strip()}.")
            break
    title = re.search(r"\b((?:Senior |Staff |Principal |Lead |Chief )?(?:Technologist|Architect|Engineer|Developer|Consultant|Manager|Director|Analyst|Designer|Scientist))\b", flat)
    if title:
        value = title.group(1).strip()
        facts.append(f"{name} is {'an' if value[0] in 'AEIOU' else 'a'} {value}.")
    else:
        facts.append(f"{name} is the person described in this profile.")
    exp_src = re.sub(r"\b(CAREER EXPERIENCE|WORK EXPERIENCE|EXPERIENCE|PROFESSIONAL EXPERIENCE|EMPLOYMENT)\b", "|", flat)
    employer = re.search(r"([A-Z][A-Za-z0-9&.\-]+(?:\s+[A-Z][A-Za-z0-9&.\-]+){0,3})\s+(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+\d{4}", exp_src)
    if employer: facts.append(f"{name} experience includes work at {employer.group(1).strip()}.")
    return facts
