"""Shared corpus file operations used by both profile and dataset modes."""
import json
import os
from app.config import CORPUS_DIR, DATASET_META

def clear_text_files() -> None:
    for filename in os.listdir(CORPUS_DIR):
        if filename.endswith(".txt"):
            os.remove(os.path.join(CORPUS_DIR, filename))

def remove_dataset_meta() -> None:
    if os.path.exists(DATASET_META):
        os.remove(DATASET_META)

def list_profiles() -> list[str]:
    return sorted(filename[:-4] for filename in os.listdir(CORPUS_DIR) if filename.endswith(".txt"))

def write_text(filename: str, text: str) -> None:
    with open(os.path.join(CORPUS_DIR, filename), "w", encoding="utf-8") as handle:
        handle.write(text)

def write_dataset_meta(payload: dict) -> None:
    with open(DATASET_META, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)

def read_dataset_meta() -> dict:
    try:
        with open(DATASET_META, encoding="utf-8") as handle:
            return json.load(handle)
    except (OSError, json.JSONDecodeError):
        return {"source": None, "rows": 0, "examples": []}

def read_all_text() -> dict:
    """The full active corpus as one blob — what the model will train on."""
    files = sorted(f for f in os.listdir(CORPUS_DIR) if f.endswith(".txt"))
    chunks = []
    for f in files:
        with open(os.path.join(CORPUS_DIR, f), encoding="utf-8") as handle:
            chunks.append(f"===== {f} =====\n" + handle.read().strip())
    blob = "\n\n".join(chunks)
    return {"files": files, "text": blob, "chars": len(blob)}
