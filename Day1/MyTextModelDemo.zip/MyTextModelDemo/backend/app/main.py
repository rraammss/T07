"""TF07 backend/orchestrator API.

Routes stay intentionally thin: parsing and corpus logic live in services,
while model execution remains isolated in the model container.
"""
import requests
from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from app.config import OPENAI_KEY, OPENAI_MODEL
from app.schemas import DatasetImport, Infer
from app.services import corpus, datasets, documents, model_client

app = FastAPI(title="TF07 backend")

@app.post("/api/profiles")
async def add_profile(name: str = Form(...), linkedin: str = Form(""), facts: str = Form(""), file: UploadFile | None = File(None)):
    if not file and not linkedin.strip() and not facts.strip():
        raise HTTPException(400, "Give a document, quick facts, or a LinkedIn URL.")
    parts = [f"{name} profile."]
    doc_text = documents.extract_text(file.filename, await file.read()).strip() if file else ""
    if doc_text: parts.extend(documents.auto_facts(name, doc_text))
    if facts.strip():
        parts.append(facts.strip())
        if facts.strip().lower() != facts.strip(): parts.append(facts.strip().lower())
    if doc_text: parts.append(doc_text)
    if linkedin.strip(): parts.append(f"{name} LinkedIn profile: {linkedin.strip()}")
    text = "\n".join(parts) + "\n"
    filename = f"{documents.slug(name)}.txt"
    corpus.write_text(filename, text); model_client.invalidate_model()
    return {"saved": documents.slug(name), "characters": len(text)}

@app.get("/api/profiles")
def list_profiles(): return {"profiles": corpus.list_profiles()}

@app.delete("/api/profiles")
def clear_profiles():
    corpus.clear_text_files(); corpus.remove_dataset_meta(); model_client.invalidate_model()
    return {"cleared": True}

@app.get("/api/datasets/catalog")
def dataset_catalog(): return {"sources": datasets.CATALOG}

@app.post("/api/datasets/import")
def import_dataset(request: DatasetImport):
    result = datasets.import_dataset(request.url, request.rows); model_client.invalidate_model(); return result

@app.get("/api/datasets/examples")
def dataset_examples(): return corpus.read_dataset_meta()

@app.get("/api/corpus")
def corpus_text(): return corpus.read_all_text()

@app.post("/api/train")
def train(): return model_client.train_model()

@app.post("/api/infer")
def infer(request: Infer):
    if request.model == "tf07":
        body = model_client.generate(request.prompt, request.mode)
        return {"model":"TF07","answer":body["answer"],"prompt_ids":body["prompt_ids"]}
    if request.model == "openai":
        if not OPENAI_KEY: raise HTTPException(400, "OPENAI_API_KEY is not set in .env")
        response = requests.post("https://api.openai.com/v1/chat/completions", headers={"Authorization":f"Bearer {OPENAI_KEY}"}, json={"model":OPENAI_MODEL,"messages":[{"role":"system","content":(("Answer thoroughly and in detail." if request.mode == "full" else "Answer in one or two short sentences.") + " If you do not know, say you do not know.")},{"role":"user","content":request.prompt}]}, timeout=60)
        if response.status_code != 200: raise HTTPException(response.status_code, f"OpenAI: {response.text[:200]}")
        return {"model":OPENAI_MODEL,"answer":response.json()["choices"][0]["message"]["content"].strip()}
    raise HTTPException(400, "model must be 'tf07' or 'openai'")

@app.get("/api/anatomy")
def anatomy(): return model_client.anatomy()

@app.get("/api/status")
def status(): return {**model_client.status(), "openai_key": bool(OPENAI_KEY)}
