/**
 * TF07 classroom UI controller.
 *
 * Responsibilities: call backend APIs, update the three teaching tabs, and run
 * the small visual animations. No model/training logic lives in the browser.
 */
const $ = id => document.getElementById(id);
const QFIELDS = [["is","Who"],["email is","Email"],["phone is","Phone"],
                 ["LinkedIn is","LinkedIn"],["education includes","Education"],
                 ["experience","Experience"]];
function renderQButtons(names){
  const box = $("qbtns");
  if(!names.length){ box.innerHTML = '<span style="font-size:12px;color:#8a97a6">Train a profile first</span>'; return; }
  box.innerHTML = names.flatMap(n =>
    QFIELDS.map(([suffix,label]) =>
      `<button class="btn" style="background:#eef4ee;color:#0F6E56;border:1px solid #1D9E75;padding:6px 12px;font-size:12px"
        onclick="tapQ('${n} ${suffix}')">${cap(n)} · ${label}</button>`)
  ).join("");
}
function cap(s){ return s.charAt(0).toUpperCase()+s.slice(1); }
function tapQ(prompt){ $("q").value = prompt; ask(); }

const api = (p, opt) => fetch("/api" + p, opt).then(async r => {
  const b = await r.json().catch(() => ({}));
  if (!r.ok) {
    let msg = b.detail;
    if (Array.isArray(msg))            // FastAPI validation errors come as an array
      msg = msg.map(e => e.msg || JSON.stringify(e)).join("; ");
    throw new Error(msg || r.statusText);
  }
  return b;
});

function show(tab){
  $("train").classList.toggle("hide", tab !== "train");
  $("infer").classList.toggle("hide", tab !== "infer");
  $("anat").classList.toggle("hide", tab !== "anat");
  $("tabTrain").classList.toggle("on", tab === "train");
  $("tabInfer").classList.toggle("on", tab === "infer");
  $("tabAnat").classList.toggle("on", tab === "anat");
  if (tab === "anat") loadAnatomy();
}


let datasetExamples = [];
function renderDatasetQuestions(){
  const wrap=$("datasetQWrap"), box=$("datasetQbtns");
  if(!datasetExamples.length){ wrap.style.display="none"; return; }
  wrap.style.display="block";
  box.innerHTML=datasetExamples.slice(0,6).map((e,i)=>
    `<button class="btn" style="background:#fff8eb;color:#854F0B;border:1px solid #EF9F27;padding:6px 10px;font-size:11px" onclick="tapDatasetQ(${i})">Example ${i+1}</button>`).join("");
}
function tapDatasetQ(i){ $("q").value=datasetExamples[i].prompt; $("mSel").value="tf07"; $("mMode").value="short"; ask(); }

async function loadCorpus(){
  try{
    const c = await api("/corpus");
    $("corpusView").value = c.text || "";
    $("corpusMeta").textContent = c.files && c.files.length
      ? `${c.files.length} file(s) · ${c.chars.toLocaleString()} characters · ${c.files.join(", ")}`
      : "corpus is empty";
  }catch(e){}
}

async function importDataset(){
  const btn=$("btnAlpaca"), n=Number($("alpacaRows").value), url=$("dsUrl").value.trim();
  const label=btn.textContent; btn.disabled=true; btn.textContent="Pulling…";
  const t0=Date.now();
  const tick=()=>{ const s=((Date.now()-t0)/1000).toFixed(1);
    $("trainOut").innerHTML=`<span class="warn">Contacting Hugging Face… ${s}s</span>\nDownloading rows and building the corpus. The HF dataset viewer can be slow to warm up on the first request.`; };
  tick(); const timer=setInterval(tick,100);
  try{
    const r=await api("/datasets/import",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({url, rows:n})});
    clearInterval(timer);
    const took=((Date.now()-t0)/1000).toFixed(1);
    datasetExamples=r.examples||[];
    $("trainOut").innerHTML=`<span class="ok">Pulled ${r.rows} rows from ${r.source}</span> (${r.characters.toLocaleString()} characters) in ${took}s.\nClick Train the model.`;
    await loadCorpus(); renderDatasetQuestions(); await refresh();
  }catch(e){ clearInterval(timer); $("trainOut").innerHTML=`<span class="warn">${e.message}</span>`; }
  finally{ clearInterval(timer); btn.disabled=false; btn.textContent=label; }
}

async function refresh(){
  try{
    const s = await api("/status");
    $("pill").textContent =
      `corpus ${s.profiles} · model ${s.trained ? "TRAINED" : "not trained"} · openai key ${s.openai_key ? "✓" : "✗"}`;
    $("tabInfer").disabled = !s.trained;
    $("tabAnat").disabled = !s.trained;
    $("trainedNote").style.display = s.trained ? "block" : "none";
    const p = await api("/profiles");
    $("chips").innerHTML = p.profiles.map(n => `<span class="chip">${n}</span>`).join("");
    renderQButtons(p.profiles.filter(n => !n.startsWith("hf_")));
    const d = await api("/datasets/examples");
    datasetExamples = d.examples || [];
    renderDatasetQuestions();
    if(d.rows && $("corpusStatus")) $("corpusStatus").innerHTML = `<span class="ok">READY</span> ${d.rows} rows from ${d.source || "dataset"} in the active corpus${s.trained ? " · model trained" : " · <span class=\"warn\">TRAIN required</span>"}`;
    loadCorpus();
  }catch(e){ $("pill").textContent = "backend unreachable"; }
}

async function addProfile(){
  const fd = new FormData();
  fd.append("name", $("pName").value.trim());
  fd.append("linkedin", $("pUrl").value.trim());
  fd.append("facts", $("pFacts").value.trim());
  if ($("pFile").files[0]) fd.append("file", $("pFile").files[0]);
  if (!fd.get("name")) return alert("Name is required");
  try{
    const r = await api("/profiles", {method:"POST", body:fd});
    $("pName").value = $("pUrl").value = $("pFacts").value = ""; $("pFile").value = "";
    await refresh(); await loadCorpus();
  }catch(e){ alert(e.message); }
}

async function clearProfiles(){
  await api("/profiles", {method:"DELETE"}); await refresh(); await loadCorpus();
}

async function train(){
  $("btnTrain").disabled = true;
  $("trainOut").innerHTML = "counting pairs · gluing pieces · filling tensors…";
  try{
    const r = await api("/train", {method:"POST"});
    $("trainOut").innerHTML =
      `<span class="ok">TRAINED</span>\n` +
      `corpus files: ${r.profiles}\n` +
      `tokens     : ${r.tokens}\n` +
      `vocab      : ${r.vocab} pieces  -> tokenizer.json\n` +
      `parameters : ${r.parameters.toLocaleString()} learned numbers -> model.safetensors`;
  }catch(e){
    $("trainOut").innerHTML = `<span class="warn">FAILED</span>\n${e.message}`;
  }
  $("btnTrain").disabled = false;
  refresh();
}

async function ask(){
  $("btnAsk").disabled = true;
  $("askOut").textContent = "thinking…"; $("askMeta").textContent = "";
  try{
    const r = await api("/infer", {method:"POST",
      headers:{"Content-Type":"application/json"},
      body: JSON.stringify({prompt: $("q").value, model: $("mSel").value, mode: $("mMode").value})});
    $("askOut").textContent = r.answer;
    $("askMeta").textContent = r.prompt_ids
      ? `answered by ${r.model} · prompt token IDs [${r.prompt_ids.join(", ")}]`
      : `answered by ${r.model}`;
  }catch(e){ $("askOut").innerHTML = `<span class="warn">${e.message}</span>`; }
  $("btnAsk").disabled = false;
}

async function loadAnatomy(){
  const box = $("anatBody");
  box.innerHTML = '<div class="out mono">reading tokenizer.json and model.safetensors…</div>';
  let a;
  try { a = await api("/anatomy"); }
  catch(e){ box.innerHTML = `<div class="out mono"><span style="color:#EF9F27">${e.message}</span></div>`; return; }

  const esc = s => String(s).replace(/</g,"&lt;");
  const fmt = n => n.toLocaleString();
  const ul = arr => `<details class="explain"><summary>What is this? — tap to explain</summary>
    <ul class="tlist">${arr.map(b=>`<li>${esc(b)}</li>`).join("")}</ul></details>`;

  // ---- STEP 1: tokenizer.json
  const toks = a.tokenizer.example_tokens.map(t =>
    `<span class="tok ${t.whole?'whole':''}">${esc(t.piece)}<span class="id">id ${t.id}</span></span>`).join("");
  const pieces = a.tokenizer.meaningful_pieces.map(p =>
    `<span class="tok whole">${esc(p.piece)}<span class="id">id ${p.id}</span></span>`).join("");
  const mrow = m => `
    <div class="mrow">
      <span class="mp">${esc(m.a)}</span><span class="mplus">+</span><span class="mp">${esc(m.b)}</span>
      <span class="marrow">→</span><span class="mp mres">${esc(m.result)}</span></div>`;
  const early = (a.tokenizer.merges_early||[]).map(mrow).join("");
  const late = (a.tokenizer.merges_late||[]).map(mrow).join("");
  const step1 = `
    ${ul(a.tokenizer.bullets)}
    <div class="fact"><span class="k">type</span> ${a.tokenizer.type} (${a.tokenizer.type_full})
      &nbsp;·&nbsp; <span class="k">vocabulary</span> ${fmt(a.tokenizer.vocab_size)} pieces
      &nbsp;·&nbsp; <span class="k">merge rules</span> ${fmt(a.tokenizer.merge_rules)}</div>

    <ul class="deckbullets">
      <li>The tokenizer builds its vocabulary by <b>gluing pieces together</b>, starting from single letters.</li>
      <li><b>First rules</b> can only glue <b>two letters</b> — like <span class="mono">i</span>+<span class="mono">n</span> → <span class="mono">in</span>. These are the building blocks.</li>
      <li><b>Later rules</b> glue those chunks into <b>whole words</b> — like <span class="mono">␣eng</span>+<span class="mono">ineer</span> → <span class="mono">␣engineer</span>.</li>
      <li>So small pieces <b>stack up</b> into big ones. That's the whole trick.</li>
    </ul>
    <div class="mini">First rules — glue 2 letters:</div>
    <div class="merges">${early}</div>
    <div class="mini" style="margin-top:10px">Last rules — glue whole chunks into words (${a.tokenizer.merges_total} rules in total):</div>
    <div class="merges">${late}</div>

    <ul class="deckbullets" style="margin-top:14px">
      <li>Here's a real sentence cut into pieces: <b>"${esc(a.tokenizer.example_text)}"</b> → ${a.tokenizer.example_tokens.length} pieces.</li>
      <li><span style="color:var(--teal);font-weight:700">Green</span> = a whole word &nbsp;·&nbsp; grey = a fragment.</li>
      <li>The little number on each piece is its <b>slot in the vocabulary</b> (an id) — <b>not</b> how many times it appears.</li>
    </ul>
    <div style="margin:6px 0 12px">${toks}</div>

    <div class="mini">some real words this tokenizer learned as single pieces (from the active training corpus):</div>
    <div style="margin:6px 0 4px">${pieces}</div>`;

  // ---- STEP 2: model.safetensors, with per-part explanations
  const grp = g => {
    const rows = g.tensors.map(t =>
      `<div class="nm">${esc(t.name.split(".").slice(-2).join("."))}</div>
       <div class="sh">[${t.shape.join(" × ")}]</div>
       <div class="pc">${fmt(t.params)}</div>`).join("");
    return `<details class="astep"><summary>
        <span class="chev">▶</span>
        <span class="t">${g.title}</span>
        <span class="s">${g.one_liner}</span></summary>
      <div class="body">
        ${ul(g.bullets)}
        <div class="mini" style="margin-top:8px">what's actually stored here:</div>
        <div class="grid">
          <div class="h">tensor</div><div class="h">shape</div><div class="h">numbers</div>
          ${rows}
        </div>
      </div></details>`;
  };
  const w = a.weights, s = a.samples;
  // render a long vector as a labelled, wrapping grid of dim:value cells
  const vecGrid = (arr) => `<div class="vecgrid">` +
    arr.map((x,i)=>`<span class="cell"><span class="d">${i}</span>${x.toFixed(4)}</span>`).join("") +
    `</div>`;
  const step2 = `
    ${ul(w.intro)}
    <div class="rowcard panelGreen" style="margin-bottom:12px">
      <div class="rowhead">WHERE THIS RUNS DURING GPU INFERENCE</div>
      <div style="display:grid;grid-template-columns:1fr 52px 1fr;gap:10px;align-items:stretch;margin-top:8px">
        <div class="note" style="margin:0"><b>CPU · MODEL SERVER</b><br>Receives HTTP · batches/schedules requests · tokenizes text → integer IDs · sends IDs/tensors to the accelerator · streams generated tokens back.</div>
        <div style="display:flex;align-items:center;justify-content:center;font-size:24px;color:var(--teal)">→</div>
        <div class="note" style="margin:0"><b>GPU · MODEL COMPUTE</b><br>Embedding lookup (ID → vector) · attention Q/K/V/O · MLP · layer norms · output projection/logits. These are the heavy tensor operations.</div>
      </div>
      <div class="mini" style="margin-top:9px">If the model is deliberately running on CPU only, the same math runs on CPU. The split above describes the normal GPU-serving setup.</div>
    </div>
    <div class="fact"><span class="k">tensors</span> ${fmt(w.tensors)}
      &nbsp;·&nbsp; <span class="k">parameters</span> ${fmt(w.parameters)} numbers</div>
    <div class="mini" style="margin-bottom:6px">the parts, in the order text flows through them — tap any to open:</div>
    ${w.groups.map(grp).join("")}

    <details class="deepdive"><summary>🔍 Go deeper — how a token becomes a vector, and how that vector flows through the blocks</summary>
    <div class="ddbody">

    <div class="rowcard panel1">
      <div class="rowhead">FROM TOKEN → EMBEDDING → TRANSFORMER</div>
      <div class="embedflow" aria-label="animated embedding lookup flow">
        <div class="enode">TEXT TOKEN<b>"${esc(s.embed_token)}"</b></div><span class="earrow">→</span>
        <div class="enode">TOKENIZER<b>ID ${s.embed_token_id}</b></div><span class="earrow">→</span>
        <div class="enode lookup">LOOKUP<b>row ${s.embed_token_id}</b></div><span class="earrow">→</span>
        <div class="enode">EMBEDDING<b>${s.embed_dims} numbers</b></div><span class="earrow">→</span>
        <div class="enode">MODEL MATH<b>Block 0</b></div>
      </div>
      <div class="truthbox">The tokenizer performs <b>text → integer IDs</b>. The embedding table performs <b>ID → learned vector</b>. From this point on, the transformer works with vectors, not words.</div>
    </div>

    <div class="rowcard panel2">
      <div class="rowhead">ONE EMBEDDING ROW</div>
      <div class="maprow">
        <span class="mapfrom">"${esc(s.embed_token)}"</span>
        <span class="maparrow">→ vocab id ${s.embed_token_id} →</span>
        <span class="mapid">embed_tokens.weight[${s.embed_token_id}]</span>
      </div>
      <p style="margin:7px 0 7px;font-size:13px;color:#3a4a5a">One vocabulary row contains <b>${s.embed_dims} learned numbers</b> — the model's learned numerical starting representation for this token.</p>
      <div class="vectorpeek">[ ${s.embed_full_row.slice(0,5).map(x=>x.toFixed(4)).join('   ')}   …   ${s.embed_dims} numbers total ]</div>
      <details class="vectorDetails">
        <summary>Show all ${s.embed_dims} numbers</summary>
        ${vecGrid(s.embed_full_row)}
      </details>
      <div class="lessonShort"><b>Key idea:</b> no single dimension has a human-readable meaning. The useful information is in the <b>whole vector together</b> and in how whole vectors relate to one another.</div>
    </div>

    <div class="rowcard panelGreen">
      <div class="rowhead">WHAT THE VECTOR IS GOOD FOR → SIMILARITY</div>
      <p style="margin:5px 0 7px;font-size:13px;color:#3a4a5a">Tokens used in similar contexts can end up with nearby vectors. Tap the token to watch this tiny model compare the whole vector using cosine similarity.</p>
      <div class="simcontrols">
        <button class="simanchor" onclick="runSimilarityScan(this)">${esc(s.embed_token)}</button>
        <span>→</span><span class="simhint">find nearest vectors</span>
        <span class="simstatus"></span>
      </div>
      <div class="simtable" data-simtable>
        ${s.neighbors.map((n,i)=>`
          <div class="sim-w">${esc(n.word)}</div>
          <div class="sim-bar"><span style="--target:${Math.max(2,Math.round(n.cosine*100))}%"></span></div>
          <div class="sim-v">${n.cosine.toFixed(3)}</div>`).join("")}
      </div>
      <div class="conceptspace">
        <span class="cdot anchor" style="left:55%;top:50%">${esc(s.embed_token)}</span>
        ${s.neighbors.slice(0,6).map((n,i)=>{
          const pts=[[31,33],[76,30],[30,70],[78,68],[49,22],[52,79]]; const p=pts[i];
          return `<span class="cdot" style="left:${p[0]}%;top:${p[1]}%">${esc(n.word)}</span>`;
        }).join("")}
      </div>
      <div class="truthbox">The picture is only a teaching projection. Your actual embedding row has ${s.embed_dims} dimensions; a 2-D screen cannot show all of them faithfully.</div>
    </div>

    <div class="rowcard panelGreen">
      <div class="rowhead">THE SAME 128-NUMBER VECTOR IS REFINED THROUGH EVERY BLOCK</div>
      <p style="margin:5px 0 8px;font-size:13px;color:#3a4a5a">The embedding vector enters Transformer Block 0. Every block updates that <b>same-size 128-number representation</b> using surrounding context. The token string does not travel through the blocks — the vector does.</p>
      <div class="vectorJourney" aria-label="128-number vector travelling through transformer blocks">
        <div class="vjstage"><b>Embedding</b>starting representation<div class="dims">128 numbers</div></div>
        ${w.groups.filter(g=>g.title.startsWith('Transformer block')).map((g,i)=>`<span class="vjarrow">→</span><div class="vjstage"><b>Block ${i}</b>${i===0?'context begins':i===w.groups.filter(x=>x.title.startsWith('Transformer block')).length-1?'final contextual representation':'context refines'}<div class="dims">128 numbers</div></div>`).join('')}
        <span class="vjarrow">→</span><div class="vjstage"><b>LM Head</b>score vocabulary<div class="dims">512 scores</div></div>
      </div>
      <div class="lessonShort"><b>Important:</b> the vector stays <b>128 numbers wide</b> through all ${w.groups.filter(g=>g.title.startsWith('Transformer block')).length} transformer blocks. Its values change as context is added. The LM Head then converts the final 128-number representation into one score for each vocabulary token.</div>

      <div class="autorepeat">
        <div class="rowhead" style="margin-bottom:8px">GENERATION = ONE TOKEN, THEN REPEAT</div>
        <div class="loop">
          <span class="loopnode hot">Embedding</span><span class="looparrow">→</span>
          <span class="loopnode hot">Transformer × ${w.groups.filter(g=>g.title.startsWith('Transformer block')).length}</span><span class="looparrow">→</span>
          <span class="loopnode hot">LM Head</span><span class="looparrow">→</span>
          <span class="loopnode hot">Next token</span>
        </div>
        <div class="repeatback">↺ append the new token to the sequence and run the forward pass again</div>
      </div>
    </div>
    </div></details>`;

    box.innerHTML = `
    <details class="astep" open><summary><span class="num">1</span>
      <span class="t">tokenizer.json</span><span class="s">the alphabet</span>
      <span class="chev">▶</span></summary><div class="body">${step1}</div></details>
    <details class="astep" open><summary><span class="num">2</span>
      <span class="t">model.safetensors</span><span class="s">the brain</span>
      <span class="chev">▶</span></summary><div class="body">${step2}</div></details>`;
}


function runSimilarityScan(btn){
  const card=btn.closest('.rowcard');
  const table=card.querySelector('[data-simtable]');
  const status=card.querySelector('.simstatus');
  table.classList.remove('scanned');
  status.textContent='scanning 128-D vectors…';
  void table.offsetWidth;
  setTimeout(()=>{table.classList.add('scanned');status.textContent='ranking nearest vectors…';},300);
  setTimeout(()=>{status.textContent='nearest vectors found ✓';},1450);
  setTimeout(()=>{status.textContent='';},2600);
}

refresh(); setInterval(refresh, 6000);
