# TF07 Studio — train it, then ask it

Three containers:

| container | job |
|---|---|
| `frontend` | two-tab UI: **Train** / **Inference** — http://localhost:8080 |
| `backend`  | extracts PDF/DOCX text, stores the corpus, routes prompts to TF07 or OpenAI |
| `model`    | TF07 itself — trains and serves `tokenizer.json` + `model.safetensors` |

TF07 = BPE tokenizer (vocab 512) + two tensors in `model.safetensors`:
a `[512 x 512]` bigram count grid and `memory.ids`, the tokenized corpus
river. Inference is **longest-suffix match** — an n-gram with unbounded
order. On a classroom-sized corpus TF07 has *perfect memory*, so it
answers questions about US verbatim, while OpenAI (which never saw the
corpus) cannot. That contrast is the whole demo.
Bonus teaching beat: ask TF07 about someone NOT in the corpus ("Elon is")
— it backs off to short context and confidently answers with the wrong
person's line. TF07 hallucinates under backoff, exactly like the big ones.

## Run
```bash
cp .env.example .env        # paste your real OpenAI key
docker compose up --build   # then open http://localhost:8080
```

## Classroom flow
1. **Train tab** — each participant: name + LinkedIn URL + profile document
   (PDF / Word / txt). Click **Add profile** (chip appears), repeat.
2. Click **Train the model** — watch vocab / tokens / parameter counts.
   The Inference tab unlocks.
3. **Inference tab** — prompt `Priya is`, model **TF07** → her exact line.
   Switch to **OpenAI**, same prompt → it has no idea who Priya is.

## Notes
- LinkedIn blocks anonymous scraping, so the URL is stored as a *fact* in
  the corpus (ask TF07 `<name> LinkedIn`) — profile content comes from the
  uploaded document.
- TF07 decoding is greedy (deterministic): same prompt, same answer. Ask
  the room why the v1 demo gave a different answer every run.
- After training, the two files appear right in the project:
  `./artifacts/tokenizer.json` (open it — plain JSON) and
  `./artifacts/model.safetensors`. The corpus is visible too: `./corpus/*.txt`.
  The model reloads them on restart, so a trained TF07 survives
  `docker compose down`.
- Look inside both files (the v1 inspect step, live in class):
  `docker compose exec model python inspect_files.py`


## What's inside model.safetensors (anatomy)

Training writes a **real transformer's weight layout** — the same tensor
names and shapes you see on any HuggingFace model:

    model.embed_tokens.weight              [vocab, hidden]
    model.layers.{0..3}.self_attn.q_proj   [hidden, hidden]   (also k/v/o_proj)
    model.layers.{0..3}.mlp.gate_proj      [ffn, hidden]      (also up/down_proj)
    model.layers.{0..3}.input_layernorm    [hidden]
    model.norm.weight                      [hidden]
    lm_head.weight                         [vocab, hidden]

plus `config.json` — the architecture card (hidden_size, num_hidden_layers,
num_attention_heads...). Walk through it all with:

    docker compose exec model python inspect_files.py

This shows students embedding / attention / MLP / norm / output head exactly
as a Llama or Qwen model is built — just tiny (~1.2M params vs ~1e12).

Note: TF07 *generates* from its bigram brain (`tf07.brain.safetensors`); the
transformer weights in `model.safetensors` are for SHOWING architecture, not
trained to produce text. Training real transformer weights is the LoRA chapter.


## Live dataset classroom demo

The Train tab now starts with a **Training Data Sources** lab.

- **Hugging Face** — live one-click demo. Pull 10–100 rows from `tatsu-lab/alpaca` through the Hugging Face Dataset Viewer API.
- **Common Crawl** — explain as a web-scale ingestion source: WARC/WET -> clean/filter/dedupe -> text shards.
- **Google Dataset Search** — discovery, not a corpus API. Find a publisher dataset, then ingest the publisher's files/API.
- **Kaggle** — dataset hub. Download CSV/JSON/text (often authenticated), select text fields, normalize, then add to `/corpus`.
- **data.gov** — government catalog. Follow the agency resource to CSV/JSON/API, extract useful text, then add to `/corpus`.

### 5-minute teaching flow

1. Open `http://localhost:8080`.
2. Set Alpaca rows to **25** and click **Pull live Alpaca sample**.
3. Point to the animated pipeline: `SOURCE -> ROWS -> FORMAT -> CORPUS -> READY`.
4. Show a preview row: `Instruction ... Response ...`. Explain that the response is the training target.
5. Click **Train the model**. The existing TF07 pipeline builds the BPE tokenizer, token IDs, tensors, and safetensors from the imported text.
6. Open **Inference** and click one of the orange **Example** buttons. TF07 replays what it learned from that imported corpus.
7. Open **Look inside** to connect the public dataset back to `tokenizer.json` and `model.safetensors`.

For class speed, use 10–100 rows. The point is to make the ingestion/training mechanics visible, not to create a useful general-purpose LLM from Alpaca on CPU.

## v4 · Look Inside embedding lesson polish

The Look Inside → model.safetensors lesson now keeps the raw 128-number vector collapsed by default and adds a lightweight visual teaching sequence: token → token ID → embedding lookup → 128-number vector → Transformer block 0. Similarity bars animate on demand, a clearly labeled 2-D concept-space illustration reinforces the idea of nearby vectors, and the page connects embeddings to semantic search, vector databases, RAG, recommendations, clustering, and classification. A final animation shows the representation being refined through TF07's actual three transformer blocks before the LM head scores the next token. The UI explicitly labels the TF07 co-occurrence similarity as a teaching proxy rather than implying it is a measured production embedding model.


## v5 final animation pass
The Look Inside embedding lesson now adds four micro-animations without adding new concepts: the embedding lookup briefly shows a row-loading state; cosine-similarity bars fill in sequence; the same 128-number representation visibly travels through all four TF07 transformer blocks and remains 128 numbers wide while its values are refined; and a final autoregressive loop shows Embedding → Transformer ×4 → LM Head → Next token → repeat.

---

## Refactored code map

The demo is intentionally split by responsibility so a new reader can follow the request from UI to model without opening one large file.

```text
frontend/
  index.html              page structure only
  assets/styles.css       all visual styling
  assets/app.js           browser/API interactions and teaching animations

backend/app/
  main.py                 thin FastAPI routes
  config.py               environment/runtime configuration
  schemas.py              request models
  services/
    documents.py          PDF/DOCX/TXT extraction + resume fact helpers
    corpus.py             shared /corpus file operations
    datasets.py           source catalog + live Alpaca importer
    model_client.py       all backend -> model-service HTTP calls

model/app/
  main.py                 thin model-service routes
  config.py               tiny-model dimensions and limits
  state.py                loaded tokenizer/brain runtime state
  weights.py              transformer-shaped safetensor layout
  training.py             BPE training + artifact creation/loading
  generation.py           TF07 longest-suffix generation behavior
  inspector.py            Look Inside teaching payload and tensor samples
  schemas.py              request models
```

### Safe change rule

When extending the demo, keep UI concerns in `frontend`, orchestration/integration concerns in `backend`, and model/training concerns in `model`. The HTTP endpoints and Docker service names are unchanged from the working classroom version.
