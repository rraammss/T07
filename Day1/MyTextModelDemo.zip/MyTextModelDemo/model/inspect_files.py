"""
INSPECT — open the model files and look inside, the way you'd inspect any
HuggingFace model. Run it inside the model container:

    docker compose exec model python inspect_files.py

Three files come out of training — the same three a real model ships with:
    tokenizer.json      the frozen language universe (pieces + glue rules)
    config.json         the architecture card (how many layers, how wide)
    model.safetensors   the WEIGHTS: embedding, attention, MLP, norms, head
"""

import json
import struct
import numpy as np
from tokenizers import Tokenizer

# ================================================================ FILE 1
print("=" * 68)
print("FILE 1: tokenizer.json  (plain JSON — open it in any editor)")
print("=" * 68)
raw = json.load(open("/artifacts/tokenizer.json", encoding="utf-8"))
vocab, merges = raw["model"]["vocab"], raw["model"]["merges"]
print(f"model type    : {raw['model']['type']}")
print(f"vocab entries : {len(vocab)}    merge rules : {len(merges)}")
tok = Tokenizer.from_file("/artifacts/tokenizer.json")
demo = "attention is all you need"
enc = tok.encode(demo)
print(f"\ntokenize {demo!r}:")
for piece, i in zip(enc.tokens, enc.ids):
    print(f"   {piece!r:>10} -> id {i}")
print("   (the leading marker is how ByteLevel BPE writes a space)")

# ================================================================ FILE 2
print()
print("=" * 68)
print("FILE 2: config.json  (the architecture card — like any HF model)")
print("=" * 68)
cfg = json.load(open("/artifacts/config.json"))
for k, v in cfg.items():
    print(f"   {k:24} : {v}")

# ================================================================ FILE 3
print()
print("=" * 68)
print("FILE 3: model.safetensors  (the WEIGHTS)")
print("=" * 68)
with open("/artifacts/model.safetensors", "rb") as f:
    hlen = struct.unpack("<Q", f.read(8))[0]
    header = json.loads(f.read(hlen))
header.pop("__metadata__", None)
total = sum(int(np.prod(v["shape"])) for v in header.values())
print(f"header length : {hlen} bytes")
print(f"tensors       : {len(header)}")
print(f"parameters    : {total:,}  (every one is a number in this file)\n")

def show(name):
    if name in header:
        sh = header[name]["shape"]
        print(f"   {name:48} {str(sh):14} {header[name]['dtype']}")

print("EMBEDDING - turns each token id into a vector:")
show("model.embed_tokens.weight")
L = cfg["num_hidden_layers"]
print(f"\n{L} TRANSFORMER BLOCKS - each identical in shape. Block 0:")
for n in ["self_attn.q_proj.weight", "self_attn.k_proj.weight",
          "self_attn.v_proj.weight", "self_attn.o_proj.weight",
          "mlp.gate_proj.weight", "mlp.up_proj.weight", "mlp.down_proj.weight",
          "input_layernorm.weight", "post_attention_layernorm.weight"]:
    show(f"model.layers.0.{n}")
print(f"   ... blocks 1..{L-1} have the exact same shapes")
print("\nFINAL NORM + OUTPUT HEAD - turns the last vector back into vocab scores:")
show("model.norm.weight")
show("lm_head.weight")

with open("/artifacts/model.safetensors", "rb") as f:
    f.read(8 + hlen)
    blob = f.read()
def tensor(name):
    meta = header[name]
    a, b = meta["data_offsets"]
    return np.frombuffer(blob[a:b], dtype=np.float32).reshape(meta["shape"])

emb = tensor("model.embed_tokens.weight")
q = tensor("model.layers.0.self_attn.q_proj.weight")
print("\n" + "-" * 68)
print("PEEK AT REAL NUMBERS")
print("-" * 68)
tid = tok.encode(" attention").ids[-1]
print(f"embedding vector for token {tok.decode([tid])!r} (first 8 of {emb.shape[1]} dims):")
print("  ", np.round(emb[tid][:8], 4).tolist())
print(f"\nq_proj of block 0 is a {q.shape[0]}x{q.shape[1]} matrix. Top-left 4x4 corner:")
for row in np.round(q[:4, :4], 4).tolist():
    print("  ", row)

print("\n" + "=" * 68)
print("This is the SAME structure as Llama, Qwen, GPT - just tiny.")
print(f"TF07: {total:,} parameters.  GPT-4-class: ~1,000,000,000,000.")
print("Same file format. Same tensor names. Same math. Different scale.")
print("=" * 68)
