"""Build the JSON payload behind the Look Inside tab.

All classroom explanations and real tensor samples are centralized here so the
HTTP route remains tiny and the teaching copy is easy to find/edit.
"""
import glob
import numpy as np
from fastapi import HTTPException
from app.state import state

def _clean(piece: str) -> str:
    """Turn ByteLevel BPE markers into human-readable characters:
    Ġ (leading space) -> ␣ ,  Ċ (newline) -> ⏎ . Everything else as-is."""
    return piece.replace("Ġ", "␣").replace("Ċ", "⏎")

def _pick_example(corpus_text: str) -> str:
    """A short phrase from the active training corpus for the tokenizer demo."""
    import re as _re
    words = _re.findall(r"[A-Za-z]{4,}", corpus_text)
    if len(words) >= 3:
        for i, w in enumerate(words[:-2]):
            if w[0].isupper():
                return " ".join(words[i:i + 3])
        return " ".join(words[:3])
    return "attention is all you need"

def _pick_sentence(corpus_text: str, tok=None) -> str:
    """A short real phrase (5 words) from the active corpus where MOST words are
    common enough to survive as single tokens — so the example reads cleanly
    with a fragment or two, not all scraps. Skips URL/email/header lines."""
    import re as _re
    best = None
    for line in corpus_text.splitlines():
        low = line.lower()
        if any(bad in low for bad in ("linkedin", "http", "@", "profile:")):
            continue
        words = _re.findall(r"[A-Za-z]{3,}", line)
        for i in range(len(words) - 4):
            window = words[i:i + 5]
            if tok is not None:
                whole = sum(1 for w in window if len(tok.encode(" " + w).ids) == 1)
                if whole >= 3 and any(len(w) >= 8 for w in window):
                    return " ".join(window)
            elif len(window) == 5 and any(len(w) >= 8 for w in window):
                best = best or " ".join(window)
    return best or "data design and delivery"

def _meaningful_pieces(vocab: dict, limit: int = 14) -> list:
    """Pick vocab pieces that are recognizable whole words (a space marker +
    letters), to show students the tokenizer learned real chunks — not junk."""
    items = []
    for piece, i in vocab.items():
        disp = _clean(piece)
        if disp.startswith("␣") and disp[1:].isalpha() and len(disp) >= 5:
            items.append({"piece": disp, "id": int(i)})
    items.sort(key=lambda x: -len(x["piece"]))   # longest = most word-like
    return items[:limit]

def _re_words(text):
    import re as _re
    return set(_re.findall(r"[A-Za-z]{3,}", text))

def _merge_row(m):
    a, b = (m[0], m[1]) if isinstance(m, list) else m.split()
    return {"a": _clean(a), "b": _clean(b), "result": _clean(a + b)}

def _pick_word_token(tok, corpus_text, exclude=None):
    """Find a token that is a COMPLETE, meaningful word (not a fragment), is
    FREQUENT in the upload (so its vector is well-formed and similarity is
    stable — rare words get noisy vectors), and that students recognize.
    `exclude` = set of words to skip (e.g. the person's own name, which sits
    in a unique context and gives meaningless all-zero similarities).
    Returns (token_id, display_word)."""
    import re as _re
    from collections import Counter
    STOP = {"with", "from", "across", "through", "this", "that", "have", "were",
            "which", "their", "them", "into", "over", "under", "than", "then",
            "your", "about", "these", "those", "such", "also", "both", "each",
            "will", "would", "could", "should", "been", "being", "more", "most",
            "other", "some", "they", "here", "there", "when", "what", "where",
            "linkedin", "profile", "email", "phone", "includes"}
    exclude = {e.lower() for e in (exclude or set())}
    counts = Counter(_re.findall(r"[A-Za-z]{4,}", corpus_text))
    ranked = [(w, c) for w, c in counts.most_common(120)
              if w.lower() not in STOP and w.lower() not in exclude and c >= 3]
    # prefer a lowercase common-noun domain term (not a Proper Name) for a
    # clean similarity demo, then fall back to frequency
    def score(item):
        w, c = item
        return (not w[0].isupper(), c, len(w))
    for w, c in sorted(ranked, key=score, reverse=True):
        ids = tok.encode(" " + w).ids
        if len(ids) == 1:
            return ids[0], w
    for w, _ in counts.most_common(120):
        if w.lower() in STOP or w.lower() in exclude:
            continue
        ids = tok.encode(" " + w).ids
        if len(ids) == 1:
            return ids[0], w
    tid = tok.encode(" the").ids[-1]
    return tid, "the"

def build_anatomy_payload():
    """Return the trained model's structure + real sample numbers, shaped for
    a friendly UI walkthrough: tokenizer -> config -> the weight tensors."""
    import json as _json
    import struct as _struct
    if state["tok"] is None:
        raise HTTPException(409, "Model not trained yet.")
    tok = state["tok"]

    # --- tokenizer summary + a live tokenize example from the ACTIVE corpus
    raw = _json.load(open("/artifacts/tokenizer.json", encoding="utf-8"))
    corpus_text = " ".join(open(f, encoding="utf-8").read()
                           for f in glob.glob("/corpus/*.txt"))
    example = _pick_sentence(corpus_text, tok)
    enc = tok.encode(" " + example)
    # tag each piece: is it a complete word (starts with a space marker and is
    # all letters) or a fragment glued onto the previous piece?
    ex_tokens = []
    for p, i in zip(enc.tokens, enc.ids):
        disp = _clean(p)
        whole = disp.startswith("␣") and disp[1:].isalpha() and len(disp) > 2
        ex_tokens.append({"piece": disp, "id": int(i), "whole": bool(whole)})
    tokenizer_view = {
        "type": raw["model"]["type"],
        "type_full": "Byte-Pair Encoding",
        "vocab_size": len(raw["model"]["vocab"]),
        "merge_rules": len(raw["model"]["merges"]),
        "bullets": [
            "Models can't read letters — they only handle numbers. The tokenizer is the translator.",
            "It chops text into known 'pieces' and gives each a fixed id number.",
            "BPE = Byte-Pair Encoding. It starts with single characters, then repeatedly glues the most frequent adjacent pair into one new piece — over and over.",
            "Common whole words ('data', 'design') survive as ONE piece. Rarer words ('LinkedIn') get split into several — you can see both below.",
            "This file is frozen after training — the same text always becomes the same ids.",
        ],
        "example_text": example,
        "example_tokens": ex_tokens,
        "meaningful_pieces": _meaningful_pieces(raw["model"]["vocab"]),
        "merges_early": [_merge_row(m) for m in raw["model"]["merges"][:6]],
        "merges_late": [_merge_row(m) for m in raw["model"]["merges"][-6:]],
        "merges_total": len(raw["model"]["merges"]),
    }

    # --- config card
    cfg = _json.load(open("/artifacts/config.json"))

    # --- read the safetensors header (8-byte len + JSON) and the raw bytes
    with open("/artifacts/model.safetensors", "rb") as f:
        hlen = _struct.unpack("<Q", f.read(8))[0]
        header = _json.loads(f.read(hlen))
        blob = f.read()
    header.pop("__metadata__", None)

    def tensor(name):
        m = header[name]
        a, b = m["data_offsets"]
        return np.frombuffer(blob[a:b], dtype=np.float32).reshape(m["shape"])

    def meta(name):
        return {"name": name, "shape": header[name]["shape"],
                "dtype": header[name]["dtype"],
                "params": int(np.prod(header[name]["shape"]))}

    total = sum(int(np.prod(v["shape"])) for v in header.values())
    L = cfg["num_hidden_layers"]
    D = cfg["hidden_size"]
    V = cfg["vocab_size"]
    F = cfg["intermediate_size"]

    # group tensors into the parts of a transformer, each with a plain-English
    # explanation students can read like a slide
    groups = [
        {"title": "Embedding",
         "one_liner": "the model's learned lookup table — token ID → vector",
         "bullets": [
             f"One row per token in the vocabulary — {V} rows, each containing {D} learned numbers.",
             "The tokenizer has already turned raw text into integer token IDs. The embedding table is the NEXT step: each ID selects one learned vector row.",
             f"That {D}-number vector is the token's learned representation — coordinates in the model's internal feature space.",
             "Tokens used in similar contexts can develop similar vectors after training (for example related words or concepts).",
             "When the model is loaded on a GPU, this embedding lookup executes on the GPU with the rest of the forward pass.",
             "After embedding, the transformer operates on vectors — not raw text and not token strings.",
         ],
         "tensors": [meta("model.embed_tokens.weight")]},
    ]
    for i in range(L):
        p = f"model.layers.{i}."
        first = (i == 0)
        groups.append({
            "title": f"Transformer block {i}",
            "one_liner": "where tokens look at each other and think",
            "bullets": [
                "ATTENTION (q, k, v, o): each token compares itself with other tokens and decides how much attention to pay to each one. This is how context such as what 'it' refers to can be resolved.",
                "q_proj = Query: what am I looking for?  k_proj = Key: what do I match?  v_proj = Value: what information do I contribute?",
                "o_proj = combines the information gathered by attention back into the token's representation.",
                f"MLP (gate, up, down): each token is processed independently — expands from {D} to {F} numbers, applies nonlinear filtering, then shrinks back to {D}. A large share of the model's learned patterns lives in these weights.",
                "The 2 layer norms rescale activations so values stay numerically well-behaved as they pass through many layers.",
                "With a GPU-resident model, these matrix operations run on the GPU; the CPU-side model server schedules and coordinates them.",
            ] if first else [
                "Identical shape to block 0 — the SAME machinery, stacked again.",
                f"Depth is just this block repeated. This model stacks it {L} times; GPT-4-class stacks ~100 times.",
                "Each repeat lets tokens reconsider with everything the previous blocks figured out.",
            ],
            "tensors": [meta(p + n) for n in [
                "self_attn.q_proj.weight", "self_attn.k_proj.weight",
                "self_attn.v_proj.weight", "self_attn.o_proj.weight",
                "mlp.gate_proj.weight", "mlp.up_proj.weight", "mlp.down_proj.weight",
                "input_layernorm.weight", "post_attention_layernorm.weight"]],
        })
    groups.append({
        "title": "Final norm + output head",
        "one_liner": "turning thought back into a word",
        "bullets": [
            f"After the last block, each token is a vector of {D} numbers — its refined meaning.",
            f"lm_head multiplies that vector against all {V} tokens to score 'what comes next?'.",
            "Highest score = the predicted next token. That's one step of generation.",
            "norm.weight is a final stabilizer before scoring.",
        ],
        "tensors": [meta("model.norm.weight"), meta("lm_head.weight")]})

    # --- real sample numbers, for a COMPLETE WORD from the active corpus
    # exclude the people's own names (unique context → meaningless similarity)
    names = set()
    for f in glob.glob("/corpus/*.txt"):
        first = open(f, encoding="utf-8").readline()
        names.update(_re_words(first))
    tid, sample_word = _pick_word_token(tok, corpus_text, exclude=names)
    emb = tensor("model.embed_tokens.weight")
    q = tensor("model.layers.0.self_attn.q_proj.weight")
    full_row = [round(float(x), 4) for x in emb[tid]]        # ALL 128 numbers

    # several whole words -> their embedding rows (first 12 dims each), so the
    # text<->numbers mapping is shown for multiple real words side by side
    word_rows = []
    seen = {sample_word}
    meaningful = _meaningful_pieces(raw["model"]["vocab"], 40)
    for tk in meaningful:
        wtxt = tk["piece"].lstrip("␣")
        if wtxt in seen:
            continue
        seen.add(wtxt)
        word_rows.append({"word": wtxt, "id": tk["id"],
                          "values": [round(float(x), 4) for x in emb[tk["id"]][:12]]})
        if len(word_rows) >= 6:
            break

    # SIMILARITY: the real payoff of embeddings. For the sample word, find the
    # closest OTHER meaningful words by cosine similarity of their full vectors.
    # Only compare against words frequent enough to have a stable vector — rare
    # words produce spurious 1.0 matches on a tiny corpus.
    import re as _re2
    from collections import Counter as _Ctr
    freq = _Ctr(_re2.findall(r"[A-Za-z]{4,}", corpus_text))
    _sim_stop = {"from", "with", "across", "through", "this", "that", "into",
                 "their", "them", "your", "about", "these", "those",
                 "linkedin", "profile", "email", "phone", "includes", "com"}
    cand = [(tk["piece"].lstrip("␣"), tk["id"]) for tk in meaningful
            if tk["id"] != tid
            and tk["piece"].lstrip("␣").lower() not in _sim_stop
            and freq.get(tk["piece"].lstrip("␣"), 0) >= 2]
    v0 = emb[tid]
    n0 = np.linalg.norm(v0) + 1e-9
    sims = []
    for wtxt, wid in cand:
        v = emb[wid]
        cos = float(v0 @ v / (n0 * (np.linalg.norm(v) + 1e-9)))
        sims.append({"word": wtxt, "cosine": round(cos, 3)})
    sims.sort(key=lambda x: -x["cosine"])

    samples = {
        "embed_token": sample_word,
        "embed_token_id": int(tid),
        "embed_dims": int(emb.shape[1]),
        "embed_full_row": full_row,                          # the whole vector
        "word_rows": word_rows,
        "neighbors": sims[:6],                               # closest words
    }

    return {
        "tokenizer": tokenizer_view,
        "config": cfg,
        "weights": {
            "tensors": len(header),
            "parameters": total,
            "intro": [
                "This one file holds every number the model learned — nothing else.",
                "It's laid out as named blocks: an embedding, a stack of transformer blocks, and an output head.",
                "'safetensors' just means: a tiny text header listing each block's name + shape, then the raw numbers packed end to end. Safe to load, no hidden code.",
                f"Total: {total:,} numbers. A real model has the exact same parts — billions of times more of them.",
            ],
            "groups": groups},
        "samples": samples,
        "files": ["tokenizer.json", "config.json", "model.safetensors"],
    }
