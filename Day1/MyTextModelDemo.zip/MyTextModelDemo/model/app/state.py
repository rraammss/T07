"""In-memory runtime state loaded from the frozen training artifacts."""
state = {"tok": None, "bi": None, "river": None}
