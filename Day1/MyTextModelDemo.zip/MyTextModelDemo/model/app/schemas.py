"""Request schemas for model-service routes."""
from pydantic import BaseModel
class Ask(BaseModel):
    prompt: str
    mode: str = "sentence"
