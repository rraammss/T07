"""Small-model dimensions and artifact paths used throughout TF07."""
VOCAB_SIZE = 512
MAX_TOKENS = 140
MAX_TOKENS_FULL = 8000
MAX_CONTEXT = 24
D_MODEL = 128
N_LAYERS = 4
N_HEADS = 4
D_FFN = 512
CORPUS_GLOB = "/corpus/*.txt"
ARTIFACT_DIR = "/artifacts"
