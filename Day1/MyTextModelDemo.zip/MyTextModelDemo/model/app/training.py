"""Tokenizer training, corpus encoding, and artifact persistence."""
import glob
import json
import numpy as np
from fastapi import HTTPException
from tokenizers import Tokenizer, models, trainers, pre_tokenizers, decoders
from safetensors.numpy import save_file, load_file
from app.config import VOCAB_SIZE, N_LAYERS, D_MODEL
from app.state import state
from app.weights import build_anatomy, anatomy_config

def train_from_corpus() -> dict:
    files = sorted(glob.glob("/corpus/*.txt"))
    corpus = [open(f, encoding="utf-8").read() for f in files]
    if not corpus:
        raise HTTPException(400, "No training text in the corpus yet. Import a dataset or add a profile first.")

    # STEP 1 — build + freeze the tokenizer (count pairs, glue, repeat)
    tok = Tokenizer(models.BPE())
    tok.pre_tokenizer = pre_tokenizers.ByteLevel(add_prefix_space=True)
    tok.decoder = decoders.ByteLevel()
    trainer = trainers.BpeTrainer(
        vocab_size=VOCAB_SIZE,
        initial_alphabet=pre_tokenizers.ByteLevel.alphabet(),
    )
    tok.train_from_iterator(corpus, trainer)
    tok.save("/artifacts/tokenizer.json")                       # FREEZE #1

    # STEP 2 — replay the frozen rules LINE BY LINE into one ID river.
    #   Per-line encoding matters: it guarantees "Priya" at a line start
    #   tokenizes exactly like " Priya" in a prompt (same Ġ piece, same ID).
    NL = tok.encode("\n").ids[-1:]   # [-1:] — the actual Ċ id; with
                                      # add_prefix_space, ids[0] is a SPACE
    ids = []
    for text in corpus:
        for line in text.splitlines():
            if line.strip():
                ids.extend(tok.encode(line).ids)
                ids.extend(NL)                  # newline token ends every line
        ids.extend(NL)                          # double newline = END OF PROFILE

    # STEP 3 — "training" = filling tensors with numbers from the data
    V = tok.get_vocab_size()
    bi = np.zeros((V, V), dtype=np.float32)
    for a, b in zip(ids, ids[1:]):
        bi[a, b] += 1.0
    river = np.array(ids, dtype=np.int64)

    # STEP 4 — freeze TWO things:
    #   model.safetensors : a REAL transformer's weights (what students dissect)
    #   config.json       : its architecture card, exactly like HuggingFace
    import json
    anatomy = build_anatomy(bi, V)
    save_file(anatomy, "/artifacts/model.safetensors")          # FREEZE #2
    json.dump(anatomy_config(V), open("/artifacts/config.json", "w"), indent=2)

    #   tf07.brain.safetensors : TF07's actual working brain (bigram + river).
    #   Kept separate so model.safetensors looks like a genuine HF download.
    save_file({"bigram.counts": bi, "memory.ids": river},
              "/artifacts/tf07.brain.safetensors")
    load_artifacts()
    anat_params = sum(a.size for a in anatomy.values())
    return {
        "profiles": len(files),
        "tokens": len(ids),
        "vocab": V,
        "parameters": int(anat_params),
        "layers": N_LAYERS,
        "hidden": D_MODEL,
        "tensors": len(anatomy),
        "files": ["tokenizer.json", "model.safetensors", "config.json"],
    }

def load_artifacts() -> bool:
    try:
        state["tok"] = Tokenizer.from_file("/artifacts/tokenizer.json")
        t = load_file("/artifacts/tf07.brain.safetensors")
        state["bi"], state["river"] = t["bigram.counts"], t["memory.ids"]
        return True
    except Exception:
        return False
