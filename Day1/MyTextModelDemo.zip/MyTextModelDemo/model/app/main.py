"""TF07 model-service HTTP entry point.

The route layer deliberately contains no training math or anatomy-building
logic; those concerns live in focused modules under app/.
"""
import glob
import os
from fastapi import FastAPI
from app.schemas import Ask
from app.state import state
from app.training import train_from_corpus, load_artifacts
from app.generation import generate_text
from app.inspector import build_anatomy_payload

app = FastAPI(title="TF07")

@app.post("/generate")
def generate(request: Ask):
    return generate_text(request.prompt, request.mode)

@app.post("/invalidate")
def invalidate():
    """Unload/delete stale artifacts whenever the active corpus changes."""
    state.update({"tok": None, "bi": None, "river": None})
    removed = []
    for name in ("tokenizer.json", "model.safetensors", "config.json", "tf07.brain.safetensors"):
        path = f"/artifacts/{name}"
        if os.path.exists(path):
            os.remove(path); removed.append(name)
    return {"invalidated": True, "removed": removed}

@app.post("/train")
def train():
    return train_from_corpus()

@app.get("/anatomy")
def anatomy():
    return build_anatomy_payload()

@app.get("/status")
def status():
    return {"trained": state["tok"] is not None, "profiles": len(glob.glob("/corpus/*.txt"))}

# Preserve restart behavior: reload an existing trained brain when artifacts exist.
load_artifacts()
