"""Create the transformer-shaped tensors used by the Look Inside lesson.

These tensors mirror familiar Llama/Qwen-style names and shapes. TF07's actual
generation brain remains the separately stored corpus-memory tensors.
"""
import numpy as np
from app.config import D_MODEL, N_LAYERS, N_HEADS, D_FFN

def build_anatomy(bi: np.ndarray, V: int) -> dict:
    """A real transformer's weight LAYOUT, seeded from our corpus statistics so
    the numbers are non-trivial (not random, not zero). Same names & shapes as
    a Llama/Qwen-style model on HuggingFace — that is the whole point.
    """
    rng = np.random.default_rng(7)
    # small init like real models (~ N(0, 0.02)); token embedding gets a real
    # signal from the bigram matrix so it isn't pure noise
    def w(*shape):
        return (rng.standard_normal(shape) * 0.02).astype(np.float32)

    # embedding: compress the [V x V] bigram grid down to D_MODEL columns
    # (an SVD — the same math that turns co-occurrence into dense vectors)
    counts = np.log1p(bi)
    U, S, _ = np.linalg.svd(counts, full_matrices=False)
    embed = (U[:, :D_MODEL] * S[:D_MODEL]).astype(np.float32)
    embed = embed / (np.abs(embed).max() + 1e-6) * 0.05   # scale to init range

    t = {"model.embed_tokens.weight": embed}
    for i in range(N_LAYERS):
        p = f"model.layers.{i}."
        t[p + "self_attn.q_proj.weight"] = w(D_MODEL, D_MODEL)
        t[p + "self_attn.k_proj.weight"] = w(D_MODEL, D_MODEL)
        t[p + "self_attn.v_proj.weight"] = w(D_MODEL, D_MODEL)
        t[p + "self_attn.o_proj.weight"] = w(D_MODEL, D_MODEL)
        t[p + "mlp.gate_proj.weight"] = w(D_FFN, D_MODEL)
        t[p + "mlp.up_proj.weight"] = w(D_FFN, D_MODEL)
        t[p + "mlp.down_proj.weight"] = w(D_MODEL, D_FFN)
        t[p + "input_layernorm.weight"] = np.ones(D_MODEL, np.float32)
        t[p + "post_attention_layernorm.weight"] = np.ones(D_MODEL, np.float32)
    t["model.norm.weight"] = np.ones(D_MODEL, np.float32)
    t["lm_head.weight"] = embed.copy()   # weight tying, like real small models
    return t

def anatomy_config(V: int) -> dict:
    return {
        "architectures": ["TF07ForCausalLM"],
        "model_type": "tf07",
        "vocab_size": V,
        "hidden_size": D_MODEL,
        "num_hidden_layers": N_LAYERS,
        "num_attention_heads": N_HEADS,
        "intermediate_size": D_FFN,
        "tie_word_embeddings": True,
    }
