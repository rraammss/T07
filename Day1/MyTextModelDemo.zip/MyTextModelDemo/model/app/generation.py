"""TF07 inference: longest-suffix replay over the tokenized corpus river."""
import re
import numpy as np
from fastapi import HTTPException
from app.config import MAX_CONTEXT, MAX_TOKENS, MAX_TOKENS_FULL
from app.state import state

def next_id(ids: list) -> int | None:
    """Longest suffix of `ids` found in the river wins; most frequent
    continuation breaks ties. Length 1 = plain bigram behaviour."""
    river = state["river"]
    for L in range(min(len(ids), MAX_CONTEXT), 0, -1):
        pat = np.array(ids[-L:], dtype=np.int64)
        # positions i where river[i:i+L] == pat  (vectorised sliding compare)
        windows = np.lib.stride_tricks.sliding_window_view(river, L)
        hits = np.nonzero((windows == pat).all(axis=1))[0]
        nxt = [int(river[i + L]) for i in hits if i + L < len(river)]
        if nxt:
            vals, cnt = np.unique(nxt, return_counts=True)
            return int(vals[cnt.argmax()])
    return None

def generate_text(prompt: str, mode: str = "sentence") -> dict:
    """Generate with the same behavior as the original single-file service."""
    if state["tok"] is None:
        raise HTTPException(409, "Model not trained yet.")
    tok = state["tok"]
    nl = tok.encode("\n").ids[-1]
    ids = tok.encode(" " + prompt.strip()).ids
    prompt_len = len(ids)
    cap = MAX_TOKENS_FULL if mode == "full" else MAX_TOKENS
    for _ in range(cap):
        nxt = next_id(ids)
        if nxt is None:
            break
        if nxt == nl:
            if mode != "full":
                break
            if ids[-1] == nl:
                break
        ids.append(nxt)
    answer = tok.decode(ids[prompt_len:]).strip()
    if mode == "sentence":
        match = re.search(r"\.(?=\s|$)", answer[10:])
        if match:
            answer = answer[:10 + match.end()]
    return {"answer": answer or "(the model has nothing for this prompt)",
            "prompt_ids": ids[:prompt_len]}
