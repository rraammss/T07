"""
sizing.py — how big is the request, layer by layer?

A request on the wire is built up in layers (this is what we teach):

  1. APPLICATION DATA — the JSON body itself (the payload the API cares about).
  2. + HTTP HEADERS   — the request line + headers (Host, Authorization,
                        Content-Type, Content-Length, User-Agent, Accept …).
                        Estimated; the real bytes depend on the HTTP client.
  3. + TCP/IP FRAMING — each packet carries ~40 bytes of IPv4 + TCP headers
                        (20 + 20). Estimated as ~40 B × number_of_packets.
  = TOTAL ON THE WIRE — the sum, chopped into MTU-sized frames
                        (~1460 B payload each). packets = ceil(total / 1460).

(TLS record overhead is real but omitted here to keep the layers clear.)
"""
import json, math
from typing import Any, Dict

MTU_PAYLOAD = 1460          # ethernet 1500 − 20 IP − 20 TCP
TCPIP_PER_PACKET = 40       # 20 B IPv4 + 20 B TCP, per packet (estimate)
CHARS_PER_TOKEN = 4

# A realistic Chat Completions request carries these header lines. Sizes are
# typical byte counts; the real total depends on the HTTP client and the key.
_TYPICAL_HTTP_HEADERS = {
    "request-line (POST /v1/... HTTP/1.1)": 40,
    "Host": 30,
    "Authorization: Bearer <api-key>": 75,
    "Content-Type: application/json": 32,
    "Content-Length": 25,
    "Accept": 25,
    "Accept-Encoding": 40,
    "User-Agent": 60,
    "Connection": 25,
}
HTTP_HEADER_BYTES = sum(_TYPICAL_HTTP_HEADERS.values())   # ≈ 352 B, itemized


def byte_breakdown(body: Dict[str, Any]) -> Dict[str, Any]:
    full = json.dumps(body, separators=(",", ":")).encode("utf-8")
    app_data = len(full)                                   # layer 1: JSON body

    # per-key contribution within the JSON body (so students see what's heavy)
    sections = {
        k: len(json.dumps({k: v}, separators=(",", ":")).encode("utf-8"))
        for k, v in body.items()
    }

    http_headers = HTTP_HEADER_BYTES                        # layer 2

    # packets depend on total, and TCP/IP framing depends on packets — resolve once:
    approx = app_data + http_headers
    packets = max(1, math.ceil(approx / MTU_PAYLOAD))
    # a few large bodies push one more packet once framing is added; re-check:
    tcpip = TCPIP_PER_PACKET * packets                      # layer 3
    total = app_data + http_headers + tcpip
    packets = max(1, math.ceil(total / MTU_PAYLOAD))
    tcpip = TCPIP_PER_PACKET * packets
    total = app_data + http_headers + tcpip

    return {
        "app_data_bytes": app_data,
        "sections": sections,
        "http_header_bytes": http_headers,
        "tcpip_bytes": tcpip,
        "tcpip_per_packet": TCPIP_PER_PACKET,
        "total_bytes": total,
        "mtu": MTU_PAYLOAD,
        "packets": packets,
        # kept for backward-compat with any old callers:
        "json_bytes": app_data,
        "header_overhead": http_headers,
        "on_wire_bytes": total,
    }


def estimate_tokens(body: Dict[str, Any]) -> int:
    """Very rough token estimate from the text content of the body."""
    text_len = len(json.dumps(body))
    return max(1, text_len // CHARS_PER_TOKEN)


def context_check(body: Dict[str, Any], context_window: int, max_output: int) -> Dict[str, Any]:
    est = estimate_tokens(body)
    fits = est < (context_window - max_output)
    return {
        "estimated_input_tokens": est,
        "context_window": context_window,
        "max_output": max_output,
        "budget_for_input": context_window - max_output,
        "fits": fits,
        "pct_used": round(100 * est / context_window, 1),
    }
