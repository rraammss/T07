"""
documents.py — handle PDF and Word attachments for this demo.

SCOPE (state clearly in the UI): PDF and Word (.docx) ONLY.
No image / audio / video in this demo.

Two things we do with an attachment:
  1. base64-encode it (what actually goes on the wire) and report the size
     inflation (raw bytes → base64 bytes, ×1.37).
  2. extract text so it can be counted/shown:
       - PDF  → pypdf (page by page)
       - Word → python-docx
     (Anthropic's count_tokens + Messages also accept PDF natively as a
      document block, so the real PDF token cost comes from that endpoint.)
"""
from __future__ import annotations
import base64, io
from typing import Any, Dict, Optional

PDF = "application/pdf"
DOCX = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
ALLOWED = {PDF, DOCX}


def encode_info(raw_bytes: bytes, media_type: str) -> Dict[str, Any]:
    b64 = base64.standard_b64encode(raw_bytes).decode("utf-8")
    return {
        "media_type": media_type,
        "raw_bytes": len(raw_bytes),
        "b64_bytes": len(b64),
        "ratio": round(len(b64) / max(1, len(raw_bytes)), 3),
        "b64": b64,
    }


def sniff_mime(raw_bytes: bytes) -> str:
    """Resolve the MIME type from the file's magic bytes — independent of whatever
    the browser claimed. Teaches that the browser-reported type isn't authoritative.

      * PDF  → starts with b'%PDF'
      * DOCX → a ZIP container (b'PK\\x03\\x04') holding word/ XML parts
    """
    head = raw_bytes[:8]
    if head.startswith(b"%PDF"):
        return PDF
    if head.startswith(b"PK\x03\x04"):
        # docx/xlsx/pptx are all zip; check for the word/ marker
        try:
            import zipfile, io
            with zipfile.ZipFile(io.BytesIO(raw_bytes)) as z:
                names = z.namelist()
                if any(n.startswith("word/") for n in names):
                    return DOCX
                return "application/zip (Office Open XML — not Word)"
        except Exception:
            return "application/zip"
    return "application/octet-stream (unrecognized)"


def docx_to_text(raw_bytes: bytes) -> str:
    """Extract plain text from a .docx (python-docx)."""
    from docx import Document
    doc = Document(io.BytesIO(raw_bytes))
    return "\n".join(p.text for p in doc.paragraphs)


def pdf_to_text(raw_bytes: bytes) -> str:
    """Extract plain text from a PDF (pypdf), page by page."""
    from pypdf import PdfReader
    reader = PdfReader(io.BytesIO(raw_bytes))
    return "\n".join((page.extract_text() or "") for page in reader.pages)


def extract_text(raw_bytes: bytes, media_type: str) -> str:
    """Dispatch to the right extractor for the attachment type."""
    if media_type == DOCX:
        return docx_to_text(raw_bytes)
    if media_type == PDF:
        return pdf_to_text(raw_bytes)
    return ""
