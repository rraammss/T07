"""
tokenizer.py — count input tokens with the RIGHT tokenizer for each provider.

Teaching point: every provider has its own tokenizer. Using the wrong one gives
wrong numbers.

  * OpenAI    → tiktoken (its own BPE tokenizer). Exact for GPT.
  * Anthropic → count_tokens endpoint: client.messages.count_tokens(...). Exact.
  * Gemini    → client.models.count_tokens(model, contents) → total_tokens. Exact.
  * Groq      → serves Llama models (SentencePiece tokenizer). We don't ship that
                vocab, so we show a labeled ~4-chars/token ESTIMATE.

Each function returns: {tokens, method, exact, note}
"""
from __future__ import annotations
from typing import Any, Dict, List, Optional

_ENC = None


def _tiktoken_enc():
    global _ENC
    if _ENC is None:
        import tiktoken
        try:
            _ENC = tiktoken.get_encoding("o200k_base")
        except Exception:
            _ENC = tiktoken.get_encoding("cl100k_base")
    return _ENC


def _rough(system: str, user: str, history: List[Dict]) -> int:
    parts = [system] if system else []
    for m in history:
        c = m.get("content", "")
        if isinstance(c, str):
            parts.append(c)
    parts.append(user)
    return max(1, len("\n".join(parts)) // 4)


def count_openai(*, system, user, history) -> Dict[str, Any]:
    enc = _tiktoken_enc()
    parts = [system] if system else []
    for m in history:
        c = m.get("content", "")
        if isinstance(c, str):
            parts.append(c)
    parts.append(user)
    n = len(enc.encode("\n".join(parts))) + 4 * (len(history) + (2 if system else 1))
    return {"tokens": n, "method": "tiktoken (o200k_base)", "exact": True,
            "note": "tiktoken is OpenAI's own tokenizer — exact for GPT models."}


def count_anthropic(vendor, *, model, system, user, history,
                    attachment_b64=None, attachment_media="application/pdf") -> Dict[str, Any]:
    if not vendor.has_key():
        return {"tokens": None, "method": "Anthropic count_tokens API", "exact": True,
                "note": f"{vendor.key_env} not set — cannot call count_tokens."}
    if attachment_b64:
        content: Any = [
            {"type": "text", "text": user},
            {"type": "document", "source": {"type": "base64",
             "media_type": attachment_media, "data": attachment_b64}},
        ]
    else:
        content = user
    messages = list(history) + [{"role": "user", "content": content}]
    kwargs: Dict[str, Any] = {"model": model, "messages": messages}
    if system:
        kwargs["system"] = system
    try:
        resp = vendor.client().messages.count_tokens(**kwargs)
        return {"tokens": resp.input_tokens, "method": "Anthropic count_tokens API", "exact": True,
                "note": "POST /v1/messages/count_tokens — Claude's own tokenizer, exact (supports PDFs)."}
    except Exception as e:
        return {"tokens": None, "method": "Anthropic count_tokens API", "exact": True,
                "note": f"count_tokens call failed: {e}"}


def count_google(vendor, *, model, system, user, history,
                 attachment_b64=None, attachment_media="application/pdf") -> Dict[str, Any]:
    if not vendor.has_key():
        return {"tokens": None, "method": "Gemini count_tokens API", "exact": True,
                "note": f"{vendor.key_env} not set — cannot call count_tokens."}
    try:
        from google.genai import types  # noqa
        # build the same 'contents' the send path uses
        contents = []
        for m in history:
            role = "model" if m.get("role") == "assistant" else "user"
            c = m.get("content", "")
            if isinstance(c, str):
                contents.append({"role": role, "parts": [{"text": c}]})
        parts = [{"text": (system + "\n" + user) if system else user}]
        contents.append({"role": "user", "parts": parts})
        resp = vendor.client().models.count_tokens(model=model, contents=contents)
        n = getattr(resp, "total_tokens", None)
        return {"tokens": n, "method": "Gemini count_tokens API", "exact": True,
                "note": "client.models.count_tokens — Gemini's own tokenizer, exact."}
    except Exception as e:
        return {"tokens": None, "method": "Gemini count_tokens API", "exact": True,
                "note": f"count_tokens call failed: {e}"}


def count_groq(*, system, user, history) -> Dict[str, Any]:
    return {"tokens": _rough(system, user, history), "method": "estimate (~4 chars/token)",
            "exact": False,
            "note": "Groq serves Llama models (SentencePiece). No local vocab shipped — this is an approximation."}


def count_for(vendor, *, model, system, user, history,
              attachment_b64=None, attachment_media="application/pdf") -> Dict[str, Any]:
    if vendor.id == "openai":
        return count_openai(system=system, user=user, history=history)
    if vendor.id == "anthropic":
        return count_anthropic(vendor, model=model, system=system, user=user, history=history,
                               attachment_b64=attachment_b64, attachment_media=attachment_media)
    if vendor.id == "google":
        return count_google(vendor, model=model, system=system, user=user, history=history,
                            attachment_b64=attachment_b64, attachment_media=attachment_media)
    if vendor.id == "groq":
        return count_groq(system=system, user=user, history=history)
    return {"tokens": _rough(system, user, history), "method": "estimate", "exact": False,
            "note": "unknown provider — estimate only."}


def count_text(vendor, model: str, text: str) -> int:
    """Count a single text blob with the provider's own tokenizer. Used to break
    a request into per-component segments (history / system / message)."""
    if not text:
        return 0
    if vendor.id == "openai":
        try:
            return len(_tiktoken_enc().encode(text))
        except Exception:
            return max(1, len(text) // 4)
    if vendor.id == "anthropic":
        if not vendor.has_key():
            return max(1, len(text) // 4)
        try:
            r = vendor.client().messages.count_tokens(
                model=model, messages=[{"role": "user", "content": text}])
            return r.input_tokens
        except Exception:
            return max(1, len(text) // 4)
    if vendor.id == "google":
        if not vendor.has_key():
            return max(1, len(text) // 4)
        try:
            r = vendor.client().models.count_tokens(
                model=model, contents=[{"role": "user", "parts": [{"text": text}]}])
            return getattr(r, "total_tokens", None) or max(1, len(text) // 4)
        except Exception:
            return max(1, len(text) // 4)
    return max(1, len(text) // 4)   # groq / unknown
