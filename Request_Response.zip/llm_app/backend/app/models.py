"""
models.py — the model capability table.

Context-window sizes are maintained HERE because they are not reliably
discoverable at runtime for every provider:

  * OpenAI   — no runtime metadata API for context window; keep a table.
  * Anthropic — Models API returns metadata; we still keep a table for offline.
  * Gemini   — Models API returns input_token_limit / output_token_limit.
  * Groq     — serves open models; keep a table (context per model).

Each entry: context_window (input tokens) and max_output (output tokens).
"""
from dataclasses import dataclass
from typing import Dict, List


@dataclass(frozen=True)
class ModelInfo:
    id: str
    provider: str
    label: str
    context_window: int
    max_output: int
    source: str


MODELS: Dict[str, ModelInfo] = {
    # Anthropic
    "claude-haiku-4-5": ModelInfo("claude-haiku-4-5", "anthropic", "Claude Haiku 4.5",
        200_000, 64_000, "anthropic docs / Models API"),
    "claude-sonnet-4-5": ModelInfo("claude-sonnet-4-5", "anthropic", "Claude Sonnet 4.5",
        200_000, 64_000, "anthropic docs / Models API"),
    # OpenAI
    "gpt-4o-mini": ModelInfo("gpt-4o-mini", "openai", "GPT-4o mini",
        128_000, 16_384, "openai model docs (maintained table)"),
    "gpt-4o": ModelInfo("gpt-4o", "openai", "GPT-4o",
        128_000, 16_384, "openai model docs (maintained table)"),
    # Google Gemini
    "gemini-2.5-flash": ModelInfo("gemini-2.5-flash", "google", "Gemini 2.5 Flash",
        1_048_576, 65_536, "gemini Models API (input/output token limits)"),
    "gemini-2.5-pro": ModelInfo("gemini-2.5-pro", "google", "Gemini 2.5 Pro",
        1_048_576, 65_536, "gemini Models API (input/output token limits)"),
    # Groq (open models)
    "llama-3.3-70b-versatile": ModelInfo("llama-3.3-70b-versatile", "groq", "Llama 3.3 70B (Groq)",
        128_000, 32_768, "groq model docs (maintained table)"),
    "llama-3.1-8b-instant": ModelInfo("llama-3.1-8b-instant", "groq", "Llama 3.1 8B Instant (Groq)",
        128_000, 8_192, "groq model docs (maintained table)"),
}


def for_provider(provider: str) -> List[ModelInfo]:
    return [m for m in MODELS.values() if m.provider == provider]


def get(model_id: str) -> ModelInfo:
    return MODELS[model_id]


def as_dict() -> List[dict]:
    return [{"id": m.id, "provider": m.provider, "label": m.label,
             "context_window": m.context_window, "max_output": m.max_output, "source": m.source}
            for m in MODELS.values()]
