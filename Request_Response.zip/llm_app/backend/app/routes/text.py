"""routes/text.py — Tab 3: build/size/tokenize/attach/send/stream the text payload."""
import json, base64
from fastapi import APIRouter, Request
from fastapi.responses import StreamingResponse
from fastapi.concurrency import run_in_threadpool
from .. import vendors, tokenizer, documents
from ..sizing import byte_breakdown
from ._shared import attach_kwargs

router = APIRouter()


@router.post("/api/build")
async def build(req: Request):
    d = await req.json()
    v = vendors.get(d.get("provider", "anthropic"))
    model_id = d.get("model") or v.default_model
    payload = v.build_payload(
        model=model_id, system=d.get("system", ""), user=d.get("user", ""),
        history=d.get("history", []), stream=bool(d.get("stream", True)),
        max_tokens=int(d.get("max_tokens", 256)),
        **attach_kwargs(d))
    return {"payload": payload, "pretty": json.dumps(payload, indent=2)[:8000],
            "bytes": byte_breakdown(payload)}


# ---- Tab 3: count input tokens with the RIGHT tokenizer ----


@router.post("/api/count_tokens")
async def count_tokens(req: Request):
    d = await req.json()
    provider = d.get("provider", "anthropic")
    v = vendors.get(provider)
    model_id = d.get("model") or v.default_model
    system = d.get("system", ""); user = d.get("user", ""); history = d.get("history", [])
    max_tokens = int(d.get("max_tokens", 256))
    att = d.get("attachment_b64"); media = d.get("attachment_media", "application/pdf")

    tk = await run_in_threadpool(
        tokenizer.count_for, v, model=model_id, system=system, user=user,
        history=history, attachment_b64=att, attachment_media=media)

    # per-component breakdown (real tokenizer) so the bar can show what fills the window
    def _breakdown():
        hist_text = "\n".join(m.get("content", "") for m in history
                              if isinstance(m.get("content"), str))
        system_t = tokenizer.count_text(v, model_id, system)
        message_t = tokenizer.count_text(v, model_id, user)
        history_t = tokenizer.count_text(v, model_id, hist_text)
        attach_t = 0
        if att:
            with_att = tokenizer.count_for(v, model=model_id, system=system, user=user,
                                           history=history, attachment_b64=att, attachment_media=media).get("tokens") or 0
            without = tokenizer.count_for(v, model=model_id, system=system, user=user,
                                          history=history, attachment_b64=None, attachment_media=media).get("tokens") or 0
            attach_t = max(0, with_att - without)
        return {"history": history_t, "system": system_t, "message": message_t, "attachment": attach_t}
    breakdown = await run_in_threadpool(_breakdown)

    cx = await run_in_threadpool(ctxmod.context_for, v, model_id)
    input_tokens = tk.get("tokens")
    out = {"tokenizer": tk, "context": cx, "max_output": max_tokens, "breakdown": breakdown}
    if input_tokens is not None and cx.get("context_window"):
        cw = cx["context_window"]
        out["fit"] = {
            "input_tokens": input_tokens,
            "reserved_output": max_tokens,
            "total_needed": input_tokens + max_tokens,
            "context_window": cw,
            "fits": (input_tokens + max_tokens) <= cw,
            "pct_input": round(100 * input_tokens / cw, 2),
            "pct_output": round(100 * max_tokens / cw, 2),
        }
    return out


# ---- Tab 3: attachment encode (PDF / Word only) with progress ----


@router.post("/api/attach")
async def attach(req: Request):
    d = await req.json()
    browser_media = d.get("media_type", "")     # what the browser claimed (file.type)
    data_url_b64 = d.get("b64", "")
    raw = base64.b64decode(data_url_b64) if data_url_b64 else b""
    resolved_media = documents.sniff_mime(raw)  # what the bytes actually are

    # validate on the RESOLVED type (bytes don't lie); the browser type is advisory
    if resolved_media not in documents.ALLOWED:
        return JSONResponse({"ok": False,
            "browser_media": browser_media or "(none)", "resolved_media": resolved_media,
            "message": "This demo accepts PDF and Word (.docx) only — no image / audio / video."},
            status_code=200)

    info = documents.encode_info(raw, resolved_media)
    resp = {"ok": True,
            "browser_media": browser_media or "(none reported)",
            "resolved_media": resolved_media,
            "mime_mismatch": bool(browser_media) and browser_media != resolved_media,
            "raw_bytes": info["raw_bytes"], "b64_bytes": info["b64_bytes"],
            "ratio": info["ratio"], "b64": info["b64"]}
    try:
        txt = documents.extract_text(raw, resolved_media)
        resp["extracted_chars"] = len(txt)
        resp["preview"] = txt[:400]
        resp["extracted_text"] = txt[:200000]   # full text (capped) for history-augmentation
    except Exception as e:
        resp["extracted_chars"] = None
        resp["preview"] = f"(could not extract: {e})"
    return resp


# ---- Tab 3: send ----


@router.post("/api/send")
async def send(req: Request):
    d = await req.json()
    v = vendors.get(d.get("provider", "anthropic"))
    payload = v.build_payload(
        model=d.get("model") or v.default_model, system=d.get("system", ""), user=d.get("user", ""),
        history=d.get("history", []), stream=False, max_tokens=int(d.get("max_tokens", 256)),
        **attach_kwargs(d))
    return await run_in_threadpool(v.send, payload)


@router.post("/api/stream")
async def stream(req: Request):
    d = await req.json()
    v = vendors.get(d.get("provider", "anthropic"))
    payload = v.build_payload(
        model=d.get("model") or v.default_model, system=d.get("system", ""), user=d.get("user", ""),
        history=d.get("history", []), stream=True, max_tokens=int(d.get("max_tokens", 256)),
        **attach_kwargs(d))

    async def sse():
        import anyio
        send_stream, recv_stream = anyio.create_memory_object_stream(64)
        async def pump():
            def work():
                for ev in v.stream(payload):
                    anyio.from_thread.run(send_stream.send, ev)
            await run_in_threadpool(work)
            await send_stream.aclose()
        async with anyio.create_task_group() as tg:
            tg.start_soon(pump)
            async for ev in recv_stream:
                yield f"data: {json.dumps(ev)}\n\n"

    return StreamingResponse(sse(), media_type="text/event-stream")


# ----- File upload / reference-by-id tab -----------------------------------
