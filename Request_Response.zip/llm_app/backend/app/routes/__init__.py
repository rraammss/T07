"""
routes/ — the HTTP endpoints, grouped by tab/feature so each file mirrors a
part of the UI:

  meta.py          — health, providers, models, context window
  connection.py    — Tab 1: connection test
  errors_routes.py — Tab 2: error prepare/execute
  text.py          — Tab 3: build, count_tokens, attach, send, stream
  files.py         — Tab 4: file upload-once / reference-by-id

main.py just wires these routers onto the app.
"""
from . import meta, connection, errors_routes, text, files

all_routers = [meta.router, connection.router, errors_routes.router,
               text.router, files.router]
