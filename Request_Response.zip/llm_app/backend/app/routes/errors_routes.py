"""routes/errors_routes.py — Tab 2: prepare a request for a target HTTP error, then fire it."""
from fastapi import APIRouter
from fastapi.concurrency import run_in_threadpool
from .. import vendors, errors

router = APIRouter()


@router.get("/api/errors")
def error_meta():
    return errors.meta_list()


@router.get("/api/error_prepare")
async def error_prepare(provider: str = "anthropic", code: str = "401"):
    """Return the exact crafted request + steps — nothing is sent yet."""
    v = vendors.get(provider); mod = errors.get(code)
    return await run_in_threadpool(mod.prepare, v)


@router.get("/api/error_execute")
async def error_execute(provider: str = "anthropic", code: str = "401"):
    """Actually fire the crafted request and return the result."""
    v = vendors.get(provider); mod = errors.get(code)
    return await run_in_threadpool(mod.execute, v)


# ---- Tab 3: context window (live where possible) ----
