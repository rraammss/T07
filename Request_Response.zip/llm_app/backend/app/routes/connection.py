"""routes/connection.py — Tab 1: a tiny real call that proves the key works."""
from fastapi import APIRouter
from fastapi.concurrency import run_in_threadpool
from .. import vendors

router = APIRouter()


@router.get("/api/connection_test")
async def connection_test(provider: str = "anthropic", prompt: str = "Say 'ok'."):
    return await run_in_threadpool(vendors.get(provider).connection_test, prompt)


# ---- Tab 2: two-phase errors (show request, THEN send on click) ----
