"""routes/files.py — Tab 4: real upload-once / reference-by-id file endpoints."""
import json, base64
from fastapi import APIRouter, Request
from fastapi.concurrency import run_in_threadpool
from .. import vendors, documents, fileref
from ..sizing import byte_breakdown

router = APIRouter()


@router.get("/api/file_support")
async def file_support():
    """Which providers support upload-once / reference-by-id, and how."""
    return fileref.PROVIDER_FILE_SUPPORT


@router.post("/api/file_upload")
async def file_upload(req: Request):
    """REAL upload to the provider's Files API. Requires the provider key in env."""
    d = await req.json()
    provider = d.get("provider", "openai")
    v = vendors.get(provider)
    b64 = d.get("b64", "")
    filename = d.get("filename", "document.pdf")
    raw = base64.b64decode(b64) if b64 else b""
    media = documents.sniff_mime(raw) if raw else "application/pdf"
    out = await run_in_threadpool(fileref.upload, v, raw, filename, media)
    if out.get("ok"):
        out["upload_once_bytes"] = len(base64.standard_b64encode(raw))
    return out


@router.post("/api/file_build")
async def file_build(req: Request):
    """Build + size the chat body that REFERENCES the file by id (not inlined)."""
    d = await req.json()
    provider = d.get("provider", "openai")
    v = vendors.get(provider)
    model_id = d.get("model") or v.default_model
    payload = fileref.build_referenced_payload(
        provider, model=model_id, system=d.get("system", ""), user=d.get("user", ""),
        history=d.get("history", []), file_id=d.get("file_id", "file-xxxx"),
        max_tokens=int(d.get("max_tokens", 300)))
    b = byte_breakdown(payload)
    return {"payload": payload, "pretty": json.dumps(payload, indent=2)[:8000], "bytes": b}


@router.post("/api/file_send")
async def file_send(req: Request):
    """REAL model call with the file referenced by id."""
    d = await req.json()
    provider = d.get("provider", "openai")
    v = vendors.get(provider)
    model_id = d.get("model") or v.default_model
    out = await run_in_threadpool(
        fileref.send_referenced, v, model=model_id, system=d.get("system", ""),
        user=d.get("user", ""), history=d.get("history", []),
        file_id=d.get("file_id", ""), max_tokens=int(d.get("max_tokens", 300)))
    return out
