"""routes/meta.py — what's available: health, providers, models, context window."""
from fastapi import APIRouter
from fastapi.concurrency import run_in_threadpool
from .. import vendors, models, context as ctxmod

router = APIRouter()


@router.get("/api/health")
def health():
    return {v.id: {"label": v.label, "key_env": v.key_env, "has_key": v.has_key()}
            for v in vendors.all_vendors()}


@router.get("/api/vendors")
def vendor_list():
    return [{"id": v.id, "label": v.label, "default_model": v.default_model}
            for v in vendors.all_vendors()]


@router.get("/api/models")
def model_list():
    return models.as_dict()


# ---- Tab 1 ----


@router.get("/api/context")
async def context(provider: str = "anthropic", model: str = ""):
    v = vendors.get(provider)
    model_id = model or v.default_model
    return await run_in_threadpool(ctxmod.context_for, v, model_id)


# ---- Tab 3: build + byte size ----
