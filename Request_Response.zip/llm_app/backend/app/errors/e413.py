"""errors/e413.py — 413 Payload too large (BYTES limit, not tokens)."""
from ._util import result, pretty

CODE = "413"; NAME = "Payload too large"
WHY = "the request body exceeds the byte size the server accepts"
CHARS = 6_300_000  # ~6 MB


def prepare(vendor):
    req = {"client_api_key": f"${vendor.key_env} (real key)",
           "model": vendor.default_model,
           "messages": [{"role": "user", "content": f"<<~6 MB of text — {CHARS:,} chars>>"}],
           "max_tokens": 8}
    steps = [
        {"label": "use good key", "detail": f"{vendor.key_env} from env — auth passes"},
        {"label": "craft the fault", "detail": f"user message ≈ 6 MB ({CHARS:,} chars)"},
        {"label": "will send", "detail": "trips the BYTES limit at the HTTP gateway (not the token limit)"},
    ]
    return {"display": req, "display_pretty": pretty(req), "steps": steps}


def execute(vendor):
    if not vendor.has_key():
        return result(CODE, "no_key", f"{vendor.key_env} not set")
    big = "banking " * 900_000
    payload = vendor.build_payload(model=vendor.default_model, system="", user=big,
                                   history=[], stream=False, max_tokens=8)
    r = vendor.send(payload)
    got = r.get("status") or ("200" if r.get("ok") else "err")
    return result(CODE, got, "oversized HTTP body (may surface as 400/429)", r.get("raw", ""))
