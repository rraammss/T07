"""
errors/e401.py — 401 Authentication.

REPRODUCTION (safe): env keeps the GOOD key untouched. We build a fresh SDK
client with an EXPLICIT wrong key and make one otherwise-normal call.
"""
from ._util import status_of, result, pretty

CODE = "401"; NAME = "Authentication"
WHY = "who are you? — the API key is missing or wrong"
BAD_KEY = "sk-invalid-key-for-demo-00000000000000000000"


def prepare(vendor):
    """Return the exact request we will send, plus the backend steps."""
    req = {
        "sdk_call": ("client.messages.create(...)" if vendor.id == "anthropic"
                     else "client.chat.completions.create(...)"),
        "client_api_key": BAD_KEY,          # <-- the fault, shown explicitly
        "model": vendor.default_model,
        "messages": [{"role": "user", "content": "hi"}],
        "max_tokens": 8,
    }
    steps = [
        {"label": "use a fresh client", "detail": f"vendor.client(api_key='{BAD_KEY[:22]}…')"},
        {"label": "env untouched", "detail": f"{vendor.key_env} in the environment is NOT modified"},
        {"label": "build request", "detail": "a normal, well-formed 'hi' message"},
        {"label": "will send", "detail": "one call with the bad-key client → gate 1 rejects it"},
    ]
    return {"display": req, "display_pretty": pretty(req), "steps": steps}


def execute(vendor):
    try:
        client = vendor.client(api_key=BAD_KEY)     # explicit wrong key; env safe
        if vendor.id == "anthropic":
            client.messages.create(model=vendor.default_model, max_tokens=8,
                                   messages=[{"role": "user", "content": "hi"}])
        else:
            client.chat.completions.create(model=vendor.default_model, max_tokens=8,
                                          messages=[{"role": "user", "content": "hi"}])
        return result(CODE, "200", "unexpectedly accepted the bad key")
    except Exception as e:
        return result(CODE, status_of(e),
                      "fresh client used an explicit invalid key; env key never changed", str(e))
