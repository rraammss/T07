"""
errors/_util.py — shared helpers.

Two-phase design so the UI can SHOW the exact crafted request before sending:
  * prepare(vendor) -> {"display": <the request we'll send>, "trace": [...] }
  * execute(vendor) -> actually fires it, returns {status, matched, raw, ...}

Reproduction is safe: we never mutate os.environ. Auth faults are produced by
passing an explicit wrong key into a fresh client via vendor.client(api_key=...).
"""
import json
from typing import Any, Dict, List, Optional


def status_of(e: Exception) -> Optional[int]:
    code = getattr(e, "status_code", None)
    if code:
        return code
    resp = getattr(e, "response", None)
    if resp is not None and getattr(resp, "status_code", None):
        return resp.status_code
    s = str(e)
    for guess in ("400", "401", "403", "404", "413", "429", "500", "503"):
        if guess in s:
            return int(guess)
    return None


def pretty(obj: Any) -> str:
    try:
        return json.dumps(obj, indent=2)[:2000]
    except Exception:
        return str(obj)[:2000]


def result(expected: str, got, note: str, raw: str = "") -> Dict[str, Any]:
    return {
        "expected": expected,
        "status": got,
        "matched": str(got) == str(expected),
        "note": note,
        "raw": (raw or "")[:800],
    }
