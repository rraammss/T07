"""errors/e404.py — 404 Not found. Model that doesn't exist."""
from ._util import result, pretty

CODE = "404"; NAME = "Not found"
WHY = "the model name (or endpoint path) doesn't exist"
FAKE = "totally-made-up-model-xyz"


def prepare(vendor):
    req = {"client_api_key": f"${vendor.key_env} (real key)",
           "model": FAKE, "messages": [{"role": "user", "content": "hi"}], "max_tokens": 8}
    steps = [
        {"label": "use good key", "detail": f"{vendor.key_env} from env — auth passes"},
        {"label": "craft the fault", "detail": f"model='{FAKE}'"},
        {"label": "will send", "detail": "the gateway can't route it to any model server"},
    ]
    return {"display": req, "display_pretty": pretty(req), "steps": steps}


def execute(vendor):
    if not vendor.has_key():
        return result(CODE, "no_key", f"{vendor.key_env} not set")
    payload = vendor.build_payload(model=FAKE, system="", user="hi", history=[],
                                   stream=False, max_tokens=8)
    r = vendor.send(payload)
    got = r.get("status") or ("200" if r.get("ok") else "err")
    return result(CODE, got, "model name doesn't exist", r.get("raw", ""))
