"""errors/e400.py — 400 Bad request / schema."""
from ._util import status_of, result, pretty

CODE = "400"; NAME = "Bad request / schema"
WHY = "the JSON is malformed or a required field is missing"


def prepare(vendor):
    if vendor.id == "anthropic":
        req = {"sdk_call": "client.messages.create(...)",
               "model": vendor.default_model,
               "messages": [{"role": "user", "content": "hi"}],
               "max_tokens": "<<OMITTED — but it is REQUIRED>>"}
        fault = "omit the REQUIRED max_tokens"
    else:
        req = {"sdk_call": "client.chat.completions.create(...)",
               "model": vendor.default_model,
               "messages": "THIS SHOULD BE A LIST (sent as a string on purpose)"}
        fault = "messages sent as a string, not a list"
    steps = [
        {"label": "use good key", "detail": f"{vendor.key_env} from env — auth passes"},
        {"label": "craft the fault", "detail": fault},
        {"label": "will send", "detail": "the schema check rejects it before the model runs"},
    ]
    return {"display": req, "display_pretty": pretty(req), "steps": steps}


def execute(vendor):
    if not vendor.has_key():
        return result(CODE, "no_key", f"{vendor.key_env} not set")
    try:
        client = vendor.client()
        if vendor.id == "anthropic":
            client.messages.create(model=vendor.default_model,
                                   messages=[{"role": "user", "content": "hi"}])  # type: ignore
        else:
            client.chat.completions.create(model=vendor.default_model,
                                          messages="THIS SHOULD BE A LIST")  # type: ignore
        return result(CODE, "200", "malformed body unexpectedly accepted")
    except Exception as e:
        return result(CODE, status_of(e), "required field missing / wrong type", str(e))
