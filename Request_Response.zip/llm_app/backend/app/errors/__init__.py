"""errors/__init__.py — registry. Each module: CODE, NAME, WHY, prepare(v), execute(v)."""
from types import ModuleType
from typing import Dict, List
from . import e401, e403, e400, e404, e413, e429

MODULES: List[ModuleType] = [e401, e403, e400, e404, e413, e429]
REGISTRY: Dict[str, ModuleType] = {m.CODE: m for m in MODULES}


def meta_list():
    return [{"code": m.CODE, "name": m.NAME, "why": m.WHY} for m in MODULES]


def get(code: str) -> ModuleType:
    if code not in REGISTRY:
        raise KeyError(f"unknown error code '{code}'")
    return REGISTRY[code]
