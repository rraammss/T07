"""errors/e429.py — 429 Rate limit / quota (burst)."""
from ._util import result, pretty

CODE = "429"; NAME = "Rate limit / quota"
WHY = "too many requests, or you're out of credits"
BURST = 25


def prepare(vendor):
    req = {"client_api_key": f"${vendor.key_env} (real key)",
           "model": vendor.default_model,
           "messages": [{"role": "user", "content": "hi"}], "max_tokens": 4,
           "_note": f"the SAME request sent {BURST}× as fast as possible"}
    steps = [
        {"label": "use good key", "detail": f"{vendor.key_env} from env — auth passes"},
        {"label": "craft the fault", "detail": f"loop {BURST} identical requests, no delay"},
        {"label": "will send", "detail": "they pile up against your per-minute limit"},
    ]
    return {"display": req, "display_pretty": pretty(req), "steps": steps}


def execute(vendor):
    if not vendor.has_key():
        return result(CODE, "no_key", f"{vendor.key_env} not set")
    payload = vendor.build_payload(model=vendor.default_model, system="", user="hi",
                                   history=[], stream=False, max_tokens=4)
    last = None
    for i in range(BURST):
        last = vendor.send(payload)
        if last.get("status") == 429:
            break
    got = last.get("status") or ("200" if last.get("ok") else "err")
    note = f"burst of {BURST}" + ("" if got == 429 else " — limit not reached on your key")
    return result(CODE, got, note, last.get("raw", ""))
