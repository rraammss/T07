"""
fileref.py — REAL "upload once, reference by id" using each provider's SDK.

No simulation. Uploads hit the provider's Files API; sends reference the returned
id and call the real model. Requires the provider's key in the environment (same
as the Text-payload tab). Providers without a chat Files API (Groq) report that
honestly.

  * OpenAI    client.files.create(file, purpose="user_data") -> file.id
              client.responses.create(input=[{content:[input_text, input_file{file_id}]}])
  * Anthropic client.beta.files.upload(...) -> id   (beta: files-api-2025-04-14)
              client.beta.messages.create(..., document{source:{type:"file",file_id}})
  * Gemini    client.files.upload(...) -> File(name, uri)
              client.models.generate_content(contents=[..., file ref])
  * Groq      no Files API for chat inputs -> not supported (must inline)
"""
import io
import time
from typing import Any, Dict, List

PROVIDER_FILE_SUPPORT: Dict[str, Dict[str, Any]] = {
    "openai": {
        "supported": True,
        "endpoint": "POST /v1/files  (purpose=user_data)",
        "reference": "Responses API - input_file { file_id }",
        "note": "Upload once via the Files API, reference by id in responses.create.",
    },
    "anthropic": {
        "supported": True,
        "endpoint": "POST /v1/files  (beta: files-api-2025-04-14)",
        "reference": "Messages - document { source: { type:'file', file_id } }",
        "note": "Create once, use many times. Beta Files API.",
    },
    "google": {
        "supported": True,
        "endpoint": "files.upload  (File API)",
        "reference": "generateContent - the uploaded File is passed in contents",
        "note": "Returns a files/<id> name + uri you reference.",
    },
    "groq": {
        "supported": False,
        "endpoint": "-",
        "reference": "not available - Groq has no Files API for chat inputs",
        "note": "You must inline the extracted text every turn (see the Text tab).",
    },
}

_ANTHROPIC_FILES_BETA = "files-api-2025-04-14"


def _status(e) -> int:
    return getattr(e, "status_code", None) or getattr(getattr(e, "response", None), "status_code", 0) or 500


def upload(vendor, raw_bytes: bytes, filename: str, media_type: str) -> Dict[str, Any]:
    """Really upload the file to the provider's Files API."""
    pid = vendor.id
    if not PROVIDER_FILE_SUPPORT.get(pid, {}).get("supported"):
        return {"ok": False, "supported": False,
                "message": PROVIDER_FILE_SUPPORT.get(pid, {}).get("reference", "not supported"),
                "note": PROVIDER_FILE_SUPPORT.get(pid, {}).get("note", "")}
    if not vendor.has_key():
        return {"ok": False, "reason": "no_key",
                "message": f"{vendor.key_env} not set - add it to .env and restart the backend."}
    t0 = time.time()
    try:
        if pid == "openai":
            f = vendor.client().files.create(
                file=(filename, io.BytesIO(raw_bytes), media_type), purpose="user_data")
            env = f.model_dump() if hasattr(f, "model_dump") else dict(f)
            file_id = f.id
        elif pid == "anthropic":
            f = vendor.client().beta.files.upload(
                file=(filename, io.BytesIO(raw_bytes), media_type))
            env = f.model_dump() if hasattr(f, "model_dump") else dict(f)
            file_id = f.id
        elif pid == "google":
            f = vendor.client().files.upload(
                file=io.BytesIO(raw_bytes),
                config={"mime_type": media_type, "display_name": filename})
            env = f.model_dump() if hasattr(f, "model_dump") else {
                "name": getattr(f, "name", None), "uri": getattr(f, "uri", None)}
            file_id = getattr(f, "name", None) or getattr(f, "uri", None)
        else:
            return {"ok": False, "supported": False, "message": "not supported"}
        ms = int((time.time() - t0) * 1000)
        return {"ok": True, "supported": True, "file_id": file_id, "response": env,
                "latency_ms": ms, "raw_bytes": len(raw_bytes),
                "endpoint": PROVIDER_FILE_SUPPORT[pid]["endpoint"],
                "reference": PROVIDER_FILE_SUPPORT[pid]["reference"],
                "note": PROVIDER_FILE_SUPPORT[pid]["note"]}
    except Exception as e:
        return {"ok": False, "status": _status(e), "message": str(e)[:600]}


def build_referenced_payload(pid: str, *, model: str, system: str, user: str,
                             history: List[Dict], file_id: str,
                             max_tokens: int) -> Dict[str, Any]:
    """Build the exact chat body that references the uploaded file by id."""
    if pid == "google":
        contents = []
        for m in history:
            role = "model" if m.get("role") == "assistant" else "user"
            contents.append({"role": role, "parts": [{"text": m.get("content", "")}]})
        contents.append({"role": "user",
                         "parts": [{"text": user}, {"file_data": {"file_uri": file_id}}]})
        payload: Dict[str, Any] = {"model": model, "contents": contents}
        if system:
            payload["system_instruction"] = {"parts": [{"text": system}]}
        return payload
    if pid == "anthropic":
        messages = list(history)
        messages.append({"role": "user", "content": [
            {"type": "text", "text": user},
            {"type": "document", "source": {"type": "file", "file_id": file_id}}]})
        payload = {"model": model, "max_tokens": max_tokens, "messages": messages}
        if system:
            payload["system"] = system
        return payload
    # openai responses-style
    input_items: List[Dict] = []
    if system:
        input_items.append({"role": "system", "content": system})
    input_items += list(history)
    input_items.append({"role": "user", "content": [
        {"type": "input_text", "text": user},
        {"type": "input_file", "file_id": file_id}]})
    return {"model": model, "input": input_items, "max_output_tokens": max_tokens}


def send_referenced(vendor, *, model: str, system: str, user: str,
                    history: List[Dict], file_id: str, max_tokens: int) -> Dict[str, Any]:
    """Really call the model with the file referenced by id."""
    pid = vendor.id
    if not vendor.has_key():
        return {"ok": False, "reason": "no_key", "message": f"{vendor.key_env} not set."}
    t0 = time.time()
    try:
        if pid == "openai":
            payload = build_referenced_payload(pid, model=model, system=system, user=user,
                                               history=history, file_id=file_id, max_tokens=max_tokens)
            r = vendor.client().responses.create(**payload)
            raw = r.model_dump() if hasattr(r, "model_dump") else None
            text = getattr(r, "output_text", "") or ""
            u = getattr(r, "usage", None)
            usage = {"input_tokens": getattr(u, "input_tokens", None),
                     "output_tokens": getattr(u, "output_tokens", None)} if u else {}
        elif pid == "anthropic":
            messages = list(history)
            messages.append({"role": "user", "content": [
                {"type": "text", "text": user},
                {"type": "document", "source": {"type": "file", "file_id": file_id}}]})
            kwargs = {"model": model, "max_tokens": max_tokens, "messages": messages,
                      "betas": [_ANTHROPIC_FILES_BETA]}
            if system:
                kwargs["system"] = system
            r = vendor.client().beta.messages.create(**kwargs)
            raw = r.model_dump() if hasattr(r, "model_dump") else None
            text = "".join(b.text for b in r.content if getattr(b, "type", "") == "text")
            usage = {"input_tokens": r.usage.input_tokens, "output_tokens": r.usage.output_tokens}
        elif pid == "google":
            fobj = vendor.client().files.get(name=file_id)
            cfg = {"max_output_tokens": max_tokens}
            if system:
                cfg["system_instruction"] = system
            r = vendor.client().models.generate_content(model=model, contents=[user, fobj], config=cfg)
            raw = r.model_dump() if hasattr(r, "model_dump") else None
            text = getattr(r, "text", "") or ""
            um = getattr(r, "usage_metadata", None)
            usage = {"input_tokens": getattr(um, "prompt_token_count", None),
                     "output_tokens": getattr(um, "candidates_token_count", None)} if um else {}
        else:
            return {"ok": False, "supported": False, "message": "not supported"}
        ms = int((time.time() - t0) * 1000)
        return {"ok": True, "status": 200, "latency_ms": ms, "text": text,
                "usage": usage, "raw_response": raw}
    except Exception as e:
        return {"ok": False, "status": _status(e), "message": str(e)[:600]}
