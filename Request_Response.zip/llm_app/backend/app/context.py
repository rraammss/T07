"""
context.py — fetch a model's context window, live where possible.

  * Anthropic — client.models.retrieve(model); read context window; catalog fallback.
  * Gemini    — client.models.get(model); read input_token_limit/output_token_limit; catalog fallback.
  * OpenAI    — no runtime context API; always catalog.
  * Groq      — no runtime context API; always catalog.

Returns: {context_window, max_output, source, endpoint}
"""
from __future__ import annotations
from typing import Any, Dict
from . import models


def context_for(vendor, model_id: str) -> Dict[str, Any]:
    if vendor.id == "anthropic":
        live = _anthropic_live(vendor, model_id)
        if live:
            return live
    if vendor.id == "google":
        live = _google_live(vendor, model_id)
        if live:
            return live
    if model_id in models.MODELS:
        mi = models.get(model_id)
        return {"context_window": mi.context_window, "max_output": mi.max_output,
                "source": f"catalog (models.py) — {mi.source}",
                "endpoint": "— (no runtime context API for this provider)"}
    return {"context_window": None, "max_output": None, "source": "unknown model", "endpoint": "—"}


def _anthropic_live(vendor, model_id: str):
    if not vendor.has_key():
        return None
    try:
        m = vendor.client().models.retrieve(model_id)
        ctx = getattr(m, "max_input_tokens", None) or getattr(m, "context_window", None)
        out = getattr(m, "max_output_tokens", None) or getattr(m, "max_tokens", None)
        if ctx:
            cat_out = models.get(model_id).max_output if model_id in models.MODELS else out
            return {"context_window": ctx, "max_output": out or cat_out,
                    "source": "Anthropic Models API (live)", "endpoint": "GET /v1/models/{model}"}
    except Exception:
        return None
    return None


def _google_live(vendor, model_id: str):
    if not vendor.has_key():
        return None
    try:
        # google-genai: get returns input/output token limits
        name = model_id if model_id.startswith("models/") else f"models/{model_id}"
        m = vendor.client().models.get(model=name)
        ctx = getattr(m, "input_token_limit", None)
        out = getattr(m, "output_token_limit", None)
        if ctx:
            return {"context_window": ctx, "max_output": out,
                    "source": "Gemini Models API (live)", "endpoint": "GET /v1beta/models/{model}"}
    except Exception:
        return None
    return None
