"""
main.py — the FastAPI app. Thin on purpose: it loads env vars, sets up CORS,
and includes the feature routers from routes/. The actual endpoints live in
routes/<feature>.py, one file per tab, so the backend mirrors the UI.
"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv

load_dotenv()

from .routes import all_routers

app = FastAPI(title="Life of an LLM Request — backend")
app.add_middleware(CORSMiddleware, allow_origins=["*"],
                   allow_methods=["*"], allow_headers=["*"])

for r in all_routers:
    app.include_router(r)
