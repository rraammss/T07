# The Life of an LLM Request — live (separate frontend + backend)

A hands-on companion to the lifecycle slides. Two independent Docker services.

```
llm_app2/
  docker-compose.yml            runs BOTH containers
  .env.example                  copy → .env, paste your GOOD keys
  backend/                      FastAPI + the provider SDKs
    Dockerfile                  (its own image)
    requirements.txt
    app/
      main.py                   routes ONLY (thin)
      models.py                 model capability table (context windows)
      sizing.py                 MTU packets + byte breakdown
      tokenizer.py              tiktoken (OpenAI) + count_tokens API (Anthropic)
      context.py                live context window (Anthropic Models API) + catalog
      documents.py              PDF / Word (.docx) base64 + text extract
      vendors/                  one file per provider (its OWN SDK)
        base.py  anthropic_vendor.py  openai_vendor.py  __init__.py
      errors/                   one file per HTTP error (two-phase)
        _util.py  e401 e403 e400 e404 e413 e429  __init__.py
  frontend/                     static UI, served by nginx (its own image)
    Dockerfile  nginx.conf  index.html
```

## Run

```bash
cp .env.example .env            # paste real keys
docker compose up --build
# open http://localhost:8080
```

The **frontend** (nginx, :8080) serves the page and proxies `/api/*` to the
**backend** container (uvicorn, :8000). Two separate images, one compose file.

## Tabs

**1 · Connection test** — a tiny real call proves the key works; shows the curl.

**2 · Error codes** — two screens: **left** shows the *exact crafted request*
(and the backend steps); **nothing is sent automatically** — you click
**"Send this request"** to fire it. **right** shows the live result. Every run
is logged to a session history.

**3 · Text payload and conversation** — Provider → Model → Mode → Max tokens, then:
- **live context window** (Anthropic Models API where available; catalog otherwise) — the source + endpoint are shown.
- **system instructions** as a 3-option preset dropdown (editable).
- **user message** (editable) and a **PDF / Word attachment** (no image/audio/video), base64-encoded with a visible size table.
- the **exact JSON** shown up top.
- **Calculate size & input tokens** → bytes → MTU packets, and **input tokens counted with the RIGHT tokenizer**, compared as a stacked bar of *input + reserved output* against the context window.
- **conversation history** in a 3-cell layout (system+user | attachment | history). Each **Send auto-appends** the exchange, and a **sliding-window bar** highlights which messages still fit the context window (blue = user, green = assistant, grey = would drop out).

**4 · File upload** — the *upload once, reference by id* model, in three phases:
- **① Upload** — a **real** call to the provider's Files API (`POST /v1/files` for OpenAI, beta Files API for Anthropic, `files.upload` for Gemini) returns a **file id**; the raw response envelope is shown.
- **② Chat** — each turn **references the id** (a few dozen bytes) instead of re-inlining the file. The JSON body, per-turn wire size, and a **response panel** (Reply text / Raw JSON) are all shown. Groq has no Files API for chat inputs, so it reports *not supported — must inline* (the Text tab's behavior).
- **③ Payoff** — a side-by-side of **inline every turn** (Text tab) vs **upload once + references** (this tab), computed from the real upload size and real per-turn request sizes, with the honest break-even point.

This tab makes **real API calls** and needs the provider key in `.env` (like the Text tab). Providers: OpenAI, Anthropic, Gemini support upload-by-reference; Groq does not.

## Tokenizers — a key teaching point

Every provider has its OWN tokenizer. Use the one that matches your model:

| Provider | Tokenizer | How | Accuracy |
|---|---|---|---|
| OpenAI | tiktoken (o200k_base) | local library | exact for GPT |
| Anthropic | count_tokens API | `client.messages.count_tokens(...)` → `.input_tokens` | exact for Claude, supports PDFs |
| Google Gemini | count_tokens API | `client.models.count_tokens(model, contents)` → `.total_tokens` | exact for Gemini |
| Groq (Llama) | estimate (~4 chars/tok) | no local SentencePiece vocab shipped | approximate, labeled |

Anthropic explicitly says **do not use tiktoken for Claude** — it undercounts by
~15–20% on typical text (more on code). This app uses each provider's own
tokenizer, and labels which one produced the number.

## Context = input + reserved output

The context window must hold BOTH your input tokens AND the reserved output
(`max_tokens`). The bar stacks input (blue) + reserved output (amber) against
the window, so "does it fit?" is answered honestly.

## Where context numbers come from (`context.py` + `models.py`)
- **Anthropic** — live `client.models.retrieve(model)` for `max_input_tokens`; catalog fallback.
- **Gemini** — live `client.models.get(model)` for `input_token_limit`/`output_token_limit`; catalog fallback.
- **OpenAI** — no reliable runtime context API; always the maintained catalog table.
- **Groq** — no runtime context API; catalog table.

## Error reproduction is SAFE

The environment always holds the GOOD keys — we never mutate `os.environ`. Auth
faults are produced by passing an explicit wrong key into a fresh client:

```python
client = vendor.client(api_key="sk-invalid-…")   # env untouched
```

Each error module is two-phase: `prepare(vendor)` returns the exact request to
display; `execute(vendor)` fires it only when you click send.

## Project structure — one file per idea

The code is split so each file does one thing. New tabs are added by dropping in
one new file, not editing a giant one.

```
frontend/
  index.html            HTML skeleton only — links the css + js below
  css/styles.css        all styling (design tokens live in :root at the top)
  js/
    core.js             globals ($ selectors, API base) + tiny shared helpers
    jsontree.js         the colored, collapsible JSON tree (reused everywhere)
    tab-connection.js   Tab 1
    tab-errors.js       Tab 2
    tab-text.js         Tab 3 (text payload & conversation)
    tab-file.js         Tab 4 (upload once, reference by id)
    app.js              boot: fetch lists, fill dropdowns, wire the tab bar (loads LAST)

backend/app/
  main.py               thin: load env, CORS, include the routers below
  routes/
    meta.py             health, providers, models, context window
    connection.py       Tab 1
    errors_routes.py    Tab 2
    text.py             Tab 3 (build, count_tokens, attach, send, stream)
    files.py            Tab 4 (file upload / reference-by-id)
    _shared.py          the attach_kwargs helper used by more than one router
  vendors/              one file per provider (base.py = shared interface)
  errors/               one file per HTTP error code
  tokenizer.py sizing.py context.py documents.py models.py fileref.py
```

The frontend uses **no build step** — plain `<script src>` tags loaded in
dependency order (shared code first, each tab next, `app.js` last). Open
`index.html` and it runs. To add the Image/Audio/Video tabs, add a
`js/tab-image.js` + a `routes/` file and register them the same way.

## Walk the code, vendor by vendor

Each provider file is self-contained: `build_payload` (the exact body — shown in
the UI and sized), `send`, `stream`, `connection_test`, `client(api_key=…)`.

| | OpenAI | Anthropic |
|---|---|---|
| SDK | `from openai import OpenAI` | `from anthropic import Anthropic` |
| endpoint | `chat.completions.create` | `messages.create` |
| system prompt | a `role:"system"` message | top-level `system=` param |
| `max_tokens` | optional | **required** |
| streaming | iterate chunks (`delta.content`) | `messages.stream()` ctx manager |
| usage | `prompt_tokens/completion_tokens` | `input_tokens/output_tokens` |
| token counting | tiktoken (local) | count_tokens API |

Plus two more providers from the original teaching sample:

| | Google Gemini | Groq |
|---|---|---|
| SDK | `from google import genai` | `from groq import Groq` |
| endpoint | `models.generate_content` | `chat.completions.create` (OpenAI-compatible) |
| system prompt | `GenerateContentConfig(system_instruction=)` | a `role:"system"` message |
| turns | `contents=[...]` | `messages=[...]` |
| usage | `usage_metadata` | `usage.prompt/completion_tokens` |
| context API | Models API (`input_token_limit`) live | catalog |

## Notes
- MTU: HTTP body is chopped into ~1500 B frames (~1460 B payload each); packets = ceil(on-wire / 1460).
- Attachments are PDF and Word only — stated in the UI. PDF text is extracted with pypdf and Word with python-docx; PDFs can also be token-counted natively by Anthropic's count_tokens.
- 429/413 depend on your live limits and may surface as a different code; the UI reports what came back.
