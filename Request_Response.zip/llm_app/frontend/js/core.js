/* ============================================================================
   core.js — shared state and small helpers used by every tab.
   Loaded FIRST. Defines the globals ($ selectors, API base, the lists the
   backend fills in) and tiny formatting helpers. No tab-specific logic here.
   ============================================================================ */

const API = (window.BACKEND_URL || "").replace(/\/$/,"");
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
let VENDORS=[], ERRORS=[], MODELS=[], conv=[], errHist=[];
let attachB64=null, attachMedia=null;
let connProv, errProv, plProv, plMode="stream", curErr=null, lastReply=null, lastUserSent=null;

const KEY_PAGES={
  "OPENAI_API_KEY":"https://platform.openai.com/api-keys",
  "ANTHROPIC_API_KEY":"https://console.anthropic.com/settings/keys",
  "GEMINI_API_KEY":"https://aistudio.google.com/app/apikey",
  "GROQ_API_KEY":"https://console.groq.com/keys",
};
const SYSTEM_PRESETS=[
  "You are a concise teaching assistant.",
  "You are a retail banking assistant. Answer only banking questions.",
  "You are a senior software engineer. Be precise and terse.",
];

/* ---- small shared helpers ---- */
function byteLen(s){ return new TextEncoder().encode(s||"").length; }
function fmt(b){ if(b<1024)return b+" B"; if(b<1048576)return (b/1024).toFixed(1)+" KB"; return (b/1048576).toFixed(2)+" MB"; }
function mimeLabel(m){ if(!m)return "unknown"; if(m==="application/pdf")return "PDF"; if(m.includes("wordprocessingml"))return "Word (.docx)"; if(m.startsWith("application/zip"))return "ZIP"; return m; }
function mimeShort(m){ if(!m)return "—"; if(m==="application/pdf")return "application/pdf"; if(m.includes("wordprocessingml"))return "…wordprocessingml.document"; if(m.length>34)return m.slice(0,32)+"…"; return m; }
function esc(s){ return (s||"").replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c])); }
function sleep(ms){ return new Promise(r=>setTimeout(r,ms)); }

function usage(u,ms){ if(!u)return""; const i=u.input_tokens??"—",o=u.output_tokens??"—";
  return `last send — input: ${i} · output: ${o}${ms?(" · "+ms+" ms"):""}`; }

$("#pl-clearconv").onclick=()=>{
  conv=[]; window._lastBreakdown=null; window._lastFit=null;
  renderConv();
  // the JSON body and token/size now reflect no history — refresh them
  scheduleJsonRefresh();
  if($("#pl-size").style.display!=="none") refreshSizing();
};

function deltaBadge(current, baseline, unit){
  if(baseline==null || baseline===0) return `<span class="delta base">baseline — first request</span>`;
  const pct=Math.round(100*(current-baseline)/baseline);
  if(pct===0) return `<span class="delta same">no change vs last request</span>`;
  const up=pct>0;
  return `<span class="delta ${up?'up':'down'}">${up?'↑':'↓'} ${Math.abs(pct)}% ${up?'larger':'smaller'} than your last request</span>`;
}


function fillModels(){
  const opts=MODELS.filter(m=>m.provider===plProv);
  $("#pl-model").innerHTML=opts.map(m=>`<option value="${m.id}">${m.label}</option>`).join("");
  $("#pl-model").onchange=()=>{fetchCtx(); scheduleJsonRefresh();};
}
