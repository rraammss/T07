/* ============================================================================
   tab-connection.js — Tab 1: a tiny real call that proves the API key works.
   ============================================================================ */

$("#conn-go").onclick=async()=>{
  const out=$("#conn-out"); out.style.display="block"; out.innerHTML='<span class="spin"></span> calling '+connProv+' …';
  const q=new URLSearchParams({provider:connProv,prompt:$("#conn-prompt").value});
  try{ const j=await (await fetch(API+"/api/connection_test?"+q)).json();
    $("#conn-curl").textContent=j.curl||"—";
    if(j.ok) out.innerHTML=`<div class="ok" style="font-size:16px">✓ Connected — HTTP ${j.status} · ${j.latency_ms} ms</div>
      <div class="muted" style="margin-top:10px">the model replied:</div><div class="mono" style="font-size:15px;margin-top:4px">“${esc(j.reply||'')}”</div>`;
    else if(j.reason==="no_key") out.innerHTML=`<div class="bad">✕ ${esc(j.message)}</div><div class="muted">set it in .env and restart the backend.</div>`;
    else out.innerHTML=`<div class="bad">✕ HTTP ${j.status||''} — ${esc(j.message||'failed')}</div>`;
  }catch(e){ out.innerHTML='<div class="bad">✕ '+esc(e.message)+'</div>'; }
};

