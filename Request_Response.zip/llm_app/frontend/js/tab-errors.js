/* ============================================================================
   tab-errors.js — Tab 2: craft a request that triggers a specific HTTP error
   (401/403/400/404/413/429), show the steps, then fire it for real.
   ============================================================================ */

function renderErrBtns(){
  $("#err-btns").innerHTML=ERRORS.map(e=>`<button data-code="${e.code}" title="${esc(e.name)}">${e.code}</button>`).join("");
  $$("#err-btns button").forEach(b=>b.onclick=()=>prepareErr(b.dataset.code,b));
}
async function prepareErr(code,btn){
  curErr=code;
  $$("#err-btns button").forEach(x=>x.classList.remove("active"));
  (btn||$$("#err-btns button").find(b=>b.dataset.code===code)).classList.add("active");
  const meta=ERRORS.find(e=>e.code===code);
  $("#err-why").innerHTML=`<b class="mono">${code} · ${esc(meta.name)}</b> — ${esc(meta.why)}`;
  $("#err-result").innerHTML='<span class="muted">not sent yet — review the request on the left, then click <b>Send this request</b>.</span>';
  const q=new URLSearchParams({provider:errProv,code});
  const j=await (await fetch(API+"/api/error_prepare?"+q)).json();
  const host=$("#err-steps"); host.innerHTML="";
  for(let i=0;i<j.steps.length;i++){
    const row=document.createElement("div"); row.className="tracerow";
    row.innerHTML=`<div class="n">${i+1}</div><div><div class="lab">${esc(j.steps[i].label)}</div><div class="det">${esc(j.steps[i].detail||'')}</div></div>`;
    host.appendChild(row); await sleep(350); row.classList.add("on");
  }
  $("#err-req").textContent=j.display_pretty;
  $("#err-reqwrap").style.display="block";
  $("#err-send").disabled=false;
  $("#err-send").onclick=()=>executeErr(code,meta);
}
async function executeErr(code,meta){
  const res=$("#err-result"); res.innerHTML='<span class="spin"></span> firing the real request…'; $("#err-send").disabled=true;
  try{
    const q=new URLSearchParams({provider:errProv,code});
    const j=await (await fetch(API+"/api/error_execute?"+q)).json();
    const got=j.status, match=j.matched;
    res.innerHTML=`<div class="result-badge ${match?'ok':'bad'}">${got}</div>
      <div style="margin-top:6px;font-size:14px">${match?'✓ matched the target code':'provider surfaced a different code (see steps)'}</div>
      <div class="muted" style="margin-top:10px">${esc(j.note||'')}</div>
      <pre class="mono small" style="margin-top:10px">${esc((j.raw||'').slice(0,400)||'(no body)')}</pre>`;
    const b=$$("#err-btns button").find(x=>x.dataset.code===code); if(b)b.classList.add("done");
    errHist.unshift({code,name:meta.name,provider:errProv,got,match,when:new Date().toLocaleTimeString()});
    renderErrHist();
  }catch(e){ res.innerHTML='<div class="bad">✕ '+esc(e.message)+'</div>'; }
  $("#err-send").disabled=false;
}
function renderErrHist(){
  if(!errHist.length) return;
  $("#err-hist").innerHTML="<thead><tr><th>time</th><th>provider</th><th>target</th><th>returned</th><th>match</th></tr></thead><tbody>"+
    errHist.map(h=>`<tr><td class="mono">${h.when}</td><td>${h.provider}</td><td class="mono">${h.code} ${esc(h.name)}</td>
      <td class="mono ${h.match?'ok':'bad'}">${h.got}</td><td>${h.match?'✓':'≠'}</td></tr>`).join("")+"</tbody>";
}
