/* ============================================================================
   jsontree.js — the colored, collapsible JSON tree renderer.
   Reused by every tab that shows a request or response body. Call
   renderJsonTreeInto(hostElement, object) to paint a tree into any element.
   ============================================================================ */

function renderJsonTree(obj){ renderJsonTreeInto($("#pl-jsontree"), obj); }
function renderJsonTreeInto(host, obj){
  host.innerHTML=""; host.classList.add("jsontree");
  host.appendChild(buildNode(obj, true));
}
function buildNode(val, root){
  const wrap=document.createElement("div");
  if(Array.isArray(val)){
    wrap.appendChild(collapsible("[", "]", val.map((v,i)=>({key:null,val:v})), root));
  } else if(val && typeof val==="object"){
    wrap.appendChild(collapsible("{", "}", Object.entries(val).map(([k,v])=>({key:k,val:v})), root));
  } else {
    wrap.appendChild(leaf(val));
  }
  return wrap;
}
function collapsible(open, close, entries, root){
  const box=document.createElement("div"); box.className="jnode";
  const head=document.createElement("span"); head.className="jtoggle";
  const caret=document.createElement("span"); caret.className="jcaret"; caret.textContent="▾";
  head.appendChild(caret);
  const ob=document.createElement("span"); ob.className="jbrace"; ob.textContent=open; head.appendChild(ob);
  const children=document.createElement("div"); children.className="jchildren";
  entries.forEach((e,idx)=>{
    const row=document.createElement("div"); row.className="jrow";
    if(e.key!==null){
      const k=document.createElement("span"); k.className="jkey"; k.textContent=`"${e.key}"`; row.appendChild(k);
      const c=document.createElement("span"); c.className="jpunc"; c.textContent=": "; row.appendChild(c);
    }
    const v=e.val;
    if(v && typeof v==="object"){ row.appendChild(buildNode(v,false)); }
    else { row.appendChild(leaf(v)); }
    if(idx<entries.length-1){ const cm=document.createElement("span"); cm.className="jpunc"; cm.textContent=","; row.appendChild(cm); }
    children.appendChild(row);
  });
  const cb=document.createElement("div"); cb.className="jbrace jclose"; cb.textContent=close;
  head.onclick=()=>{ box.classList.toggle("collapsed"); caret.textContent=box.classList.contains("collapsed")?"▸":"▾"; };
  box.appendChild(head); box.appendChild(children); box.appendChild(cb);
  return box;
}
function leaf(v){
  const s=document.createElement("span");
  if(typeof v==="string"){ s.className="jstr"; s.textContent=`"${v.length>120?v.slice(0,120)+'…':v}"`; }
  else if(typeof v==="number"){ s.className="jnum"; s.textContent=v; }
  else if(typeof v==="boolean"){ s.className="jbool"; s.textContent=v; }
  else if(v===null){ s.className="jnull"; s.textContent="null"; }
  else { s.textContent=String(v); }
  return s;
}
