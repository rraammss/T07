/* ============================================================================
   tab-file.js — Tab 4: the File upload (upload once, reference by id) tab.
   Three phases: ① real upload to the Files API, ② chat referencing the id,
   ③ the honest payoff — file-ID saves BYTES on the wire, not TOKENS.
   ============================================================================ */

/* ============ FILE UPLOAD TAB (upload once, reference by id) ============ */
let flProv=null, flConv=[], flFile=null, flFileId=null, flSupport={}, flUploadOnceBytes=0, flRawBytes=0, flTurnBytes=[], flTurnTokens=[];
async function initFileTab(){
  flSupport = await (await fetch(API+"/api/file_support")).json();
  const opts = VENDORS.map(v=>`<option value="${v.id}">${v.label}${flSupport[v.id]&&!flSupport[v.id].supported?' — no Files API':''}</option>`).join("");
  $("#fl-prov").innerHTML=opts; flProv=VENDORS[0]?.id||"openai";
  $("#fl-prov").onchange=e=>{ flProv=e.target.value; resetFileTab(); reflectSupport(); };
  reflectSupport();
  $("#fl-file").onchange=onFilePick;
  $("#fl-upload").onclick=doUpload;
  $("#fl-calc").onclick=()=>flRefresh(true);
  $("#fl-send").onclick=flSend;
  $("#fl-clear").onclick=()=>{ flConv=[]; flTurnBytes=[]; flTurnTokens=[]; window._flLastInputTokens=null; flRenderConv(); flRefresh(false); flRenderPayoff(); $("#fl-respwrap").style.display="none"; };
  ["#fl-system","#fl-user"].forEach(s=>$(s).addEventListener("input",()=>flRefresh(false)));
  $("#fl-json-expand").onclick=()=>$$("#fl-jsontree .jnode").forEach(n=>{n.classList.remove("collapsed");const c=n.querySelector(":scope > .jtoggle .jcaret");if(c)c.textContent="▾";});
  $("#fl-json-collapse").onclick=()=>$$("#fl-jsontree .jnode .jnode").forEach(n=>{n.classList.add("collapsed");const c=n.querySelector(":scope > .jtoggle .jcaret");if(c)c.textContent="▸";});
  $$("#fl-respmode .rm-btn").forEach(b=>b.onclick=()=>flSetRespMode(b.dataset.rm));
}
function reflectSupport(){
  const s=flSupport[flProv]||{};
  $("#fl-ep").textContent = s.endpoint ? s.endpoint : "—";
  if(!s.supported){
    $("#fl-unsupported").style.display="block";
    $("#fl-unsupported").innerHTML=`<b>${(VENDORS.find(v=>v.id===flProv)||{}).label||flProv} has no Files API for chat inputs.</b><br>${esc(s.note||"")}<br>You must inline the document text every turn — exactly the cost the Text-payload tab shows.`;
    $("#fl-size").style.display="none"; $("#fl-file").disabled=true;
  } else {
    $("#fl-unsupported").style.display="none"; $("#fl-file").disabled=false;
  }
}
function resetFileTab(){
  flFile=null; flFileId=null; $("#fl-file").value=""; $("#fl-fnote").textContent="";
  $("#fl-size").style.display="none"; $("#fl-uploaded").style.display="none";
  $("#fl-phase2").style.display="none"; $("#fl-phase3").style.display="none";
  $("#fl-resp-json").innerHTML="— the file-ID response will render here —";
}
async function onFilePick(e){
  const f=e.target.files[0]; if(!f) return;
  flFile=f;
  const buf=await f.arrayBuffer(); let bin=""; new Uint8Array(buf).forEach(b=>bin+=String.fromCharCode(b));
  flFile._b64=btoa(bin);
  const raw=f.size, b64=Math.ceil(raw/3)*4;
  flRawBytes=raw;
  $("#fl-fnote").innerHTML=`✓ <b>${esc(f.name)}</b>`;
  $("#fl-size").style.display="block";
  $("#fl-encsize").textContent=`${fmt(raw)} → ${fmt(b64)}`;
  $("#fl-encdetail").innerHTML=`base64-encoded (+33%). <b>This ${fmt(b64)} is sent exactly ONCE</b>, on the upload call below.`;
  $("#fl-uploaded").style.display="none";
}
async function doUpload(){
  if(!flFile) return;
  $("#fl-upload").textContent="↑ uploading…"; $("#fl-upload").disabled=true;
  const j=await (await fetch(API+"/api/file_upload",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({provider:flProv,b64:flFile._b64,filename:flFile.name})})).json();
  $("#fl-upload").textContent="↑ Upload file"; $("#fl-upload").disabled=false;
  if(!j.ok){
    $("#fl-unsupported").style.display="block";
    if(j.reason==="no_key") $("#fl-unsupported").innerHTML=`<b>${esc(j.message)}</b><br>Add the key to your <span class="mono">.env</span> and restart the backend, then try again.`;
    else if(j.supported===false) $("#fl-unsupported").innerHTML=`<b>Not supported.</b> ${esc(j.message)}`;
    else $("#fl-unsupported").innerHTML=`<b>Upload failed${j.status?` (HTTP ${j.status})`:''}.</b><br>${esc(j.message||"")}`;
    return;
  }
  flFileId=j.file_id; flUploadOnceBytes=j.upload_once_bytes;
  $("#fl-ep-title").textContent="the upload response — your file ID";
  renderJsonTreeInto($("#fl-resp-json"), j.response);
  $("#fl-uploaded").style.display="block";
  $("#fl-uploaded").innerHTML=`✓ stored as <span class="fileidchip">${esc(flFileId)}</span> <span class="muted">(${j.latency_ms} ms)</span><div class="muted" style="margin-top:6px">reference this ID from now on — the file itself won't be sent again.</div>`;
  $("#fl-phase2").style.display="block"; $("#fl-phase3").style.display="block";
  $("#fl-idchip").textContent=flFileId;
  $("#fl-refbox").innerHTML=`📎 <span class="rid">${esc(flFileId)}</span><div style="margin-top:8px">sent as a <b>reference</b>, ~${fmt(refBytes())} per turn<div class="muted">(not the ${fmt(Math.ceil(flRawBytes/3)*4)} file — just the id)</div></div>`;
  await flRefresh(false); flRenderPayoff();
}
function refBytes(){ return byteLen(JSON.stringify({file_id:flFileId})); }
async function flRefresh(showSize){
  if(!flFileId) return;
  const body={provider:flProv,model:(VENDORS.find(v=>v.id===flProv)||{}).default_model,system:$("#fl-system").value,user:$("#fl-user").value,history:flConv.slice(),file_id:flFileId,max_tokens:300};
  const j=await (await fetch(API+"/api/file_build",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify(body)})).json();
  renderJsonTreeInto($("#fl-jsontree"), j.payload);
  window._flPerTurnBytes = j.bytes.total_bytes;   // real measured per-turn wire size
  if(showSize){
    $("#fl-sizewrap").style.display="block";
    const b=j.bytes;
    $("#fl-wiretable").innerHTML="<tbody>"+
      `<tr><td><span class="ldot l-app"></span>application data <span class="muted">(JSON body — references the id)</span></td><td class="wv">${fmt(b.app_data_bytes)}</td></tr>`+
      `<tr><td><span class="ldot l-http"></span>+ HTTP headers <span class="muted">≈ typical</span></td><td class="wv">${fmt(b.http_header_bytes)}</td></tr>`+
      `<tr><td><span class="ldot l-tcp"></span>+ TCP/IP framing</td><td class="wv">${fmt(b.tcpip_bytes)}</td></tr>`+
      `<tr class="wtotal"><td><b>= total per turn</b></td><td class="wv"><b>${fmt(b.total_bytes)}</b></td></tr>`+
      "</tbody>";
    const inlineTotal=Math.ceil(flRawBytes/3)*4;
    $("#fl-wire-note").innerHTML=`Each turn is <b>${fmt(b.total_bytes)}</b> on the wire — the file (<b>${fmt(inlineTotal)}</b> inlined) is <b>not</b> here. That's the byte win: the id costs a few dozen bytes.`+
      (window._flLastInputTokens!=null
        ? `<div class="unitnote" style="margin-top:8px">⚠ <b>But tokens tell a different story:</b> the last send billed <b>${window._flLastInputTokens.toLocaleString()} input tokens</b>, which <b>include the document</b> — the model reads it every turn, so your <b>token cost is the same as inlining</b>. Bytes ≠ tokens. See the payoff below.</div>`
        : `<div class="muted" style="margin-top:6px">Send a turn to see the <b>real billed input tokens</b> — they include the document, and don't shrink just because you referenced it by ID.</div>`);
  }
}
async function flSend(){
  if(!flFileId) return;
  const u=$("#fl-user").value;
  $("#fl-status").innerHTML='<span class="spin"></span> sending…';
  const sentHistory=flConv.map(t=>({role:t.role,content:t.content}));   // history AS SENT (pre-append)
  const body={provider:flProv,model:(VENDORS.find(v=>v.id===flProv)||{}).default_model,system:$("#fl-system").value,user:u,history:sentHistory,file_id:flFileId,max_tokens:300};
  // measure the EXACT request we're about to send (reconciles with the size panel)
  let sentBytes=null;
  try{ const bj=await (await fetch(API+"/api/file_build",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify(body)})).json(); sentBytes=bj.bytes.total_bytes; }catch(e){}
  const j=await (await fetch(API+"/api/file_send",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify(body)})).json();
  $("#fl-status").innerHTML="";
  $("#fl-respwrap").style.display="block";
  if(!j.ok){
    const msg = j.reason==="no_key" ? `${j.message} — set it in .env and restart the backend.` : `HTTP ${j.status||''} — ${j.message||'request failed'}`;
    $("#fl-resp").innerHTML=`<span class="bad">${esc(msg)}</span>`;
    $("#fl-usage").textContent=""; window._flRaw=j.raw_response||null; flSetRespMode("text");
    return;
  }
  const reply=j.text||"";
  flConv.push({role:"user",content:u,ref:flFileId});
  flConv.push({role:"assistant",content:reply});
  $("#fl-user").value="";
  $("#fl-resp").textContent=reply||"(empty)";
  $("#fl-usage").textContent=usage(j.usage,j.latency_ms);
  // record REAL per-turn wire bytes + REAL billed input tokens for this sent turn
  flTurnBytes=flTurnBytes||[]; flTurnTokens=flTurnTokens||[];
  if(sentBytes!=null) flTurnBytes.push(sentBytes);
  if(j.usage && j.usage.input_tokens!=null){ window._flLastInputTokens=j.usage.input_tokens; flTurnTokens.push(j.usage.input_tokens); }
  window._flRaw=j.raw_response;
  flSetRespMode("text");
  flRenderConv(); flRefresh(true); flRenderPayoff();
}
function flSetRespMode(mode){
  $$("#fl-respmode .rm-btn").forEach(b=>b.classList.toggle("sel", b.dataset.rm===mode));
  if(mode==="text"){ $("#fl-resp").style.display="block"; $("#fl-resp-rawjson").style.display="none"; }
  else {
    $("#fl-resp").style.display="none"; $("#fl-resp-rawjson").style.display="block";
    if(window._flRaw) renderJsonTreeInto($("#fl-resp-rawjson"), window._flRaw);
    else $("#fl-resp-rawjson").innerHTML='<span style="color:#9ab">no raw response captured.</span>';
  }
}
function flRenderConv(){
  if(!flConv.length){ $("#fl-conv-list").innerHTML='<span class="muted">no turns yet.</span>'; $("#fl-conv-hint").style.display="none"; return; }
  $("#fl-conv-list").innerHTML=flConv.map(t=>{
    const refTag=t.ref?`<div class="docmark" title="carries only the file ID">📎 ${esc(t.ref.slice(0,14))}… +${refBytes()} B</div>`:"";
    return `<div class="turnrow"><div class="role ${t.role}">${t.role}<div class="turnbytes">${fmt(byteLen(t.content))}</div>${refTag}</div><div class="txt">${esc(t.content.slice(0,160))}${t.content.length>160?'…':''}</div></div>`;
  }).join("");
  $("#fl-conv-list").scrollTop=$("#fl-conv-list").scrollHeight;
  const turns=flConv.length/2;
  $("#fl-conv-hint").style.display="block";
  $("#fl-conv-hint").innerHTML=`${turns} turn${turns>1?'s':''} — each sent the id (<b>${fmt(refBytes())}</b>), never the file. Total id references: <b>${fmt(turns*refBytes())}</b> vs re-inlining the file ${turns}× = <b>${fmt(turns*Math.ceil(flRawBytes/3)*4)}</b>.`;
}
function flRenderPayoff(){
  if(!flFileId){ return; }
  const fileB64=Math.ceil(flRawBytes/3)*4;                 // the file's base64 size (what inline re-sends)
  const sent=flTurnBytes.length;                           // how many real turns we have
  const nRows=Math.max(sent, 3);                           // show at least 3 for the pattern
  // representative per-turn ref size: last real one, else current preview
  const repRef=flTurnBytes.length? flTurnBytes[flTurnBytes.length-1] : (window._flPerTurnBytes||(refBytes()+600));
  // ---- PART A: BYTES (real per-turn where we have it, projected otherwise) ----
  let brows=`<tr><td>Upload (one time)</td><td class="inlinecol">—</td><td class="refcol">${fmt(flUploadOnceBytes)}</td></tr>`;
  let inlineBytes=0, refBytesTotal=flUploadOnceBytes;
  for(let i=1;i<=nRows;i++){
    const real=flTurnBytes[i-1];
    const refB = real!=null ? real : repRef;
    const inlB = refB + fileB64;                            // inline = same request + the file bytes
    const proj = real==null ? ' <span class="muted">(projected)</span>' : '';
    inlineBytes+=inlB; refBytesTotal+=refB;
    brows+=`<tr><td>Turn ${i}${proj}</td><td class="inlinecol">${fmt(inlB)}${i>1?' <span class="muted">+file again</span>':''}</td><td class="refcol">${fmt(refB)}</td></tr>`;
  }
  const bsaved=Math.round(100*(inlineBytes-refBytesTotal)/inlineBytes);
  brows+=`<tr class="ptotal"><td>Total bytes (${nRows} turns)</td><td class="inlinecol">${fmt(inlineBytes)}</td><td class="refcol">${fmt(refBytesTotal)}${bsaved>0?` <span style="color:var(--green2)">↓ ${bsaved}%</span>`:''}</td></tr>`;
  // ---- PART B: INPUT TOKENS (real billed; file-ID does NOT reduce them) ----
  const realTok = flTurnTokens.length ? flTurnTokens[flTurnTokens.length-1] : null;
  let trows="";
  if(realTok!=null){
    let tokTotal=0;
    for(let i=1;i<=nRows;i++){
      const t=flTurnTokens[i-1]!=null?flTurnTokens[i-1]:realTok;
      const proj=flTurnTokens[i-1]==null?' <span class="muted">(projected)</span>':'';
      tokTotal+=t;
      trows+=`<tr><td>Turn ${i}${proj}</td><td class="refcol">${t.toLocaleString()}</td></tr>`;
    }
    trows+=`<tr class="ptotal"><td>Total input tokens (${nRows} turns)</td><td class="refcol">${tokTotal.toLocaleString()}</td></tr>`;
  } else {
    trows=`<tr><td colspan="2" class="muted">Send a turn to record the real billed input tokens.</td></tr>`;
  }
  $("#fl-payoff").innerHTML=
    `<thead><tr><th>BYTES ON THE WIRE</th><th>inline (file every turn)</th><th>file ID (this tab)</th></tr></thead><tbody>${brows}</tbody>`+
    `<thead><tr><th style="padding-top:14px">INPUT TOKENS billed (file ID) — <span style="color:var(--amber)">not reduced by referencing</span></th><th style="padding-top:14px"></th><th style="padding-top:14px">per turn</th></tr></thead><tbody>${trows}</tbody>`+
    `<tbody><tr><td colspan="3" class="muted" style="border:none;padding-top:8px;font-style:italic">Per-turn size and tokens climb as the conversation history accumulates — each turn re-sends every prior message. That's why an early turn is smaller than "your next send" above (which already carries the history so far). The file/id portion is constant; the growth is the history.</td></tr></tbody>`;
  // bars: bytes differ a lot; tokens are unchanged by file-ID
  const mx=Math.max(inlineBytes,refBytesTotal);
  let bars=`<div class="muted" style="font-weight:700;margin-bottom:2px">bytes on the wire — file-ID wins</div>`+
    `<div class="pbar-row"><div class="lbl" style="color:var(--red)">inline every turn</div><div class="pbar-track"><div class="pbar-fill inline" style="width:${Math.max(8,100*inlineBytes/mx)}%">${fmt(inlineBytes)}</div></div></div>`+
    `<div class="pbar-row"><div class="lbl" style="color:var(--green2)">upload once + refs</div><div class="pbar-track"><div class="pbar-fill ref" style="width:${Math.max(8,100*refBytesTotal/mx)}%">${fmt(refBytesTotal)}</div></div></div>`;
  if(realTok!=null){
    bars+=`<div class="muted" style="font-weight:700;margin:10px 0 2px">input tokens (cost) — file-ID does NOT reduce this</div>`+
      `<div class="pbar-row"><div class="lbl" style="color:var(--green2)">file ID, per turn</div><div class="pbar-track"><div class="pbar-fill" style="width:100%;background:var(--amber2)">~${realTok.toLocaleString()} tok — billed every turn</div></div></div>`;
  }
  $("#fl-payoffbars").innerHTML=bars;
  const visionNote = realTok!=null && flRawBytes>0 && realTok > (flRawBytes/1000)*8
    ? ` <b>Notice the size:</b> ~${realTok.toLocaleString()} tokens is far more than the plain text in a document this size — for PDFs the file path also ingests <b>page images (vision)</b>, not just text, which can make it cost <i>more</i> tokens than inlining extracted text alone (what the Text tab does for OpenAI/Groq).`
    : "";
  $("#fl-crossover").innerHTML=
    `<b>What upload-by-ID actually saves — and what it doesn't.</b><br>`+
    `✅ <b>Bytes on the wire:</b> the file travels once, so you stop re-transmitting it each turn (↓ ${bsaved>0?bsaved:0}% here).<br>`+
    `❌ <b>Token cost:</b> NOT saved. The model reads the whole document every turn, so input tokens — and your bill — don't shrink from referencing by ID.`+
    (realTok!=null?` The last send billed <b>${realTok.toLocaleString()} input tokens</b>, charged again every turn.`:"")+visionNote+`<br>`+
    `💡 <b>To cut token cost on repeated content, use prompt caching</b> (a separate feature): when the same prefix repeats across turns, cached input tokens are billed at a large discount (up to ~90% off on OpenAI/Anthropic). File-ID is a <i>bandwidth</i> optimization; caching is a <i>token-cost</i> one.`;
}

