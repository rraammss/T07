/* ============================================================================
   app.js — boot + global wiring. Loaded LAST, after every tab file has
   defined its functions. Fetches the provider/model/error lists from the
   backend, fills the dropdowns, wires the tab bar, and kicks off each tab.
   ============================================================================ */

Promise.all([
  fetch(API+"/api/vendors").then(r=>r.json()),
  fetch(API+"/api/health").then(r=>r.json()),
  fetch(API+"/api/errors").then(r=>r.json()),
  fetch(API+"/api/models").then(r=>r.json()),
]).then(([vs,health,errs,ms])=>{
  VENDORS=vs; ERRORS=errs; MODELS=ms;
  connProv=errProv=plProv=vs[0].id;
  $("#keychips").innerHTML=Object.values(health).map(h=>{
    const url=KEY_PAGES[h.key_env];
    const link=url?` <a class="getkey" href="${url}" target="_blank" rel="noopener" title="Get a key, then put it in your .env file">get key ↗</a>`:"";
    return `<span class="chip ${h.has_key?'on':'off'}"><span class="statusdot"></span>${h.key_env}${h.has_key?'':link}</span>`;
  }).join("");
  ["#conn-prov","#err-prov","#pl-prov"].forEach(sel=>$(sel).innerHTML=vs.map(v=>`<option value="${v.id}">${v.label}</option>`).join(""));
  $("#conn-prov").onchange=e=>connProv=e.target.value;
  $("#err-prov").onchange=e=>{errProv=e.target.value; if(curErr) prepareErr(curErr);};
  $("#pl-prov").onchange=e=>{plProv=e.target.value; fillModels(); fetchCtx(); renderCompat(); renderAttachSize(); scheduleJsonRefresh();};
  $("#pl-system-sel").innerHTML='<option value="-1">presets ▾</option>'+SYSTEM_PRESETS.map((s,i)=>`<option value="${i}">${s.length>42?s.slice(0,42)+'…':s}</option>`).join("");
  $("#pl-system-sel").onchange=e=>{const i=+e.target.value; if(i>=0){$("#pl-system").value=SYSTEM_PRESETS[i]; scheduleJsonRefresh();} e.target.value="-1";};
  ["#pl-system","#pl-user","#pl-max"].forEach(sel=>$(sel).addEventListener("input", scheduleJsonRefresh));
  fillModels(); renderErrBtns(); fetchCtx(); refreshJsonOnly(); initFileTab();
});

/* ---- tab bar + mode toggle wiring ---- */
$$(".tab").forEach(t=>t.onclick=()=>{
  $$(".tab").forEach(x=>x.classList.remove("sel")); t.classList.add("sel");
  $$(".panel").forEach(p=>p.classList.remove("sel")); $("#p-"+t.dataset.t).classList.add("sel");
});
$$("#pl-mode button").forEach(b=>b.onclick=()=>{$$("#pl-mode button").forEach(x=>x.classList.remove("sel"));b.classList.add("sel");plMode=b.dataset.m; scheduleJsonRefresh();});

